
import numpy as np
import random
import matplotlib.pyplot as plt
import pandas as pd
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import ListedColormap
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
import time
import math
import os
from datetime import datetime
from typing import Dict, List, Tuple
from collections import defaultdict
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from collections import deque
import openpyxl
from openpyxl import Workbook
from collections import Counter
import scipy.stats as stats
import copy

OUTPUT_DIR = r"File_path"  # Modify to your desired path

def ensure_output_directory():
    """Ensure output directory exists"""
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
        print(f"Output directory created: {OUTPUT_DIR}")
    return OUTPUT_DIR

def get_output_path(filename):
    """Get full path of output file"""
    ensure_output_directory()
    return os.path.join(OUTPUT_DIR, filename)

# Set Chinese font (for display of Chinese characters in plots)
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# ============================================================================
#                            Code 1: Original Warehouse System (Keep all functions)
# ============================================================================

# Create 3D shelf structure with coordinates starting from 1,
# so actual array size needs to be increased by 1
warehouse_shape = (16, 40, 14)  # (x, y, z) corresponding to 1-16, 1-40, 1-14
warehouse = np.zeros((warehouse_shape[0] + 1, warehouse_shape[1] + 1, warehouse_shape[2] + 1),
                     dtype=int)  # 1-based indexing

# Set 52% of storage slots as occupied
total_slots = warehouse_shape[0] * warehouse_shape[1] * warehouse_shape[2]
num_occupied = int(total_slots * 0.52)
occupied_indices = random.sample(range(1, total_slots + 1), num_occupied)  # 1-based indices

for idx in occupied_indices:
    idx_0based = idx - 1
    x = idx_0based // (warehouse_shape[1] * warehouse_shape[2]) + 1  # X-axis (1-16)
    y = (idx_0based % (warehouse_shape[1] * warehouse_shape[2])) // warehouse_shape[2] + 1  # Y-axis (1-40)
    z = idx_0based % warehouse_shape[2] + 1  # Z-axis (1-14)
    warehouse[x, y, z] = 1

print(f"Total warehouse storage slots: {total_slots}")
occupied = np.sum(warehouse) - warehouse[0].sum() - warehouse[:, 0].sum() - warehouse[:, :, 0].sum()
print(f"Occupied storage slots: {occupied} ({occupied / total_slots * 100:.2f}%)")

# Create mass and volume limits for each storage slot
mass_limits = np.zeros((warehouse_shape[0] + 1, warehouse_shape[1] + 1, warehouse_shape[2] + 1))
volume_limits = np.zeros((warehouse_shape[0] + 1, warehouse_shape[1] + 1, warehouse_shape[2] + 1))

for x in range(1, warehouse_shape[0] + 1):
    for y in range(1, warehouse_shape[1] + 1):
        for z in range(1, warehouse_shape[2] + 1):
            mass_limits[x, y, z] = round(random.uniform(1, 25), 2)
            volume_limits[x, y, z] = round(random.uniform(1, 30), 2)

# Create cargo information for occupied storage slots
occupied_items = {}
for x in range(1, warehouse_shape[0] + 1):
    for y in range(1, warehouse_shape[1] + 1):
        for z in range(1, warehouse_shape[2] + 1):
            if warehouse[x, y, z] == 1:  # Occupied storage slot
                occupied_items[(x, y, z)] = {
                    'mass': round(random.uniform(1, 25), 2),
                    'volume': round(random.uniform(1, 30), 2),
                    'frequency': random.randint(1, 30)
                }

# I/O points (inbound/outbound ports) configuration
IO_POINTS = {
    1: (1, 1, 1),  # I/O Point 1
    2: (8, 1, 1),  # I/O Point 2
    3: (16, 1, 1)  # I/O Point 3
}


def select_io_point_and_elevator(x_coordinate):
    """Select I/O point and elevator based on shuttle's x-coordinate"""
    if x_coordinate <= 6:
        return 1, 1  # I/O Point 1, Elevator 1
    elif 6 < x_coordinate <= 10:
        return 2, 2  # I/O Point 2, Elevator 2
    else:
        return 3, 3  # I/O Point 3, Elevator 3




def select_nearest_elevator_position(x_coordinate):
    """Select nearest elevator position and ID based on x-coordinate"""
    # Elevator positions: x=1 (ID=1), x=8 (ID=2), x=16 (ID=3)
    elevator_positions = [(1, 1), (8, 2), (16, 3)]  # (x-coordinate, elevator ID)

    # Find the nearest elevator
    min_distance = float('inf')
    selected_elevator_x = 1
    selected_elevator_id = 1

    for elevator_x, elevator_id in elevator_positions:
        distance = abs(x_coordinate - elevator_x)
        if distance < min_distance:
            min_distance = distance
            selected_elevator_x = elevator_x
            selected_elevator_id = elevator_id

    return selected_elevator_x, selected_elevator_id

import pandas as pd

# Function to read Excel file
def load_tasks_from_excel(file_path=r"C:\Users\hp\Desktop\DEC-MAPPO\storage_task_100.xlsx"):
    """Read task information from Excel file"""
    try:
        # Read Excel file
        df = pd.read_excel(file_path, sheet_name=0)  # Read first sheet

        print(f"=== Successfully read Excel file: {file_path} ===")
        print(f"File contains {len(df)} tasks")
        print(f"Column names: {list(df.columns)}")

        # Check if required columns exist
        required_columns = ['frequency', 'volume', 'weight']
        missing_columns = [col for col in required_columns if col not in df.columns]

        if missing_columns:
            print(f"Warning: Missing required columns: {missing_columns}")
            return None

        # Display data overview
        print(f"\nData Overview:")
        print(f"  Frequency range: {df['frequency'].min():.1f} - {df['frequency'].max():.1f}")
        print(f"  Volume range: {df['volume'].min():.2f} - {df['volume'].max():.2f}")
        print(f"  Weight range: {df['weight'].min():.2f} - {df['weight'].max():.2f}")
        if 'remaining_time' in df.columns:
            print(f"  Remaining time range: {df['remaining_time'].min():.2f} - {df['remaining_time'].max():.2f}")

        return df

    except FileNotFoundError:
        print(f"Error: File {file_path} not found")
        print("Please ensure the file exists in the current directory")
        return None
    except Exception as e:
        print(f"Error occurred while reading Excel file: {e}")
        return None

import numpy as np
from typing import Dict, List

# ============================================================================
#                            Reward Function System (Keep complete original reward system)
# ============================================================================

class EnhancedWarehouseRewardFunction:
    """Enhanced reward function design class for intelligent warehouse system - supports dense rewards and reward shaping"""

    def __init__(self,
                 time_weight=0.7,  # Reduce time weight to make space for new rewards
                 load_balance_weight=0.15,
                 step_reward_weight=0.15,  # New: Step reward weight
                 progress_reward_weight=0,  # New: Progress reward weight
                 curiosity_weight=0):  # New: Curiosity reward weight

        # Keep original parameters
        self.time_weight = time_weight
        self.load_balance_weight = load_balance_weight

        # New parameters
        self.step_reward_weight = step_reward_weight
        self.progress_reward_weight = progress_reward_weight
        self.curiosity_weight = curiosity_weight

        # Keep original baseline values
        self.baseline_task_time = 120.0
        self.baseline_total_time = 3000.0
        self.max_variance = 1000.0

        # New: Reward shaping related parameters
        self.previous_distances = {}  # Record distance from each shuttle to target
        self.state_visit_count = {}  # State visit count for curiosity reward
        self.task_progress_cache = {}  # Task progress cache

    # Keep all original methods (calculate_task_completion_reward, calculate_time_performance_reward, etc.)
    def calculate_task_completion_reward(self, task_completion_time: float, remaining_time: float = None) -> float:
        """Keep original implementation"""
        time_efficiency = max(0, (self.baseline_task_time - task_completion_time) / self.baseline_task_time)
        base_reward = 100 * (1 + time_efficiency)

        urgency_bonus = 0
        if remaining_time is not None:
            if remaining_time <= 20:
                urgency_bonus = 50
            elif remaining_time <= 40:
                urgency_bonus = 30
            elif remaining_time <= 60:
                urgency_bonus = 15

        return base_reward + urgency_bonus

    def calculate_time_performance_reward(self, current_time: float, total_tasks: int, completed_tasks: int) -> float:
        """Keep original implementation"""
        if completed_tasks == 0:
            return 0

        avg_completion_time = current_time / completed_tasks
        time_efficiency = max(0, (self.baseline_task_time - avg_completion_time) / self.baseline_task_time)
        progress_ratio = completed_tasks / total_tasks
        progress_reward = 200 * progress_ratio * (1 + time_efficiency)

        return progress_reward

    def calculate_load_balance_reward(self, equipment_loads: Dict[str, List[float]]) -> float:
        """Keep original implementation"""
        total_balance_reward = 0

        for equipment_type, loads in equipment_loads.items():
            if len(loads) <= 1:
                continue

            mean_load = np.mean(loads)
            variance = np.var(loads)
            balance_score = max(0, 1 - variance / self.max_variance)
            utilization_score = self._calculate_utilization_score(mean_load)
            equipment_reward = 50 * balance_score * utilization_score
            total_balance_reward += equipment_reward

        return total_balance_reward

    def _calculate_utilization_score(self, utilization: float) -> float:
        """Keep original implementation"""
        if 0.6 <= utilization <= 0.8:
            return 1.0
        elif utilization < 0.6:
            return utilization / 0.6
        else:
            return max(0, 2 - utilization)

    # New method: Dense rewards
    def calculate_dense_step_reward(self, state_info: Dict, prev_state_info: Dict = None) -> float:
        """Calculate dense step-level rewards - give small rewards for each step"""
        step_reward = 0.0

        # 1. Basic activity reward - encourage system to stay active
        active_shuttles = state_info.get('active_shuttles', 0)
        total_shuttles = state_info.get('total_shuttles', 1)
        activity_ratio = active_shuttles / total_shuttles
        step_reward += activity_ratio * 5.0  # Max 5 points for activity reward

        # 2. Efficiency reward - give reward based on current efficiency
        current_time = state_info.get('current_time', 0)
        completed_tasks = state_info.get('completed_task_count', 0)
        if current_time > 0 and completed_tasks > 0:
            current_efficiency = completed_tasks / (current_time / 60.0)  # Tasks completed per minute
            efficiency_reward = min(current_efficiency * 2.0, 10.0)  # Max 10 points
            step_reward += efficiency_reward

        # 3. Real-time load balance reward
        equipment_loads = state_info.get('equipment_loads', {})
        balance_reward = self._calculate_balance_step_reward(equipment_loads)
        step_reward += balance_reward

        return step_reward

    # New method: Potential-based reward shaping
    def calculate_potential_based_reward(self, shuttles_info: List[Dict]) -> float:
        """Potential function-based reward shaping"""
        total_potential_reward = 0.0

        for shuttle_info in shuttles_info:
            shuttle_id = shuttle_info['shuttle_id']
            current_pos = shuttle_info['current_position']
            target_pos = shuttle_info.get('target_position')

            if target_pos:
                # Calculate distance to target
                current_distance = self._calculate_3d_distance(current_pos, target_pos)

                # Get previous distance
                prev_distance = self.previous_distances.get(shuttle_id, current_distance)

                # Reward shaping: positive reward for distance reduction, negative for increase
                distance_improvement = prev_distance - current_distance
                potential_reward = distance_improvement * 2.0  # 2 points per unit distance improvement

                # Update distance record
                self.previous_distances[shuttle_id] = current_distance

                total_potential_reward += potential_reward

        return total_potential_reward

    # New method: Hierarchical progress reward
    def calculate_hierarchical_progress_reward(self, state_info: Dict) -> Dict[str, float]:
        """Hierarchical progress reward: immediate + short-term + long-term"""
        rewards = {
            'immediate': 0.0,
            'short_term': 0.0,
            'long_term': 0.0
        }

        # Immediate reward: instant feedback for current step
        rewards['immediate'] = self.calculate_dense_step_reward(state_info)

        # Short-term reward: phased progress (e.g., completing movement, starting operation, etc.)
        phase_progress = state_info.get('phase_progress', {})
        for phase, progress in phase_progress.items():
            if progress > 0:
                rewards['short_term'] += progress * 15.0  # Phase completion reward

        # Long-term reward: task completion and overall objectives
        completion_rate = state_info.get('completed_task_count', 0) / max(state_info.get('total_tasks', 1), 1)
        rewards['long_term'] = completion_rate * 100.0  # Completion rate reward

        return rewards

    # New method: Curiosity reward
    def calculate_curiosity_reward(self, state_vector: np.ndarray) -> float:
        """Curiosity reward based on state exploration"""
        # Convert state vector to hashable key
        state_key = tuple(np.round(state_vector, 2))  # Discretize state by keeping 2 decimal places

        # Update state visit count
        visit_count = self.state_visit_count.get(state_key, 0)
        self.state_visit_count[state_key] = visit_count + 1

        # Curiosity reward: higher reward for less visited states
        curiosity_reward = 10.0 / (1.0 + visit_count * 0.1)  # Decreasing exploration reward

        return curiosity_reward

    import numpy as np
    from typing import Dict, List

    # New method: Curiosity reward
    def calculate_curiosity_reward(self, state_vector: np.ndarray) -> float:
        """Curiosity reward based on state exploration"""
        # Convert state vector to hashable key
        state_key = tuple(np.round(state_vector, 2))  # Discretize state by keeping 2 decimal places

        # Update state visit count
        visit_count = self.state_visit_count.get(state_key, 0)
        self.state_visit_count[state_key] = visit_count + 1

        # Curiosity reward: higher reward for less visited states
        curiosity_reward = 10.0 / (1.0 + visit_count * 0.1)  # Decreasing exploration reward

        return curiosity_reward

    # New method: Task phase progress tracking reward
    def calculate_task_phase_progress_reward(self, shuttles_info: List[Dict]) -> float:
        """Task phase progress tracking reward"""
        progress_reward = 0.0

        for shuttle_info in shuttles_info:
            shuttle_id = shuttle_info['shuttle_id']
            current_phase = shuttle_info.get('current_phase', 'idle')
            phase_progress = shuttle_info.get('phase_progress', 0.0)  # Progress between 0-1

            # Set different progress reward weights for different phases
            phase_weights = {
                'to_io_for_inbound': 1.0,
                'inbound_phase': 1.5,
                'outbound_phase': 1.5,
                'to_io_for_outbound': 1.0,
                'moving_y': 0.8,
                'working': 2.0  # Higher reward for operation phase
            }

            phase_weight = phase_weights.get(current_phase, 0.5)

            # Calculate progress reward for this shuttle
            shuttle_progress_reward = phase_progress * phase_weight * 8.0
            progress_reward += shuttle_progress_reward

            # Cache progress information for reward shaping
            cache_key = f"{shuttle_id}_{current_phase}"
            prev_progress = self.task_progress_cache.get(cache_key, 0.0)

            # Give additional progress reward if there is improvement
            if phase_progress > prev_progress:
                progress_improvement = (phase_progress - prev_progress) * 20.0
                progress_reward += progress_improvement

            self.task_progress_cache[cache_key] = phase_progress

        return progress_reward

    # New method: Enhanced total reward calculation
    def calculate_enhanced_total_reward(self, state_info: Dict,
                                        prev_state_info: Dict = None,
                                        shuttles_info: List[Dict] = None,
                                        state_vector: np.ndarray = None) -> Dict[str, float]:
        """Enhanced total reward calculation - integrate all reward components"""

        reward_components = {}

        # 1. Original base rewards (time and load balance)
        base_time_reward = self.calculate_time_performance_reward(
            state_info.get('current_time', 0),
            state_info.get('total_tasks', 1),
            state_info.get('completed_task_count', 0)
        )
        base_balance_reward = self.calculate_load_balance_reward(
            state_info.get('equipment_loads', {})
        )
        reward_components['base_time'] = base_time_reward * self.time_weight
        reward_components['base_balance'] = base_balance_reward * self.load_balance_weight

        # 2. New: Dense step reward
        step_reward = self.calculate_dense_step_reward(state_info, prev_state_info)
        reward_components['step_reward'] = step_reward * self.step_reward_weight

        # 3. New: Potential-based reward shaping
        if shuttles_info:
            potential_reward = self.calculate_potential_based_reward(shuttles_info)
            reward_components['potential_reward'] = potential_reward * 0.3
        else:
            reward_components['potential_reward'] = 0.0

        # 4. New: Progress reward
        if shuttles_info:
            progress_reward = self.calculate_task_phase_progress_reward(shuttles_info)
            reward_components['progress_reward'] = progress_reward * self.progress_reward_weight
        else:
            reward_components['progress_reward'] = 0.0

        # 5. New: Curiosity reward
        if state_vector is not None:
            curiosity_reward = self.calculate_curiosity_reward(state_vector)
            reward_components['curiosity_reward'] = curiosity_reward * self.curiosity_weight
        else:
            reward_components['curiosity_reward'] = 0.0

        # Calculate total reward
        total_reward = sum(reward_components.values())
        reward_components['total'] = total_reward

        return reward_components

    import math
    import numpy as np
    from typing import Dict, List

    # New auxiliary methods
    def _calculate_balance_step_reward(self, equipment_loads: Dict[str, List[float]]) -> float:
        """Calculate step reward for load balance"""
        balance_reward = 0.0

        for equipment_type, loads in equipment_loads.items():
            if len(loads) <= 1:
                continue

            load_std = np.std(loads)
            max_possible_std = np.std([1.0, 0.0] * (len(loads) // 2)) if len(loads) > 1 else 1.0

            if max_possible_std > 0:
                balance_score = 1.0 - (load_std / max_possible_std)
                balance_reward += balance_score * 3.0  # Max 3 points per equipment type

        return balance_reward

    def _calculate_3d_distance(self, pos1: tuple, pos2: tuple) -> float:
        """Calculate 3D spatial distance"""
        if not pos1 or not pos2:
            return 0.0
        return math.sqrt(sum((a - b) ** 2 for a, b in zip(pos1, pos2)))

    def reset_episode_cache(self):
        """Reset episode cache"""
        self.previous_distances.clear()
        self.task_progress_cache.clear()
        # Note: Do NOT clear state_visit_count to maintain exploration memory across episodes

    # Keep original calculate_total_reward method for backward compatibility
    def calculate_total_reward(self, state_info: Dict) -> float:
        """Keep original simplified total reward calculation for compatibility with existing code"""
        current_time = state_info.get('current_time', 0)
        completed_task_count = state_info.get('completed_task_count', 0)
        total_tasks = state_info.get('total_tasks', 1)

        time_reward = 0
        if completed_task_count > 0:
            avg_time_per_task = current_time / completed_task_count
            baseline_time_per_task = 120.0
            time_efficiency = max(0, (baseline_time_per_task - avg_time_per_task) / baseline_time_per_task)
            time_reward = 1000 * time_efficiency * completed_task_count

            progress_ratio = completed_task_count / max(total_tasks, 1)
            progress_bonus = 500 * progress_ratio

            if progress_ratio >= 1.0:
                expected_total_time = 3000.0
                if current_time < expected_total_time:
                    completion_bonus = 2000 * (expected_total_time - current_time) / expected_total_time
                    time_reward += completion_bonus

            time_reward += progress_bonus

        balance_reward = self.calculate_load_balance_reward(
            state_info.get('equipment_loads', {})
        )

        total_reward = time_reward * 0.7 + balance_reward * 0.3
        return total_reward


from typing import Dict, List

class WarehouseStateExtractor:
    """Warehouse system state extractor"""

    def __init__(self):
        self.previous_state = None

    def extract_state_info(self, shuttles, transfer_shuttles, elevators, current_time, scheduler) -> Dict:
        """Extract enhanced state information to support new reward mechanisms"""
        # Keep all original code...

        # Extract basic information
        total_tasks = sum(len(tasks) for tasks in scheduler.zone_combined_tasks.values())
        completed_tasks = len(scheduler.completed_tasks)

        # Extract equipment load information
        shuttle_loads = []
        transfer_loads = []
        elevator_loads = []

        # Shuttle load (based on task execution time)
        for shuttle in shuttles:
            load = len(shuttle.completed_combined_tasks) / max(current_time / 100, 1)
            shuttle_loads.append(min(load, 1.0))

        # Transfer shuttle load
        for transfer_shuttle in transfer_shuttles.values():
            load = len(transfer_shuttle.completed_transfers) / max(current_time / 100, 1)
            transfer_loads.append(min(load, 1.0))

        # Elevator load
        for elevator in elevators.values():
            load = len(elevator.completed_lifts) / max(current_time / 100, 1)
            elevator_loads.append(min(load, 1.0))

        # Calculate total distance and working time
        total_distance = sum(shuttle.total_distance_traveled for shuttle in shuttles)
        total_distance += sum(ts.total_distance_traveled for ts in transfer_shuttles.values())
        total_distance += sum(el.total_distance_traveled for el in elevators.values())

        total_working_time = sum(shuttle.total_working_time for shuttle in shuttles)

        # Calculate idle time
        idle_time = 0
        for shuttle in shuttles:
            if shuttle.status == "idle":
                idle_time += 1

        # Extract detailed information of completed tasks
        completed_task_info = []
        for shuttle in shuttles:
            for task_info in shuttle.task_execution_log:
                completed_task_info.append({
                    'completion_time': task_info['duration'],
                    'remaining_time': task_info.get('remaining_time')
                })

        state_info = {
            'current_time': current_time,
            'total_tasks': total_tasks,
            'completed_task_count': completed_tasks,
            'completed_tasks': completed_task_info,
            'equipment_loads': {
                'shuttles': shuttle_loads,
                'transfer_shuttles': transfer_loads,
                'elevators': elevator_loads
            },
            'total_distance': total_distance,
            'total_working_time': total_working_time,
            'idle_time': idle_time,
            'deadline_violations': sum(getattr(shuttle, 'deadline_violations', 0) for shuttle in shuttles),
            'equipment_conflicts': sum(getattr(shuttle, 'equipment_conflicts', 0) for shuttle in shuttles),

            # New state information
            'active_shuttles': len([s for s in shuttles if s.status != "idle"]),
            'total_shuttles': len(shuttles),
            'phase_progress': self._calculate_overall_phase_progress(shuttles),
            'detailed_equipment_status': self._get_detailed_equipment_status(shuttles, transfer_shuttles, elevators)
        }

        return state_info

    def _calculate_overall_phase_progress(self, shuttles) -> Dict:
        """Calculate overall phase progress"""
        phase_progress = {}
        phase_counts = {}

        for shuttle in shuttles:
            phase = shuttle.current_phase
            progress = shuttle.get_phase_progress() if hasattr(shuttle, 'get_phase_progress') else 0.0

            if phase not in phase_progress:
                phase_progress[phase] = 0.0
                phase_counts[phase] = 0

            phase_progress[phase] += progress
            phase_counts[phase] += 1

        # Calculate average progress for each phase
        for phase in phase_progress:
            if phase_counts[phase] > 0:
                phase_progress[phase] /= phase_counts[phase]

        return phase_progress

    def _get_detailed_equipment_status(self, shuttles, transfer_shuttles, elevators) -> Dict:
        """Get detailed equipment status information"""
        return {
            'shuttle_statuses': {s.shuttle_id: s.status for s in shuttles},
            'transfer_statuses': {t_id: ts.status for t_id, ts in transfer_shuttles.items()},
            'elevator_statuses': {e_id: el.status for e_id, el in elevators.items()}
        }


import random
import copy
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from collections import deque

# ============================================================================
#                            DDPG Algorithm Implementation
# ============================================================================

class ReplayBuffer:
    """Experience replay buffer"""

    def __init__(self, capacity):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        """Add experience to buffer"""
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        """Sample batch data from buffer"""
        batch = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = map(np.stack, zip(*batch))
        return state, action, reward, next_state, done

    def __len__(self):
        return len(self.buffer)


class OUNoise:
    """Ornstein-Uhlenbeck noise generator for exploration"""

    def __init__(self, size, mu=0.0, theta=0.15, sigma=0.2):
        self.size = size
        self.mu = mu * np.ones(size)
        self.theta = theta
        self.sigma = sigma
        self.reset()

    def reset(self):
        """Reset noise state"""
        self.state = copy.deepcopy(self.mu)

    def sample(self):
        """Generate noise sample"""
        dx = self.theta * (self.mu - self.state) + self.sigma * np.random.randn(self.size)
        self.state += dx
        return self.state


class WarehouseActor(nn.Module):
    """Warehouse-specific Actor network - outputs 3 continuous values corresponding to 3 strategies"""

    def __init__(self, state_dim, hidden_dim=256):
        super(WarehouseActor, self).__init__()

        # Shared feature extraction layers
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)

        # Output continuous values for 3 strategies separately
        self.storage_head = nn.Linear(hidden_dim, 1)  # Storage strategy (strategy_1, strategy_2, strategy_3)
        self.outbound_head = nn.Linear(hidden_dim, 1)  # Outbound strategy (strategy_1-5)
        self.task_selection_head = nn.Linear(hidden_dim, 1)  # Task selection strategy (strategy_1-4)

        # Initialize network weights
        self.init_weights()

    def init_weights(self):
        """Initialize network weights"""
        for layer in [self.fc1, self.fc2]:
            nn.init.xavier_uniform_(layer.weight)
            nn.init.constant_(layer.bias, 0)

        # Output layers use smaller weight initialization
        for head in [self.storage_head, self.outbound_head, self.task_selection_head]:
            nn.init.uniform_(head.weight, -3e-3, 3e-3)
            nn.init.uniform_(head.bias, -3e-3, 3e-3)

    def forward(self, state):
        """Forward propagation"""
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))

        # Output 3 continuous values in range [-1, 1]
        storage_value = torch.tanh(self.storage_head(x))
        outbound_value = torch.tanh(self.outbound_head(x))
        task_selection_value = torch.tanh(self.task_selection_head(x))

        # Concatenate into a 3-dimensional action vector
        action = torch.cat([storage_value, outbound_value, task_selection_value], dim=1)
        return action


import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

class WarehouseCritic(nn.Module):
    """Warehouse-specific Critic network"""

    def __init__(self, state_dim, action_dim=3, hidden_dim=256):
        super(WarehouseCritic, self).__init__()

        # Q-network
        self.fc1 = nn.Linear(state_dim + action_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, 1)

        # Initialize network weights
        self.init_weights()

    def init_weights(self):
        """Initialize network weights"""
        for layer in [self.fc1, self.fc2]:
            nn.init.xavier_uniform_(layer.weight)
            nn.init.constant_(layer.bias, 0)

        # Last layer uses smaller weight initialization
        nn.init.uniform_(self.fc3.weight, -3e-3, 3e-3)
        nn.init.uniform_(self.fc3.bias, -3e-3, 3e-3)

    def forward(self, state, action):
        """Forward propagation"""
        x = torch.cat([state, action], dim=1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        q_value = self.fc3(x)
        return q_value


class WarehouseDDPG:
    """Warehouse-specific DDPG agent"""

    def __init__(self, state_dim, lr_actor=1e-4, lr_critic=1e-3, gamma=0.99, tau=0.005, noise_std=0.2):

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")

        # Hyperparameters
        self.gamma = gamma  # Discount factor
        self.tau = tau      # Soft update parameter
        self.action_dim = 3 # 3 strategies

        # Strategy mapping
        self.storage_strategies = ["strategy_1", "strategy_2", "strategy_3"]
        self.outbound_strategies = ["strategy_1", "strategy_2", "strategy_3", "strategy_4", "strategy_5"]
        self.task_selection_strategies = ["strategy_1", "strategy_2", "strategy_3", "strategy_4"]

        # Network initialization
        self.actor = WarehouseActor(state_dim).to(self.device)
        self.actor_target = WarehouseActor(state_dim).to(self.device)
        self.critic = WarehouseCritic(state_dim, self.action_dim).to(self.device)
        self.critic_target = WarehouseCritic(state_dim, self.action_dim).to(self.device)

        # Copy network parameters to target networks
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_target.load_state_dict(self.critic.state_dict())

        # Optimizers
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=lr_actor)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=lr_critic)

        self.actor_scheduler = optim.lr_scheduler.ExponentialLR(self.actor_optimizer, gamma=0.995)
        self.critic_scheduler = optim.lr_scheduler.ExponentialLR(self.critic_optimizer, gamma=0.995)

        # Experience replay buffer
        self.replay_buffer = ReplayBuffer(capacity=100000)

        # Noise generator
        self.noise = OUNoise(self.action_dim, sigma=noise_std)

        # Training statistics
        self.total_steps = 0

    def action_to_strategies(self, action):
        """Convert continuous action to discrete strategies"""
        # Action is a 3-dimensional vector with values in [-1, 1]
        storage_idx = int((action[0] + 1) * len(self.storage_strategies) / 2)
        storage_idx = min(storage_idx, len(self.storage_strategies) - 1)

        outbound_idx = int((action[1] + 1) * len(self.outbound_strategies) / 2)
        outbound_idx = min(outbound_idx, len(self.outbound_strategies) - 1)

        task_idx = int((action[2] + 1) * len(self.task_selection_strategies) / 2)
        task_idx = min(task_idx, len(self.task_selection_strategies) - 1)

        return (self.storage_strategies[storage_idx],
                self.outbound_strategies[outbound_idx],
                self.task_selection_strategies[task_idx])

    import torch
    import torch.nn.functional as F
    import numpy as np

    def select_action(self, state, add_noise=True):
        """Select action and convert to strategies"""
        state = torch.FloatTensor(state.reshape(1, -1)).to(self.device)

        with torch.no_grad():
            action = self.actor(state).cpu().data.numpy().flatten()

        if add_noise:
            noise = self.noise.sample()
            action = action + noise
            action = np.clip(action, -1.0, 1.0)

        # Convert to strategies
        strategies = self.action_to_strategies(action)

        return action, strategies

    def store_transition(self, state, action, reward, next_state, done):
        """Store experience transition"""
        self.replay_buffer.push(state, action, reward, next_state, done)

    def soft_update(self, target_network, source_network):
        """Soft update target network"""
        for target_param, param in zip(target_network.parameters(), source_network.parameters()):
            target_param.data.copy_(self.tau * param.data + (1.0 - self.tau) * target_param.data)

    def train(self, batch_size=64):
        """Train networks"""
        if len(self.replay_buffer) < batch_size:
            return None, None

        # Sample batch data
        state, action, reward, next_state, done = self.replay_buffer.sample(batch_size)

        # Convert to tensors
        state = torch.FloatTensor(state).to(self.device)
        action = torch.FloatTensor(action).to(self.device)
        reward = torch.FloatTensor(reward).reshape(-1, 1).to(self.device)
        next_state = torch.FloatTensor(next_state).to(self.device)
        done = torch.FloatTensor(done).reshape(-1, 1).to(self.device)

        # =============== Train Critic Network ===============
        with torch.no_grad():
            # Calculate target Q values
            next_action = self.actor_target(next_state)
            target_q = self.critic_target(next_state, next_action)
            target_q = reward + (1 - done) * self.gamma * target_q

        # Current Q values
        current_q = self.critic(state, action)

        # Critic loss
        critic_loss = F.mse_loss(current_q, target_q)

        # Update Critic
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # =============== Train Actor Network ===============
        # Actor loss (policy gradient)
        predicted_action = self.actor(state)
        actor_loss = -self.critic(state, predicted_action).mean()

        # Update Actor
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # =============== Soft Update Target Networks ===============
        self.soft_update(self.actor_target, self.actor)
        self.soft_update(self.critic_target, self.critic)

        return actor_loss.item(), critic_loss.item()

    def save_model(self, filepath):
        """Save model"""
        torch.save({
            'actor_state_dict': self.actor.state_dict(),
            'critic_state_dict': self.critic.state_dict(),
            'actor_optimizer_state_dict': self.actor_optimizer.state_dict(),
            'critic_optimizer_state_dict': self.critic_optimizer.state_dict(),
        }, filepath)
        print(f"Model saved to: {filepath}")

    def load_model(self, filepath):
        """Load model"""
        checkpoint = torch.load(filepath, map_location=self.device)
        self.actor.load_state_dict(checkpoint['actor_state_dict'])
        self.critic.load_state_dict(checkpoint['critic_state_dict'])
        self.actor_optimizer.load_state_dict(checkpoint['actor_optimizer_state_dict'])
        self.critic_optimizer.load_state_dict(checkpoint['critic_optimizer_state_dict'])

        # Update target networks
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_target.load_state_dict(self.critic.state_dict())
        print(f"Model loaded from {filepath}")import math

# ============================================================================
#                            Original Warehouse System Class
# ============================================================================

# Define Time Manager
class TimeManager:
    def __init__(self):
        self.current_time = 0.0  # Current time (seconds)

    def get_current_time(self):
        return self.current_time

    def advance_time(self, delta_time):
        self.current_time += delta_time

    def reset(self):
        self.current_time = 0.0

# Define Motion Calculator
class MotionCalculator:
    def __init__(self,
                 shuttle_velocity=3.0, transfer_velocity=3.0, elevator_velocity=4.0,
                 shuttle_acceleration=2.0, transfer_acceleration=2.0, elevator_acceleration=3.0,
                 # New: Physical dimension parameters
                 aisle_width=0.6,  # Aisle width
                 shelf_spacing=0.8,  # Shelf spacing
                 floor_height=1.2,  # Floor height
                 shuttle_depth=0.6): # Storage slot depth

        # Maximum velocities
        self.shuttle_velocity = shuttle_velocity
        self.transfer_velocity = transfer_velocity
        self.elevator_velocity = elevator_velocity

        # Accelerations
        self.shuttle_acceleration = shuttle_acceleration
        self.transfer_acceleration = transfer_acceleration
        self.elevator_acceleration = elevator_acceleration

        # New: Physical dimension parameters
        self.aisle_width = aisle_width  # Aisle width
        self.shelf_spacing = shelf_spacing  # Shelf spacing
        self.floor_height = floor_height  # Floor height
        self.shuttle_depth = shuttle_depth  # Storage slot depth

        # Pre-calculate common distances (performance optimization)
        self.single_aisle_distance = aisle_width
        self.single_shelf_distance = shelf_spacing
        self.single_floor_distance = floor_height

    def _calculate_travel_time_with_acceleration(self, distance, max_velocity, acceleration):
        """
        Calculate travel time considering acceleration
        """
        if distance <= 0:
            return 0.0

        max_speed_distance = (max_velocity ** 2) / acceleration

        if distance <= max_speed_distance:
            acceleration_time = math.sqrt(distance / acceleration)
            total_time = 2 * acceleration_time
        else:
            acceleration_time = max_velocity / acceleration
            acceleration_distance = (max_velocity ** 2) / (2 * acceleration)
            constant_speed_distance = distance - 2 * acceleration_distance
            constant_speed_time = constant_speed_distance / max_velocity
            total_time = 2 * acceleration_time + constant_speed_time

        return total_time

    def calculate_shuttle_travel_time_by_coordinates(self, start_pos, end_pos):
        """
        Calculate shuttle travel time based on coordinates (consider actual physical distance)
        """
        x1, y1, z1 = start_pos
        x2, y2, z2 = end_pos

        # Shuttle mainly moves along y-axis (movement within aisle)
        y_distance = abs(y2 - y1) * self.aisle_width

        # Add depth distance if there is depth movement (entering storage slot)
        depth_moves = 0
        if x1 != x2 or z1 != z2:
            depth_moves = max(abs(x2 - x1), abs(z2 - z1))

        total_distance = y_distance + depth_moves * self.shuttle_depth

        return self._calculate_travel_time_with_acceleration(
            total_distance, self.shuttle_velocity, self.shuttle_acceleration)

    def calculate_shuttle_travel_time(self, coordinate_distance, movement_type="y_axis"):
        """
        Calculate shuttle travel time based on coordinate difference
        """
        if movement_type == "y_axis":
            actual_distance = coordinate_distance * self.aisle_width
        elif movement_type == "depth":
            actual_distance = coordinate_distance * self.shuttle_depth
        else:
            actual_distance = coordinate_distance  # Fallback: use coordinate distance directly

        return self._calculate_travel_time_with_acceleration(
            actual_distance, self.shuttle_velocity, self.shuttle_acceleration)

    import math

    def calculate_transfer_travel_time_by_coordinates(self, start_pos, end_pos):
        """
        Calculate transfer shuttle travel time based on coordinates (consider shelf spacing)
        """
        x1, y1, z1 = start_pos
        x2, y2, z2 = end_pos

        # Transfer shuttle mainly moves along x-axis (cross-aisle movement)
        x_distance = abs(x2 - x1) * self.shelf_spacing

        return self._calculate_travel_time_with_acceleration(
            x_distance, self.transfer_velocity, self.transfer_acceleration)

    def calculate_transfer_travel_time(self, coordinate_distance):
        """
        Calculate transfer shuttle travel time based on x-coordinate difference (consider shelf spacing)
        """
        actual_distance = coordinate_distance * self.shelf_spacing
        return self._calculate_travel_time_with_acceleration(
            actual_distance, self.transfer_velocity, self.transfer_acceleration)

    def calculate_elevator_travel_time_by_coordinates(self, start_pos, end_pos):
        """
        Calculate elevator travel time based on coordinates (consider actual floor height)
        """
        x1, y1, z1 = start_pos
        x2, y2, z2 = end_pos

        # Elevator mainly moves along z-axis (inter-floor movement)
        z_distance = abs(z2 - z1) * self.floor_height

        return self._calculate_travel_time_with_acceleration(
            z_distance, self.elevator_velocity, self.elevator_acceleration)

    def calculate_elevator_travel_time(self, coordinate_distance):
        """
        Calculate elevator travel time based on z-coordinate difference (consider actual floor height)
        """
        actual_distance = coordinate_distance * self.floor_height
        return self._calculate_travel_time_with_acceleration(
            actual_distance, self.elevator_velocity, self.elevator_acceleration)

    def calculate_actual_distance(self, pos1, pos2):
        """
        Calculate actual physical distance between two points (consider actual dimensions of each axis)
        """
        x1, y1, z1 = pos1
        x2, y2, z2 = pos2

        # Calculate actual distance for each axis
        x_actual = abs(x2 - x1) * self.shelf_spacing
        y_actual = abs(y2 - y1) * self.aisle_width
        z_actual = abs(z2 - z1) * self.floor_height

        # Calculate actual distance in 3D space
        actual_distance = math.sqrt(x_actual ** 2 + y_actual ** 2 + z_actual ** 2)

        return actual_distance

    def get_physical_dimensions(self):
        """
        Get physical dimension parameter information
        """
        return {
            "aisle_width": self.aisle_width,
            "shelf_spacing": self.shelf_spacing,
            "floor_height": self.floor_height,
            "shuttle_depth": self.shuttle_depth,
            "warehouse_dimensions": {
                "total_width": 16 * self.shelf_spacing,  # 16 x-coordinates
                "total_length": 40 * self.aisle_width,  # 40 y-coordinates
                "total_height": 14 * self.floor_height  # 14 z-coordinates
            }
        }


# Optional: Add motion analysis methods in Shuttle, TransferShuttle, and Elevator classes

class EnhancedMotionAnalysis:
    """Motion analysis utility class - for debugging and optimizing motion parameters"""

    def analyze_shuttle_motion(self, shuttle, motion_calculator):
        """Analyze shuttle motion performance"""
        if hasattr(shuttle, 'movement_history'):
            motion_data = []
            for movement in shuttle.movement_history:
                distance = movement.get('distance', 0)
                if distance > 0:
                    profile = motion_calculator.get_motion_profile(
                        distance,
                        motion_calculator.shuttle_velocity,
                        motion_calculator.shuttle_acceleration
                    )
                    motion_data.append({
                        'distance': distance,
                        'calculated_time': profile['total_time'],
                        'actual_time': movement.get('actual_time', 0),
                        'profile_type': profile['profile_type'],
                        'peak_velocity': profile['peak_velocity']
                    })
            return motion_data
        return []

    def print_motion_comparison(self, old_calculator, new_calculator, test_distances):
        """Compare time differences between old and new motion calculators"""
        print("\n=== Motion Time Comparison Analysis ===")
        print(f"{'Distance(m)':<10} {'Old Method(s)':<12} {'New Method(s)':<12} {'Difference(%)':<10} {'Profile Type':<12}")
        print("-" * 70)

        for distance in test_distances:
            # Old method time (assuming simple distance/velocity calculation)
            old_shuttle_time = distance / 4.0  # Original shuttle velocity
            old_transfer_time = distance / 3.0  # Original transfer shuttle velocity
            old_elevator_time = distance / 4.0  # Original elevator velocity

            # New method time
            new_shuttle_time = new_calculator.calculate_shuttle_travel_time(distance)
            new_transfer_time = new_calculator.calculate_transfer_travel_time(distance)
            new_elevator_time = new_calculator.calculate_elevator_travel_time(distance)

            # Get motion profile
            shuttle_profile = new_calculator.get_motion_profile(
                distance, new_calculator.shuttle_velocity, new_calculator.shuttle_acceleration)

            # Calculate percentage difference
            shuttle_diff = ((new_shuttle_time - old_shuttle_time) / old_shuttle_time) * 100
            transfer_diff = ((new_transfer_time - old_transfer_time) / old_transfer_time) * 100
            elevator_diff = ((new_elevator_time - old_elevator_time) / old_elevator_time) * 100

            print(f"Shuttle:")
            print(f"{distance:<10.1f} {old_shuttle_time:<12.2f} {new_shuttle_time:<12.2f} "
                  f"{shuttle_diff:<10.1f} {shuttle_profile['profile_type']:<12}")

            print(f"Transfer Shuttle:")
            print(f"{distance:<10.1f} {old_transfer_time:<12.2f} {new_transfer_time:<12.2f} "
                  f"{transfer_diff:<10.1f}")

            print(f"Elevator:")
            print(f"{distance:<10.1f} {old_elevator_time:<12.2f} {new_elevator_time:<12.2f} "
                  f"{elevator_diff:<10.1f}")
            print("-" * 70)


# Transfer Shuttle Class: Responsible for shuttle's x-axis movement (cross-aisle movement)
class TransferShuttle:
    """Transfer Shuttle Class - Responsible for shuttle's x-axis movement, carrying shuttles for cross-aisle travel"""

    def __init__(self, transfer_id, assigned_level, motion_calculator):
        self.transfer_id = transfer_id
        self.assigned_level = assigned_level  # Responsible floor (z-coordinate)
        self.motion_calculator = motion_calculator

        # Transfer shuttle initial position: (1,1,z) on its responsible floor
        self.x, self.y, self.z = 1, 1, assigned_level
        self.initial_position = (self.x, self.y, self.z)

        # State management
        self.status = "idle"  # idle, carrying_shuttle, moving_to_pickup, moving_to_dropoff
        self.carried_shuttle = None  # Currently carried shuttle
        self.target_position = None
        self.movement_start_time = 0.0
        self.movement_duration = 0.0
        self.total_distance_traveled = 0.0
        self.total_working_time = 0.0

        # Task queue: Store information of shuttles needing transfer
        self.transfer_queue = []
        self.completed_transfers = []

        # New: Waiting time tracking
        self.idle_start_time = None
        self.total_idle_waiting_time = 0.0
        self.current_episode_waiting_time = 0.0
        self.waiting_episodes = []

    def add_transfer_request(self, shuttle, target_x, current_time):
        """Add transfer request"""
        transfer_request = {
            'shuttle': shuttle,
            'pickup_x': shuttle.x,
            'target_x': target_x,
            'pickup_y': shuttle.y,
            'created_time': current_time,
            'shuttle_id': shuttle.shuttle_id
        }
        self.transfer_queue.append(transfer_request)

    def start_next_transfer(self, current_time):
        """Start executing next transfer task"""
        if self.status != "idle" or not self.transfer_queue:
            return False

        current_request = self.transfer_queue.pop(0)
        shuttle = current_request['shuttle']
        pickup_x = current_request['pickup_x']

        if self.x != pickup_x:
            self.target_position = (pickup_x, 1, self.assigned_level)
            coordinate_distance = abs(self.x - pickup_x)
            self.movement_duration = self.motion_calculator.calculate_transfer_travel_time(coordinate_distance)
            self.movement_start_time = current_time
            actual_distance = coordinate_distance * self.motion_calculator.shelf_spacing  # Modify here
            self.total_distance_traveled += actual_distance
            self.status = "moving_to_pickup"
            self.current_request = current_request
        else:
            # Already at pickup position, pick up shuttle directly
            self._pickup_shuttle(current_request, current_time)

        return True

    def _pickup_shuttle(self, request, current_time):
        """Pick up shuttle"""
        shuttle = request['shuttle']
        self.carried_shuttle = shuttle
        self.current_request = request

        # Shuttle boards transfer shuttle
        shuttle.status = "on_transfer_shuttle"
        shuttle.x = self.x

        # Move to target position
        target_x = request['target_x']
        if self.x != target_x:
            self.target_position = (target_x, 1, self.assigned_level)
            coordinate_distance = abs(self.x - target_x)
            self.movement_duration = self.motion_calculator.calculate_transfer_travel_time(coordinate_distance)
            self.movement_start_time = current_time
            actual_distance = coordinate_distance * self.motion_calculator.shelf_spacing  # FIX: Define actual_distance
            self.total_distance_traveled += actual_distance
            self.status = "moving_to_dropoff"
        else:
            # Already at target position, drop off directly
            self._dropoff_shuttle(current_time)

    def _dropoff_shuttle(self, current_time):
        """Drop off shuttle"""
        if self.carried_shuttle:
            shuttle = self.carried_shuttle
            shuttle.status = "idle"
            shuttle.x = self.x

            # Record completed transfer
            transfer_info = {
                'shuttle_id': shuttle.shuttle_id,
                'start_time': self.current_request['created_time'],
                'end_time': current_time,
                'duration': current_time - self.current_request['created_time'],
                'from_x': self.current_request['pickup_x'],
                'to_x': self.current_request['target_x']
            }
            self.completed_transfers.append(transfer_info)

            # Notify shuttle transfer completion
            shuttle.on_transfer_completed(current_time)

            self.carried_shuttle = None
            self.current_request = None

        self.status = "idle"
        self.target_position = None

    def update(self, current_time):
        """Update transfer shuttle status"""
        if self.status == "idle":
            # Record idle waiting time
            if self.idle_start_time is None:
                self.idle_start_time = current_time

            # Attempt to start next transfer task
            if self.start_next_transfer(current_time):
                # End waiting, record waiting time
                if self.idle_start_time is not None:
                    waiting_duration = current_time - self.idle_start_time
                    self.total_idle_waiting_time += waiting_duration
                    self.current_episode_waiting_time += waiting_duration
                    self.waiting_episodes.append({
                        'start_time': self.idle_start_time,
                        'end_time': current_time,
                        'duration': waiting_duration,
                        'waiting_type': 'idle'
                    })
                    self.idle_start_time = None
            return
        else:
            # Non-idle state, reset idle start time
            self.idle_start_time = None

        elapsed_time = current_time - self.movement_start_time

        if elapsed_time >= self.movement_duration:
            if self.status == "moving_to_pickup":
                # Arrived at pickup position
                self.x = self.target_position[0]
                self._pickup_shuttle(self.current_request, current_time)
            elif self.status == "moving_to_dropoff":
                # Arrived at dropoff position
                self.x = self.target_position[0]
                if self.carried_shuttle:
                    self.carried_shuttle.x = self.x  # Update shuttle position
                self._dropoff_shuttle(current_time)

    def get_position(self):
        return (self.x, self.y, self.z)

    def __str__(self):
        return f"Transfer Shuttle {self.transfer_id} (Floor {self.assigned_level}): Position ({self.x}, {self.y}, {self.z}), Status: {self.status}"

    def reset_episode_waiting_time(self):
        """Reset episode waiting time"""
        self.current_episode_waiting_time = 0.0

# Elevator Class: Responsible for shuttle's z-axis movement (inter-floor movement)
class Elevator:
    """Elevator Class - Responsible for shuttle's z-axis movement, carrying shuttles for inter-floor travel"""

    def __init__(self, elevator_id, initial_x, motion_calculator):
        self.elevator_id = elevator_id
        self.motion_calculator = motion_calculator

        # Elevator initial position: 1st floor at specified x-coordinate
        self.x, self.y, self.z = initial_x, 1, 1
        self.initial_position = (self.x, self.y, self.z)

        # State management
        self.status = "idle"  # idle, carrying_shuttle, moving_to_pickup, moving_to_dropoff
        self.carried_shuttle = None  # Currently carried shuttle
        self.target_position = None
        self.movement_start_time = 0.0
        self.movement_duration = 0.0
        self.total_distance_traveled = 0.0
        self.total_working_time = 0.0

        # Task queue: Store information of shuttles needing lift
        self.lift_queue = []
        self.completed_lifts = []

        # New: Waiting time tracking
        self.idle_start_time = None
        self.total_idle_waiting_time = 0.0
        self.current_episode_waiting_time = 0.0
        self.waiting_episodes = []

    def add_lift_request(self, shuttle, target_z, current_time):
        """Add lift request"""
        lift_request = {
            'shuttle': shuttle,
            'pickup_z': shuttle.z,
            'target_z': target_z,
            'pickup_x': shuttle.x,
            'created_time': current_time,
            'shuttle_id': shuttle.shuttle_id
        }
        self.lift_queue.append(lift_request)

    def start_next_lift(self, current_time):
        """Start executing next lift task"""
        if self.status != "idle" or not self.lift_queue:
            return False

        current_request = self.lift_queue.pop(0)
        shuttle = current_request['shuttle']
        pickup_z = current_request['pickup_z']
        pickup_x = current_request['pickup_x']

        # Move to pickup position
        if self.z != pickup_z:
            self.target_position = (self.x, 1, pickup_z)
            distance = abs(self.z - pickup_z)
            self.movement_duration = self.motion_calculator.calculate_elevator_travel_time(distance)
            self.movement_start_time = current_time
            self.total_distance_traveled += distance
            self.status = "moving_to_pickup"
            self.current_request = current_request
        else:
            # Already at pickup position, pick up shuttle directly
            self._pickup_shuttle(current_request, current_time)

        return True

    def _pickup_shuttle(self, request, current_time):
        """Pick up shuttle"""
        shuttle = request['shuttle']
        self.carried_shuttle = shuttle
        self.current_request = request

        # Shuttle boards elevator
        shuttle.status = "on_elevator"
        shuttle.z = self.z

        # Move to target position
        target_z = request['target_z']
        if self.z != target_z:
            self.target_position = (self.x, 1, target_z)
            coordinate_distance = abs(self.z - target_z)
            self.movement_duration = self.motion_calculator.calculate_elevator_travel_time(
                coordinate_distance)  # FIX: Use correct method
            self.movement_start_time = current_time
            actual_distance = coordinate_distance * self.motion_calculator.floor_height  # FIX: Define actual_distance
            self.total_distance_traveled += actual_distance
            self.status = "moving_to_dropoff"
        else:
            # Already at target position, drop off directly
            self._dropoff_shuttle(current_time)

    def _dropoff_shuttle(self, current_time):
        """Drop off shuttle"""
        if self.carried_shuttle:
            shuttle = self.carried_shuttle
            shuttle.status = "idle"
            shuttle.z = self.z

            # Record completed lift
            lift_info = {
                'shuttle_id': shuttle.shuttle_id,
                'start_time': self.current_request['created_time'],
                'end_time': current_time,
                'duration': current_time - self.current_request['created_time'],
                'from_z': self.current_request['pickup_z'],
                'to_z': self.current_request['target_z']
            }
            self.completed_lifts.append(lift_info)

            # Notify shuttle lift completion
            shuttle.on_lift_completed(current_time)

            self.carried_shuttle = None
            self.current_request = None

        self.status = "idle"
        self.target_position = None

    def update(self, current_time):
        """Update elevator status"""
        if self.status == "idle":
            # Record idle waiting time
            if self.idle_start_time is None:
                self.idle_start_time = current_time

            # Attempt to start next lift task
            if self.start_next_lift(current_time):
                # End waiting, record waiting time
                if self.idle_start_time is not None:
                    waiting_duration = current_time - self.idle_start_time
                    self.total_idle_waiting_time += waiting_duration
                    self.current_episode_waiting_time += waiting_duration
                    self.waiting_episodes.append({
                        'start_time': self.idle_start_time,
                        'end_time': current_time,
                        'duration': waiting_duration,
                        'waiting_type': 'idle'
                    })
                    self.idle_start_time = None
            return
        else:
            # Non-idle state, reset idle start time
            self.idle_start_time = None

        elapsed_time = current_time - self.movement_start_time

        if elapsed_time >= self.movement_duration:
            if self.status == "moving_to_pickup":
                # Arrived at pickup position
                self.z = self.target_position[2]
                self._pickup_shuttle(self.current_request, current_time)
            elif self.status == "moving_to_dropoff":
                # Arrived at dropoff position
                self.z = self.target_position[2]
                if self.carried_shuttle:
                    self.carried_shuttle.z = self.z  # Update shuttle position
                self._dropoff_shuttle(current_time)

    def get_position(self):
        return (self.x, self.y, self.z)

    def __str__(self):
        return f"Elevator {self.elevator_id} (x={self.x}): Position ({self.x}, {self.y}, {self.z}), Status: {self.status}"

    def reset_episode_waiting_time(self):
        """Reset episode waiting time"""
        self.current_episode_waiting_time = 0.0

# Equipment Coordinator: Coordinates operations of transfer shuttles, elevators, and shuttles
class EquipmentCoordinator:
    """Equipment Coordinator - Unified management and coordination of transfer shuttles, elevators, and shuttles"""

    def __init__(self, transfer_shuttles, elevators):
        self.transfer_shuttles = transfer_shuttles
        self.elevators = elevators

    def request_x_movement(self, shuttle, target_x, current_time):
        """Request x-axis movement (transfer shuttle service)"""
        # Select corresponding transfer shuttle based on shuttle's current z-coordinate
        current_z = shuttle.z
        if current_z in self.transfer_shuttles:
            transfer_shuttle = self.transfer_shuttles[current_z]
            transfer_shuttle.add_transfer_request(shuttle, target_x, current_time)
            return True
        else:
            return False

    def request_z_movement(self, shuttle, target_z, current_time, preferred_elevator_id=None):
        """Request z-axis movement (elevator service)"""
        if preferred_elevator_id and preferred_elevator_id in self.elevators:
            # Use specified elevator
            selected_elevator = self.elevators[preferred_elevator_id]
            selected_elevator.add_lift_request(shuttle, target_z, current_time)
            return True
        else:
            # Select nearest elevator
            shuttle_x = shuttle.x
            min_distance = float('inf')
            selected_elevator = None

            for elevator in self.elevators.values():
                distance = abs(elevator.x - shuttle_x)
                if distance < min_distance:
                    min_distance = distance
                    selected_elevator = elevator

            if selected_elevator:
                selected_elevator.add_lift_request(shuttle, target_z, current_time)
                return True
            else:
                return False

    def update_all_equipment(self, current_time):
        """Update status of all equipment"""
        # Update transfer shuttles
        for transfer_shuttle in self.transfer_shuttles.values():
            transfer_shuttle.update(current_time)

        # Update elevators
        for elevator in self.elevators.values():
            elevator.update(current_time)


import random

# Modified Shuttle Class: Supports inbound/outbound processes via I/O points and integrates reward function
class ModifiedEnhancedShuttle:
    """Modified Enhanced Shuttle Class - Supports inbound/outbound processes via I/O points and integrates reward function"""

    def __init__(self, shuttle_id, warehouse_shape, zone, motion_calculator, equipment_coordinator,
                 reward_function=None):
        self.shuttle_id = shuttle_id
        self.warehouse_shape = warehouse_shape
        self.zone = zone
        self.motion_calculator = motion_calculator
        self.equipment_coordinator = equipment_coordinator
        self.reward_function = reward_function or EnhancedWarehouseRewardFunction()  # Integrate reward function

        # Generate initial position
        self.x, self.y, self.z = self._generate_zone_coordinates(zone)
        self.initial_position = (self.x, self.y, self.z)

        # Task and state management
        self.current_combined_task = None
        self.status = "idle"
        self.current_phase = "idle"
        self.target_position = None
        self.movement_start_time = 0.0
        self.movement_duration = 0.0
        self.total_distance_traveled = 0.0
        self.total_working_time = 0.0
        self.completed_combined_tasks = []

        # New: Cumulative execution time tracking
        self.cumulative_execution_time = 0.0

        # Reward-related attributes
        self.total_reward = 0.0  # Cumulative reward
        self.reward_history = []  # Reward history
        self.deadline_violations = 0  # Number of deadline violations
        self.equipment_conflicts = 0  # Number of equipment conflicts

        # Movement plan and status
        self.movement_plan = []  # Store complete movement plan
        self.current_movement_step = 0
        self.waiting_for_equipment = None  # "transfer" or "elevator"
        self.selected_io_point = None  # Currently selected I/O point
        self.selected_elevator_id = None  # Currently selected elevator ID

        # Task execution records
        self.task_execution_log = []
        self.current_task_start_time = 0.0

        # New: Waiting time tracking
        self.waiting_start_time = None
        self.total_waiting_time = 0.0
        self.waiting_episodes = []  # Record each waiting episode
        self.current_episode_waiting_time = 0.0
        self.phase_start_time = 0.0
        self.phase_expected_duration = 0.0
        self.detailed_phase_progress = {}  # Detailed phase progress information

    def _generate_zone_coordinates(self, zone):
        """Generate random coordinates within the boundary of the specified warehouse zone"""
        max_attempts = 1000

        for _ in range(max_attempts):
            if zone == "Zone A":
                x = random.randint(1, 8)
                y = random.randint(1, 28)
                z = random.randint(1, 8)
            elif zone == "Zone B":
                sub_areas = [
                    {"x_range": (1, 8), "y_range": (1, 34), "z_range": (9, 11)},
                    {"x_range": (1, 8), "y_range": (29, 34), "z_range": (1, 8)},
                    {"x_range": (9, 12), "y_range": (1, 34), "z_range": (1, 11)}
                ]
                area = random.choice(sub_areas)
                x = random.randint(area["x_range"][0], area["x_range"][1])
                y = random.randint(area["y_range"][0], area["y_range"][1])
                z = random.randint(area["z_range"][0], area["z_range"][1])
            elif zone == "Zone C":
                sub_areas = [
                    {"x_range": (1, 12), "y_range": (1, 40), "z_range": (12, 14)},
                    {"x_range": (1, 12), "y_range": (35, 40), "z_range": (1, 11)},
                    {"x_range": (13, 16), "y_range": (1, 40), "z_range": (1, 14)}
                ]
                area = random.choice(sub_areas)
                x = random.randint(area["x_range"][0], area["x_range"][1])
                y = random.randint(area["y_range"][0], area["y_range"][1])
                z = random.randint(area["z_range"][0], area["z_range"][1])
            else:
                x = random.randint(1, self.warehouse_shape[0])
                y = random.randint(1, self.warehouse_shape[1])
                z = random.randint(1, self.warehouse_shape[2])

            if Task._determine_zone(x, y, z) == zone:
                return x, y, z

        raise ValueError(f"Failed to generate valid coordinates for warehouse zone {zone}")

    def calculate_reward(self, current_time, scheduler=None):
        """Calculate reward for current state"""
        if not scheduler:
            return 0.0

        # Extract state information
        state_extractor = WarehouseStateExtractor()

        # Simulate other equipment information (pass real equipment objects in actual use)
        dummy_transfer_shuttles = {}
        dummy_elevators = {}

        state_info = state_extractor.extract_state_info(
            [self], dummy_transfer_shuttles, dummy_elevators,
            current_time, scheduler
        )

        reward = self.reward_function.calculate_total_reward(state_info)
        self.reward_history.append({
            'time': current_time,
            'reward': reward,
            'cumulative_reward': self.total_reward + reward
        })

        return reward

    def update_reward(self, reward):
        """Update cumulative reward"""
        self.total_reward += reward

    def create_movement_plan(self, target_location, phase_type="normal"):
        """Create complete movement plan considering elevator position constraints"""
        if not target_location:
            return []

        target_x, target_y, target_z = target_location
        current_x, current_y, current_z = self.x, self.y, self.z

        plan = []
        elevator_positions = [1, 8, 16]

        if phase_type == "to_io":
            # Movement plan to I/O point
            # Step 1: Move along y-axis to aisle entrance
            if current_y != 1:
                plan.append({
                    'type': 'y_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (current_x, 1, current_z),
                    'equipment': 'self'
                })
                current_y = 1

            # Step 2: If z-axis movement is needed, first move to nearest elevator position
            if current_z != target_z:
                nearest_elevator_x, elevator_id = select_nearest_elevator_position(current_x)

                # Move to elevator position if not already there
                if current_x != nearest_elevator_x:
                    plan.append({
                        'type': 'x_movement',
                        'from': (current_x, current_y, current_z),
                        'to': (nearest_elevator_x, current_y, current_z),
                        'equipment': 'transfer_shuttle'
                    })
                    current_x = nearest_elevator_x

                # Z-axis movement
                plan.append({
                    'type': 'z_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (current_x, current_y, target_z),
                    'equipment': 'elevator',
                    'preferred_elevator_id': elevator_id
                })
                current_z = target_z

            # Step 3: Move to x-coordinate of I/O point
            if current_x != target_x:
                plan.append({
                    'type': 'x_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (target_x, current_y, current_z),
                    'equipment': 'transfer_shuttle'
                })

        elif phase_type == "return_to_io":
            # Movement plan returning to I/O point
            # Step 1: Move along y-axis to aisle entrance
            if current_y != 1:
                plan.append({
                    'type': 'y_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (current_x, 1, current_z),
                    'equipment': 'self'
                })
                current_y = 1

            # Step 2: If z-axis movement is needed, first move to nearest elevator position
            if current_z != target_z:
                nearest_elevator_x, elevator_id = select_nearest_elevator_position(current_x)

                # Move to elevator position
                if current_x != nearest_elevator_x:
                    plan.append({
                        'type': 'x_movement',
                        'from': (current_x, current_y, current_z),
                        'to': (nearest_elevator_x, current_y, current_z),
                        'equipment': 'transfer_shuttle'
                    })
                    current_x = nearest_elevator_x

                # Z-axis movement
                plan.append({
                    'type': 'z_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (current_x, current_y, target_z),
                    'equipment': 'elevator',
                    'preferred_elevator_id': elevator_id
                })
                current_z = target_z

            # Step 3: Move to x-coordinate of I/O point
            if current_x != target_x:
                plan.append({
                    'type': 'x_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (target_x, current_y, current_z),
                    'equipment': 'transfer_shuttle'
                })

        else:
            # Regular movement plan (from I/O point to storage location or between storage locations)
            # Step 1: Move along y-axis to aisle entrance (if not already there)
            if current_y != 1:
                plan.append({
                    'type': 'y_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (current_x, 1, current_z),
                    'equipment': 'self'
                })
                current_y = 1

            # Step 2: If z-axis movement is needed, first move to nearest elevator position
            if current_z != target_z:
                nearest_elevator_x, elevator_id = select_nearest_elevator_position(current_x)

                # Move to elevator position
                if current_x != nearest_elevator_x:
                    plan.append({
                        'type': 'x_movement',
                        'from': (current_x, current_y, current_z),
                        'to': (nearest_elevator_x, current_y, current_z),
                        'equipment': 'transfer_shuttle'
                    })
                    current_x = nearest_elevator_x

                # Z-axis movement
                plan.append({
                    'type': 'z_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (current_x, current_y, target_z),
                    'equipment': 'elevator',
                    'preferred_elevator_id': elevator_id
                })
                current_z = target_z

            # Step 3: Move along x-axis to target position (if needed)
            if current_x != target_x:
                plan.append({
                    'type': 'x_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (target_x, current_y, current_z),
                    'equipment': 'transfer_shuttle'
                })
                current_x = target_x

            # Step 4: Move along y-axis to target position
            if current_y != target_y:
                plan.append({
                    'type': 'y_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (target_x, target_y, target_z),
                    'equipment': 'self'
                })

        return plan

    def start_combined_task(self, combined_task, current_time):
        """Start executing combined task"""
        if self.status != "idle" or not combined_task:
            return False

        self.current_combined_task = combined_task
        self.current_phase = "to_io_for_inbound"
        self.current_task_start_time = current_time

        # Select I/O point and elevator based on inbound task location (selection for inbound phase)
        inbound_x = combined_task.inbound_task.selected_location[0]
        io_point_id, elevator_id = select_io_point_and_elevator(inbound_x)
        self.selected_io_point = io_point_id
        self.selected_elevator_id = elevator_id
        io_location = IO_POINTS[io_point_id]

        # Create movement plan to I/O point
        self.movement_plan = self.create_movement_plan(io_location, "to_io")
        self.current_movement_step = 0

        if self.movement_plan:
            self._start_next_movement_step(current_time)
            return True
        else:
            # Already at I/O point, start inbound pickup operation directly
            self._start_inbound_pickup_operation(current_time)
            return True

    def _start_next_movement_step(self, current_time):
        """Start next movement step"""
        if self.current_movement_step < len(self.movement_plan):
            step = self.movement_plan[self.current_movement_step]
            equipment = step['equipment']

            if equipment == 'elevator':
                # Request elevator service
                target_z = step['to'][2]
                preferred_elevator_id = step.get('preferred_elevator_id', None)
                success = self.equipment_coordinator.request_z_movement(
                    self, target_z, current_time, preferred_elevator_id)
                if success:
                    self.status = "waiting_equipment"
                    self.waiting_for_equipment = "elevator"
                    self.waiting_start_time = current_time
                else:
                    self.equipment_conflicts += 1

            elif equipment == 'transfer_shuttle':
                # Request transfer shuttle service
                target_x = step['to'][0]
                success = self.equipment_coordinator.request_x_movement(self, target_x, current_time)
                if success:
                    self.status = "waiting_equipment"
                    self.waiting_for_equipment = "transfer_shuttle"
                    self.waiting_start_time = current_time
                else:
                    self.equipment_conflicts += 1

            elif equipment == 'self':
                # Autonomous y-axis movement
                self._start_y_movement(step['to'], current_time)
        else:
            # All movement steps completed, start current phase operation
            self._start_current_phase_operation(current_time)

    def _start_y_movement(self, target_position, current_time):
        """Start y-axis movement (add progress tracking)"""
        # Keep original code...
        target_x, target_y, target_z = target_position
        current_pos = (self.x, self.y, self.z)

        self.target_position = target_position
        coordinate_distance = abs(target_y - self.y)
        self.movement_duration = self.motion_calculator.calculate_shuttle_travel_time(
            coordinate_distance, "y_axis")
        self.movement_start_time = current_time
        actual_distance = coordinate_distance * self.motion_calculator.aisle_width
        self.total_distance_traveled += actual_distance
        self.status = "moving_y"

        # New: Set phase tracking
        self.phase_start_time = current_time
        self.phase_expected_duration = self.movement_duration

    def on_transfer_completed(self, current_time):
        """Callback for transfer shuttle completion"""
        if self.waiting_for_equipment == "transfer_shuttle":
            # New: End waiting timer
            if self.waiting_start_time is not None:
                waiting_duration = current_time - self.waiting_start_time
                self.total_waiting_time += waiting_duration
                self.current_episode_waiting_time += waiting_duration
                self.waiting_episodes.append({
                    'start_time': self.waiting_start_time,
                    'end_time': current_time,
                    'duration': waiting_duration,
                    'equipment_type': 'transfer_shuttle'
                })
                self.waiting_start_time = None

            self.waiting_for_equipment = None
            self.status = "idle"
            self.current_movement_step += 1
            self._start_next_movement_step(current_time)

    def on_lift_completed(self, current_time):
        """Callback for elevator lift completion"""
        if self.waiting_for_equipment == "elevator":
            # New: End waiting timer
            if self.waiting_start_time is not None:
                waiting_duration = current_time - self.waiting_start_time
                self.total_waiting_time += waiting_duration
                self.current_episode_waiting_time += waiting_duration
                self.waiting_episodes.append({
                    'start_time': self.waiting_start_time,
                    'end_time': current_time,
                    'duration': waiting_duration,
                    'equipment_type': 'elevator'
                })
                self.waiting_start_time = None

            self.waiting_for_equipment = None
            self.status = "idle"
            self.current_movement_step += 1
            self._start_next_movement_step(current_time)

    def _start_current_phase_operation(self, current_time):
        """Start current phase operation (add progress tracking)"""
        # Keep original if-elif logic...
        if self.current_phase == "to_io_for_inbound":
            self._start_inbound_pickup_operation(current_time)
        elif self.current_phase == "inbound_phase":
            self._start_inbound_storage_operation(current_time)
        elif self.current_phase == "to_io_for_outbound":
            self._start_outbound_delivery_operation(current_time)
        elif self.current_phase == "outbound_phase":
            self._start_outbound_pickup_operation(current_time)

        # New: Set operation phase tracking
        self.phase_start_time = current_time
        self.phase_expected_duration = 2.0  # Expected operation duration

    def _start_inbound_pickup_operation(self, current_time):
        """Start inbound pickup operation at I/O point"""
        self.status = "working"
        self.movement_start_time = current_time
        self.movement_duration = 2.0  # Inbound pickup operation time: 2 seconds

    def _start_inbound_storage_operation(self, current_time):
        """Start inbound storage operation"""
        self.status = "working"
        self.movement_start_time = current_time
        self.movement_duration = 2.0  # Inbound storage operation time: 2 seconds

    def _start_outbound_pickup_operation(self, current_time):
        """Start outbound pickup operation"""
        self.status = "working"
        self.movement_start_time = current_time
        self.movement_duration = 2.0  # Outbound pickup operation time: 2 seconds

    def _start_outbound_delivery_operation(self, current_time):
        """Start outbound delivery operation at I/O point"""
        self.status = "working"
        self.movement_start_time = current_time
        self.movement_duration = 2.0  # Outbound delivery operation time: 2 seconds

    def update(self, current_time):
        """Update shuttle status"""
        if self.status in ["idle", "waiting_equipment", "on_transfer_shuttle", "on_elevator"]:
            return

        elapsed_time = current_time - self.movement_start_time

        if elapsed_time >= self.movement_duration:
            if self.status == "moving_y":
                # Y-axis movement completed
                self.x, self.y, self.z = self.target_position
                self.target_position = None
                self.status = "idle"
                self.current_movement_step += 1
                self._start_next_movement_step(current_time)

            elif self.status == "working":
                # Operation completed
                self._complete_current_phase(current_time)

    def _complete_current_phase(self, current_time):
        """Complete current phase"""
        if self.current_phase == "to_io_for_inbound":
            # Pickup at I/O point completed, proceed to inbound storage location
            self.current_phase = "inbound_phase"
            self.total_working_time += 2.0

            # Create movement plan to inbound storage location
            self.movement_plan = self.create_movement_plan(self.current_combined_task.inbound_task.selected_location)
            self.current_movement_step = 0

            if self.movement_plan:
                self._start_next_movement_step(current_time)
            else:
                self._start_inbound_storage_operation(current_time)

        elif self.current_phase == "inbound_phase":
            # Inbound storage completed, proceed to outbound pickup location
            self.current_phase = "outbound_phase"
            self.total_working_time += 2.0

            # Create movement plan to outbound pickup location
            self.movement_plan = self.create_movement_plan(self.current_combined_task.outbound_task.source_location)
            self.current_movement_step = 0

            if self.movement_plan:
                self._start_next_movement_step(current_time)
            else:
                self._start_outbound_pickup_operation(current_time)

        elif self.current_phase == "outbound_phase":
            # Outbound pickup completed, return to I/O point
            self.current_phase = "to_io_for_outbound"
            self.total_working_time += 2.0

            # Re-select I/O point and elevator (based on current position)
            io_point_id, elevator_id = select_io_point_and_elevator(self.x)
            self.selected_io_point = io_point_id
            self.selected_elevator_id = elevator_id

            # Create movement plan to return to I/O point (using dedicated return mode)
            io_location = IO_POINTS[self.selected_io_point]
            self.movement_plan = self.create_movement_plan(io_location, "return_to_io")
            self.current_movement_step = 0

            if self.movement_plan:
                self._start_next_movement_step(current_time)
            else:
                self._start_outbound_delivery_operation(current_time)

        elif self.current_phase == "to_io_for_outbound":
            # Delivery at I/O point completed, task finished
            self.total_working_time += 2.0
            self.complete_current_combined_task(current_time)

    from typing import Dict

    def complete_current_combined_task(self, current_time):
        """Complete current combined task"""
        if self.current_combined_task:
            self.completed_combined_tasks.append(self.current_combined_task)

            # Calculate task execution time and update cumulative execution time
            task_duration = current_time - self.current_task_start_time
            self.cumulative_execution_time += task_duration

            # Record task execution details - use dynamically updated remaining time
            remaining_time = getattr(self.current_combined_task.inbound_task, 'dynamic_remaining_time',
                                     getattr(self.current_combined_task.inbound_task, 'remaining_time', None))

            # Calculate task completion reward
            task_reward = self.reward_function.calculate_task_completion_reward(task_duration, remaining_time)
            self.update_reward(task_reward)

            # Check for deadline violation
            if remaining_time is not None and task_duration > remaining_time:
                self.deadline_violations += 1

            task_info = {
                'task_id': self.current_combined_task.task_id,
                'start_time': self.current_task_start_time,
                'end_time': current_time,
                'duration': task_duration,
                'inbound_location': self.current_combined_task.inbound_task.selected_location,
                'outbound_location': self.current_combined_task.outbound_task.source_location,
                'io_point': self.selected_io_point,
                'remaining_time': remaining_time,
                'task_type': 'combined',
                'storage_strategy': getattr(self.current_combined_task.inbound_task, 'storage_strategy_result', {}).get(
                    'strategy', 'unknown'),
                'outbound_strategy': getattr(self.current_combined_task, 'outbound_strategy', 'unknown'),
                'task_reward': task_reward,  # New: Record reward
                'deadline_violated': remaining_time is not None and task_duration > remaining_time
            }
            self.task_execution_log.append(task_info)

            self.current_combined_task = None

        self.status = "idle"
        self.current_phase = "idle"
        self.target_position = None
        self.movement_plan = []
        self.current_movement_step = 0
        self.selected_io_point = None
        self.selected_elevator_id = None

    def get_position(self):
        return (self.x, self.y, self.z)

    def __str__(self):
        return f"Shuttle {self.shuttle_id} (Zone:{self.zone}): Position ({self.x}, {self.y}, {self.z}), Status: {self.status}, Cumulative Reward: {self.total_reward:.2f}"

    def reset_episode_waiting_time(self):
        """Reset episode waiting time"""
        self.current_episode_waiting_time = 0.0

    def get_phase_progress(self) -> float:
        """Get current phase progress (0-1)"""
        if self.status == "idle":
            return 1.0

        if self.phase_expected_duration <= 0:
            return 0.0

        current_time = self.movement_start_time + self.movement_duration  # Use existing time calculation
        elapsed_time = current_time - self.phase_start_time
        progress = min(elapsed_time / self.phase_expected_duration, 1.0)

        return max(0.0, progress)

    def get_shuttle_info_for_reward(self) -> Dict:
        """Get shuttle information for reward calculation"""
        return {
            'shuttle_id': self.shuttle_id,
            'current_position': (self.x, self.y, self.z),
            'target_position': self.target_position,
            'current_phase': self.current_phase,
            'phase_progress': self.get_phase_progress(),
            'status': self.status,
            'zone': self.zone
        }

# Define Combined Task Class (Inbound + Outbound)
class CombinedTask:
    def __init__(self, task_id, inbound_task, outbound_task, outbound_strategy="strategy_1"):
        self.task_id = task_id
        self.inbound_task = inbound_task
        self.outbound_task = outbound_task
        self.zone = inbound_task.zone
        self.outbound_strategy = outbound_strategy

    def __str__(self):
        return f"Combined Task {self.task_id}: Inbound {self.inbound_task.selected_location} + Outbound {self.outbound_task.source_location} (Outbound Strategy: {self.outbound_strategy})"


# Define Outbound Task Class
class OutboundTask:
    def __init__(self, task_id, source_location, warehouse_shape):
        self.task_id = task_id
        self.task_type = "outbound"
        self.source_location = source_location  # Outbound storage location (x, y, z)
        self.warehouse_shape = warehouse_shape
        self.zone = Task._determine_zone(source_location[0], source_location[1], source_location[2])
        self.mass = None
        self.volume = None
        self.frequency = None
        self.lmd_value = None

    def set_item_properties(self, mass, volume, frequency):
        """Set item properties"""
        self.mass = mass
        self.volume = volume
        self.frequency = frequency

    def calculate_lmd(self, mass_limits, volume_limits):
        """Calculate LMD value"""
        if self.mass and self.volume:
            x, y, z = self.source_location
            self.lmd_value = (mass_limits[x, y, z] / self.mass) * (volume_limits[x, y, z] / self.volume)
            return self.lmd_value
        return None

    def __str__(self):
        return f"Task ID: {self.task_id}, Type: Outbound, Outbound Location: {self.source_location}, Zone: {self.zone}"


import random

# Modified Task Class with support for parameter reading from Excel files
class Task:
    def __init__(self, task_id, task_type, warehouse_shape, mass=None, volume=None, frequency=None,
                 remaining_time=None):
        self.task_id = task_id
        self.task_type = task_type
        self.warehouse_shape = warehouse_shape

        # Use provided parameters if available, otherwise generate randomly (maintain compatibility)
        self.mass = mass if mass is not None else round(random.uniform(1, 25), 2)
        self.volume = volume if volume is not None else round(random.uniform(1, 30), 2)
        self.frequency = frequency if frequency is not None else random.randint(1, 30)
        self.remaining_time = remaining_time  # New: Remaining time attribute

        self.zone = None
        self.cluster = None
        self.candidate_locations = []
        self.selected_location = None
        self.storage_strategy_result = None

    def find_candidate_locations_in_zone(self, warehouse, mass_limits, volume_limits, zone, used_locations):
        """Find top 5 optimal candidate storage locations in the specified zone"""
        valid_locations = []

        for x in range(1, self.warehouse_shape[0] + 1):
            for y in range(1, self.warehouse_shape[1] + 1):
                for z in range(1, self.warehouse_shape[2] + 1):
                    if Task._determine_zone(x, y, z) == zone:
                        location_key = (x, y, z)
                        if (warehouse[x, y, z] == 0 and
                                self.mass <= mass_limits[x, y, z] and
                                self.volume <= volume_limits[x, y, z] and
                                location_key not in used_locations):
                            lmd_value = (mass_limits[x, y, z] / self.mass) * (volume_limits[x, y, z] / self.volume)
                            valid_locations.append((x, y, z, lmd_value))

        if valid_locations:
            valid_locations.sort(key=lambda x: x[3], reverse=True)
            top_5_locations = valid_locations[:5]
            self.candidate_locations = top_5_locations
            return True
        else:
            self.candidate_locations = []
            return False

    @staticmethod
    def _determine_zone(x, y, z):
        """Determine the warehouse zone for given coordinates"""
        if 1 <= x <= 8 and 1 <= y <= 28 and 1 <= z <= 8:
            return "Zone A"
        elif ((1 <= x <= 8 and 1 <= y <= 34 and 9 <= z <= 11) or
              (1 <= x <= 8 and 29 <= y <= 34 and 1 <= z <= 8) or
              (9 <= x <= 12 and 1 <= y <= 34 and 1 <= z <= 11)):
            return "Zone B"
        elif ((1 <= x <= 12 and 1 <= y <= 40 and 12 <= z <= 14) or
              (1 <= x <= 12 and 35 <= y <= 40 and 1 <= z <= 11) or
              (13 <= x <= 16 and 1 <= y <= 40 and 1 <= z <= 14)):
            return "Zone C"
        else:
            return "Unknown Zone"

    def __str__(self):
        remaining_str = f", Remaining Time: {self.remaining_time:.2f}" if self.remaining_time is not None else ""
        if self.selected_location:
            return f"Task ID: {self.task_id}, Type: Inbound, Mass: {self.mass}kg, Volume: {self.volume}dm³, " \
                   f"Frequency: {self.frequency} times/week{remaining_str}, Zone: {self.zone}, Selected Location: {self.selected_location}"
        else:
            return f"Task ID: {self.task_id}, Type: Inbound, Mass: {self.mass}kg, Volume: {self.volume}dm³, " \
                   f"Frequency: {self.frequency} times/week{remaining_str}, Zone: {self.zone}"


import random

# Improved Storage Strategy Class - Supports selection of 3 strategies
class StorageStrategy:
    @staticmethod
    def strategy_1_random_storage(task, warehouse, mass_limits, volume_limits, zone, used_locations):
        """Strategy 1: Random Storage Principle - Randomly select 1 empty storage location from valid locations in the specified zone"""
        # Find all valid empty storage locations in the specified zone
        valid_locations = []

        for x in range(1, task.warehouse_shape[0] + 1):
            for y in range(1, task.warehouse_shape[1] + 1):
                for z in range(1, task.warehouse_shape[2] + 1):
                    if Task._determine_zone(x, y, z) == zone:
                        location_key = (x, y, z)
                        # Check if location is empty, meets mass/volume limits, and not in used locations
                        if (warehouse[x, y, z] == 0 and
                                task.mass <= mass_limits[x, y, z] and
                                task.volume <= volume_limits[x, y, z] and
                                location_key not in used_locations):
                            # Calculate LMD value
                            lmd_value = (mass_limits[x, y, z] / task.mass) * (volume_limits[x, y, z] / task.volume)
                            valid_locations.append((x, y, z, lmd_value))

        if valid_locations:
            # Randomly select one from all valid empty locations
            selected_candidate = random.choice(valid_locations)
            x, y, z, lmd = selected_candidate
            return {
                'strategy': 'Random Storage',
                'selected_location': (x, y, z),
                'lmd_value': lmd,
                'z_coordinate': z,
                'reason': f'Randomly selected location ({x},{y},{z}) from {len(valid_locations)} valid empty locations in {zone}'
            }
        else:
            return {
                'strategy': 'Random Storage',
                'selected_location': None,
                'reason': f'No valid empty locations found in {zone}'
            }

    @staticmethod
    def strategy_2_highest_lmd(task):
        """Strategy 2: Select storage location with the highest location matching degree (LMD)"""
        if task.candidate_locations:
            # Candidate locations are already sorted by LMD in descending order, select first (highest LMD)
            best_candidate = task.candidate_locations[0]
            x, y, z, lmd = best_candidate
            return {
                'strategy': 'Highest Matching Degree',
                'selected_location': (x, y, z),
                'lmd_value': lmd,
                'z_coordinate': z,
                'reason': f'Selected location ({x},{y},{z}) with highest LMD value ({lmd:.4f})'
            }
        else:
            return {
                'strategy': 'Highest Matching Degree',
                'selected_location': None,
                'reason': 'No candidate locations available'
            }

    @staticmethod
    def strategy_3_lmd_with_z_priority(task, lmd_threshold_ratio=0.95):
        """Strategy 3: Combined LMD matching degree & minimum z-coordinate priority strategy"""
        if task.candidate_locations:
            max_lmd = task.candidate_locations[0][3]
            lmd_threshold = max_lmd * lmd_threshold_ratio

            qualified_locations = []
            for x, y, z, lmd in task.candidate_locations:
                if lmd >= lmd_threshold:
                    qualified_locations.append((x, y, z, lmd))

            if qualified_locations:
                # Select location with smallest z-coordinate among those meeting LMD threshold
                best_location = min(qualified_locations, key=lambda loc: loc[2])
                x, y, z, lmd = best_location
                return {
                    'strategy': 'Matching Degree + Z-Coordinate Priority',
                    'selected_location': (x, y, z),
                    'lmd_value': lmd,
                    'z_coordinate': z,
                    'reason': f'Selected location with smallest z-coordinate ({z}) from {len(qualified_locations)} locations with LMD ≥ {lmd_threshold:.4f}'
                }
            else:
                # If no locations meet LMD threshold, select highest LMD instead
                x, y, z, lmd = task.candidate_locations[0]
                return {
                    'strategy': 'Matching Degree + Z-Coordinate Priority (Degraded)',
                    'selected_location': (x, y, z),
                    'lmd_value': lmd,
                    'z_coordinate': z,
                    'reason': f'No locations met LMD threshold, selected highest LMD location instead'
                }
        else:
            return {
                'strategy': 'Matching Degree + Z-Coordinate Priority',
                'selected_location': None,
                'reason': 'No candidate locations available'
            }

    @staticmethod
    def select_storage_location(task, strategy_name="strategy_3", warehouse=None, mass_limits=None, volume_limits=None,
                                zone=None, used_locations=None):
        """Select storage location based on strategy name"""
        if strategy_name == "strategy_1":
            return StorageStrategy.strategy_1_random_storage(task, warehouse, mass_limits, volume_limits, zone,
                                                             used_locations)
        elif strategy_name == "strategy_2":
            return StorageStrategy.strategy_2_highest_lmd(task)
        elif strategy_name == "strategy_3":
            return StorageStrategy.strategy_3_lmd_with_z_priority(task)
        else:
            # Use Strategy 3 by default
            return StorageStrategy.strategy_3_lmd_with_z_priority(task)

    @staticmethod
    def strategy_warehouse_wide_random(task, warehouse, mass_limits, volume_limits, used_locations):
        """Warehouse-wide Random Storage - Select random valid empty location across entire warehouse (no zone restriction)"""
        # Find all valid empty storage locations across entire warehouse
        valid_locations = []

        for x in range(1, task.warehouse_shape[0] + 1):
            for y in range(1, task.warehouse_shape[1] + 1):
                for z in range(1, task.warehouse_shape[2] + 1):
                    location_key = (x, y, z)
                    # Check if location is empty, meets mass/volume limits, and not in used locations
                    if (warehouse[x, y, z] == 0 and
                            task.mass <= mass_limits[x, y, z] and
                            task.volume <= volume_limits[x, y, z] and
                            location_key not in used_locations):
                        # Calculate LMD value
                        lmd_value = (mass_limits[x, y, z] / task.mass) * (volume_limits[x, y, z] / task.volume)
                        # Determine zone for this location
                        location_zone = Task._determine_zone(x, y, z)
                        valid_locations.append((x, y, z, lmd_value, location_zone))

        if valid_locations:
            # Randomly select one from all valid empty locations
            selected_candidate = random.choice(valid_locations)
            x, y, z, lmd, zone = selected_candidate
            return {
                'strategy': 'Warehouse-wide Random Storage',
                'selected_location': (x, y, z),
                'lmd_value': lmd,
                'z_coordinate': z,
                'assigned_zone': zone,  # Record actually assigned zone
                'reason': f'Randomly selected location ({x},{y},{z}) from {len(valid_locations)} valid empty locations across warehouse, assigned to {zone}'
            }
        else:
            return {
                'strategy': 'Warehouse-wide Random Storage',
                'selected_location': None,
                'reason': 'No valid empty locations found across entire warehouse'
            }


import random

# 5 Outbound Strategies Class - Complete Implementation
class OutboundStrategy:
    """Outbound Strategy Class - Implements 5 different strategies for selecting outbound storage locations"""

    @staticmethod
    def strategy_1_shortest_distance(inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape,
                                     occupied_items=None):
        """Strategy 1: Shortest Distance Principle - Select nearest non-empty location in the same aisle and floor as inbound task"""
        if not inbound_task.selected_location:
            return None

        target_x, target_y, target_z = inbound_task.selected_location
        available_locations = []

        # Find non-empty locations in the same aisle and floor
        for y in range(1, warehouse_shape[1] + 1):
            if (warehouse[target_x, y, target_z] == 1 and  # Non-empty location
                    (target_x, y, target_z) != inbound_task.selected_location):  # Not the inbound location itself
                distance = abs(y - target_y)  # Distance based on y-coordinate
                available_locations.append(((target_x, y, target_z), distance))

        if available_locations:
            # Select location with shortest distance
            available_locations.sort(key=lambda x: x[1])
            selected_location = available_locations[0][0]

            # Create outbound task
            outbound_task = OutboundTask(
                f"out_{inbound_task.task_id.split('_')[1]}",
                selected_location,
                warehouse_shape
            )

            # Set item properties
            x, y, z = selected_location
            if occupied_items and selected_location in occupied_items:
                item_info = occupied_items[selected_location]
                outbound_task.set_item_properties(item_info['mass'], item_info['volume'], item_info['frequency'])
            else:
                outbound_task.set_item_properties(
                    round(random.uniform(1, 25), 2),
                    round(random.uniform(1, 30), 2),
                    random.randint(1, 30)
                )

            outbound_task.calculate_lmd(mass_limits, volume_limits)

            return outbound_task
        else:
            return None

    @staticmethod
    def strategy_2_lmd_similarity(inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape,
                                  occupied_items=None):
        """Strategy 2: LMD Similarity Principle - Select non-empty location with smallest absolute LMD difference in the same zone"""
        if not inbound_task.selected_location:
            return None

        inbound_zone = inbound_task.zone
        target_x, target_y, target_z = inbound_task.selected_location

        # Calculate LMD value for inbound location
        inbound_lmd = (mass_limits[target_x, target_y, target_z] / inbound_task.mass) * \
                      (volume_limits[target_x, target_y, target_z] / inbound_task.volume)

        available_locations = []

        # Find non-empty locations in the same zone
        for x in range(1, warehouse_shape[0] + 1):
            for y in range(1, warehouse_shape[1] + 1):
                for z in range(1, warehouse_shape[2] + 1):
                    location = (x, y, z)
                    if (Task._determine_zone(x, y, z) == inbound_zone and
                            warehouse[x, y, z] == 1 and  # Non-empty location
                            location != inbound_task.selected_location and  # Not the inbound location itself
                            location in occupied_items):  # Ensure item information exists

                        # Calculate LMD value for this location
                        item_info = occupied_items[location]
                        outbound_lmd = (mass_limits[x, y, z] / item_info['mass']) * \
                                       (volume_limits[x, y, z] / item_info['volume'])

                        # Calculate LMD difference
                        lmd_diff = abs(outbound_lmd - inbound_lmd)
                        available_locations.append((location, lmd_diff, outbound_lmd))

        if available_locations:
            # Select location with smallest LMD difference
            available_locations.sort(key=lambda x: x[1])
            selected_location, min_lmd_diff, selected_lmd = available_locations[0]

            # Create outbound task
            outbound_task = OutboundTask(
                f"out_{inbound_task.task_id.split('_')[1]}",
                selected_location,
                warehouse_shape
            )

            # Set item properties
            item_info = occupied_items[selected_location]
            outbound_task.set_item_properties(item_info['mass'], item_info['volume'], item_info['frequency'])
            outbound_task.calculate_lmd(mass_limits, volume_limits)

            return outbound_task
        else:
            return None

    @staticmethod
    def strategy_3_random_selection(inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape,
                                    occupied_items=None):
        """Strategy 3: Random Selection - Randomly select a non-empty location in the same zone"""
        if not inbound_task.selected_location:
            return None

        inbound_zone = inbound_task.zone
        available_locations = []

        # Find non-empty locations in the same zone
        for x in range(1, warehouse_shape[0] + 1):
            for y in range(1, warehouse_shape[1] + 1):
                for z in range(1, warehouse_shape[2] + 1):
                    location = (x, y, z)
                    if (Task._determine_zone(x, y, z) == inbound_zone and
                            warehouse[x, y, z] == 1 and  # Non-empty location
                            location != inbound_task.selected_location):  # Not the inbound location itself
                        available_locations.append(location)

        if available_locations:
            # Randomly select a location
            selected_location = random.choice(available_locations)

            # Create outbound task
            outbound_task = OutboundTask(
                f"out_{inbound_task.task_id.split('_')[1]}",
                selected_location,
                warehouse_shape
            )

            # Set item properties
            if occupied_items and selected_location in occupied_items:
                item_info = occupied_items[selected_location]
                outbound_task.set_item_properties(item_info['mass'], item_info['volume'], item_info['frequency'])
            else:
                outbound_task.set_item_properties(
                    round(random.uniform(1, 25), 2),
                    round(random.uniform(1, 30), 2),
                    random.randint(1, 30)
                )

            outbound_task.calculate_lmd(mass_limits, volume_limits)

            return outbound_task
        else:
            return None

    @staticmethod
    def strategy_4_highest_frequency(inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape,
                                     occupied_items=None):
        """Strategy 4: Inbound/Outbound Frequency Priority - Prioritize location with highest inbound/outbound frequency"""
        if not inbound_task.selected_location:
            return None

        inbound_zone = inbound_task.zone
        available_locations = []

        # Find non-empty locations in the same zone
        for x in range(1, warehouse_shape[0] + 1):
            for y in range(1, warehouse_shape[1] + 1):
                for z in range(1, warehouse_shape[2] + 1):
                    location = (x, y, z)
                    if (Task._determine_zone(x, y, z) == inbound_zone and
                            warehouse[x, y, z] == 1 and  # Non-empty location
                            location != inbound_task.selected_location and  # Not the inbound location itself
                            location in occupied_items):  # Ensure item information exists

                        item_info = occupied_items[location]
                        frequency = item_info['frequency']
                        available_locations.append((location, frequency))

        if available_locations:
            # Sort by frequency in descending order
            available_locations.sort(key=lambda x: x[1], reverse=True)
            max_frequency = available_locations[0][1]

            # Find all locations with highest frequency
            highest_freq_locations = [loc for loc, freq in available_locations if freq == max_frequency]

            # Randomly select one if multiple locations have the same highest frequency
            selected_location = random.choice(highest_freq_locations)

            # Create outbound task
            outbound_task = OutboundTask(
                f"out_{inbound_task.task_id.split('_')[1]}",
                selected_location,
                warehouse_shape
            )

            # Set item properties
            item_info = occupied_items[selected_location]
            outbound_task.set_item_properties(item_info['mass'], item_info['volume'], item_info['frequency'])
            outbound_task.calculate_lmd(mass_limits, volume_limits)

            return outbound_task
        else:
            return None

    import math
    import random

    @staticmethod
    def strategy_5_lmd_distance_combined(inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape,
                                         occupied_items=None):
        """Strategy 5: Combined Strategy (Strategy 2 + Strategy 1) - First select top 5 locations with closest LMD values, then choose the shortest distance"""
        if not inbound_task.selected_location:
            return None

        inbound_zone = inbound_task.zone
        target_x, target_y, target_z = inbound_task.selected_location

        # Calculate LMD value for inbound location
        inbound_lmd = (mass_limits[target_x, target_y, target_z] / inbound_task.mass) * \
                      (volume_limits[target_x, target_y, target_z] / inbound_task.volume)

        available_locations = []

        # Find non-empty locations in the same zone
        for x in range(1, warehouse_shape[0] + 1):
            for y in range(1, warehouse_shape[1] + 1):
                for z in range(1, warehouse_shape[2] + 1):
                    location = (x, y, z)
                    if (Task._determine_zone(x, y, z) == inbound_zone and
                            warehouse[x, y, z] == 1 and  # Non-empty location
                            location != inbound_task.selected_location and  # Not the inbound location itself
                            location in occupied_items):  # Ensure item information exists

                        # Calculate LMD value for this location
                        item_info = occupied_items[location]
                        outbound_lmd = (mass_limits[x, y, z] / item_info['mass']) * \
                                       (volume_limits[x, y, z] / item_info['volume'])

                        # Calculate LMD difference and Euclidean distance
                        lmd_diff = abs(outbound_lmd - inbound_lmd)
                        distance = math.sqrt((x - target_x) ** 2 + (y - target_y) ** 2 + (z - target_z) ** 2)

                        available_locations.append((location, lmd_diff, distance, outbound_lmd))

        if available_locations:
            # Step 1: Sort by LMD difference, select top 5 (or all if fewer than 5)
            available_locations.sort(key=lambda x: x[1])
            top_5_lmd = available_locations[:5]

            # Step 2: Select shortest distance from top 5
            top_5_lmd.sort(key=lambda x: x[2])
            selected_location, lmd_diff, min_distance, selected_lmd = top_5_lmd[0]

            # Create outbound task
            outbound_task = OutboundTask(
                f"out_{inbound_task.task_id.split('_')[1]}",
                selected_location,
                warehouse_shape
            )

            # Set item properties
            item_info = occupied_items[selected_location]
            outbound_task.set_item_properties(item_info['mass'], item_info['volume'], item_info['frequency'])
            outbound_task.calculate_lmd(mass_limits, volume_limits)

            return outbound_task
        else:
            return None

    @staticmethod
    def select_outbound_location(inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape,
                                 occupied_items=None, strategy_name="strategy_1"):
        """Select outbound location based on strategy name"""
        strategy_functions = {
            "strategy_1": OutboundStrategy.strategy_1_shortest_distance,
            "strategy_2": OutboundStrategy.strategy_2_lmd_similarity,
            "strategy_3": OutboundStrategy.strategy_3_random_selection,
            "strategy_4": OutboundStrategy.strategy_4_highest_frequency,
            "strategy_5": OutboundStrategy.strategy_5_lmd_distance_combined
        }

        if strategy_name in strategy_functions:
            return strategy_functions[strategy_name](
                inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape, occupied_items
            )
        else:
            return OutboundStrategy.strategy_1_shortest_distance(
                inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape, occupied_items
            )


# Function to create transfer shuttles
def create_transfer_shuttles(motion_calculator):
    """Create 14 transfer shuttles, responsible for levels 1-14 respectively"""
    transfer_shuttles = {}

    for level in range(1, 15):  # Levels 1 to 14
        transfer_shuttle = TransferShuttle(
            transfer_id=level,
            assigned_level=level,
            motion_calculator=motion_calculator
        )
        transfer_shuttles[level] = transfer_shuttle

    return transfer_shuttles


# Function to create elevators
def create_elevators(motion_calculator):
    """Create 3 elevators, located at x=1, 8, 16 positions respectively"""
    elevators = {}

    elevator_positions = [1, 8, 16]
    for i, x_pos in enumerate(elevator_positions, 1):
        elevator = Elevator(
            elevator_id=i,
            initial_x=x_pos,
            motion_calculator=motion_calculator
        )
        elevators[i] = elevator

    return elevators

# Modified Task Scheduler Strategy: Supports transfer shuttle and elevator collaboration with integrated reward function
class ModifiedEnhancedTaskScheduler:
    """Modified Enhanced Task Scheduler - Supports transfer shuttle & elevator collaboration, I/O point processes, and integrated reward function"""

    def __init__(self, time_manager, equipment_coordinator, task_selection_strategy="strategy_1", reward_function=None):
        self.time_manager = time_manager
        self.equipment_coordinator = equipment_coordinator
        self.task_selection_strategy = task_selection_strategy
        self.zone_combined_tasks = {}
        self.zone_shuttles = {}
        self.assigned_tasks = set()
        self.completed_tasks = set()

        # Integrate reward function
        self.reward_function = reward_function or EnhancedWarehouseRewardFunction()
        self.state_extractor = WarehouseStateExtractor()
        self.reward_history = []  # System-wide reward history
        self.total_system_reward = 0.0  # Total system reward

    def _get_strategy_description(self):
        """Get strategy description"""
        descriptions = {
            "strategy_1": "Strategy 1: Priority based on remaining time (tasks with shorter remaining_time processed first)",
            "strategy_2": "Strategy 2: Shortest distance priority (tasks with smaller z-coordinate processed first)",
            "strategy_3": "Strategy 3: Random selection",
            "strategy_4": "Strategy 4: Remaining time + shortest distance priority (smaller z-coordinate when times are equal)"
        }
        return descriptions.get(self.task_selection_strategy, "Unknown Strategy")

    def add_combined_tasks_for_zone(self, zone, combined_tasks):
        """Add combined tasks for a specific zone"""
        if zone not in self.zone_combined_tasks:
            self.zone_combined_tasks[zone] = []
        self.zone_combined_tasks[zone].extend(combined_tasks)

    def add_shuttles_for_zone(self, zone, shuttles):
        """Add shuttles for a specific zone"""
        if zone not in self.zone_shuttles:
            self.zone_shuttles[zone] = []
        self.zone_shuttles[zone].extend(shuttles)

    def get_available_tasks_for_zone(self, zone):
        """Get available combined tasks in a specific zone"""
        if zone not in self.zone_combined_tasks:
            return []

        available_tasks = []
        for task in self.zone_combined_tasks[zone]:
            if (task.task_id not in self.assigned_tasks and
                    task.task_id not in self.completed_tasks):
                available_tasks.append(task)
        return available_tasks

    def _select_task_by_strategy(self, available_tasks):
        """Select task according to configured strategy"""
        if not available_tasks:
            return None

        if self.task_selection_strategy == "strategy_1":
            return self._select_task_by_remaining_time(available_tasks)
        elif self.task_selection_strategy == "strategy_2":
            return self._select_task_by_distance_priority(available_tasks)
        elif self.task_selection_strategy == "strategy_3":
            return self._select_task_randomly(available_tasks)
        elif self.task_selection_strategy == "strategy_4":
            return self._select_task_by_time_and_distance(available_tasks)
        else:
            return self._select_task_by_remaining_time(available_tasks)

    import random

    def _select_task_by_remaining_time(self, available_tasks):
        """Strategy 1: Select task based on remaining time"""
        tasks_with_time = [task for task in available_tasks
                           if hasattr(task.inbound_task, 'remaining_time') and
                           task.inbound_task.remaining_time is not None]

        if tasks_with_time:
            selected_task = min(tasks_with_time, key=lambda t: t.inbound_task.remaining_time)
            return selected_task
        elif available_tasks:
            selected_task = random.choice(available_tasks)
            return selected_task
        return None

    def _select_task_by_distance_priority(self, available_tasks):
        """Strategy 2: Shortest distance priority"""
        tasks_with_location = [task for task in available_tasks
                               if task.inbound_task.selected_location is not None]

        if tasks_with_location:
            selected_task = min(tasks_with_location, key=lambda t: t.inbound_task.selected_location[2])
            return selected_task
        return None

    def _select_task_randomly(self, available_tasks):
        """Strategy 3: Random selection"""
        if available_tasks:
            selected_task = random.choice(available_tasks)
            return selected_task
        return None

    def _select_task_by_time_and_distance(self, available_tasks):
        """Strategy 4: Priority based on remaining time and shortest distance"""
        tasks_with_time = [task for task in available_tasks
                           if hasattr(task.inbound_task, 'remaining_time') and
                           task.inbound_task.remaining_time is not None and
                           task.inbound_task.selected_location is not None]

        if tasks_with_time:
            selected_task = min(tasks_with_time,
                                key=lambda t: (t.inbound_task.remaining_time,
                                               t.inbound_task.selected_location[2]))
            return selected_task
        elif available_tasks:
            return self._select_task_by_distance_priority(available_tasks)
        return None

    def assign_combined_task_to_shuttle(self, shuttle, combined_task):
        """Assign combined task to shuttle"""
        if combined_task.task_id not in self.assigned_tasks:
            # Update task remaining time based on shuttle's cumulative execution time
            original_remaining_time = getattr(combined_task.inbound_task, 'remaining_time', None)
            if original_remaining_time is not None:
                # Calculate dynamic remaining time: original remaining time - shuttle's cumulative execution time
                dynamic_remaining_time = max(0, original_remaining_time - shuttle.cumulative_execution_time)
                combined_task.inbound_task.dynamic_remaining_time = dynamic_remaining_time
            else:
                combined_task.inbound_task.dynamic_remaining_time = None

            self.assigned_tasks.add(combined_task.task_id)
            if shuttle.start_combined_task(combined_task, self.time_manager.get_current_time()):
                return True
        return False

    def assign_initial_tasks(self):
        """Assign initial tasks to shuttles in each zone"""
        for zone in self.zone_combined_tasks:
            if zone in self.zone_shuttles:
                available_tasks = self.get_available_tasks_for_zone(zone)
                shuttles = self.zone_shuttles[zone]

                for shuttle in shuttles:
                    if shuttle.status == "idle" and available_tasks:
                        selected_task = self._select_task_by_strategy(available_tasks)
                        if selected_task and self.assign_combined_task_to_shuttle(shuttle, selected_task):
                            available_tasks.remove(selected_task)

    def assign_next_task(self, shuttle):
        """Assign next task to shuttle that completed current task"""
        zone = shuttle.zone
        available_tasks = self.get_available_tasks_for_zone(zone)

        if available_tasks:
            selected_task = self._select_task_by_strategy(available_tasks)
            if selected_task and self.assign_combined_task_to_shuttle(shuttle, selected_task):
                return True
        return False

    def mark_task_completed(self, task_id):
        """Mark task as completed"""
        if task_id in self.assigned_tasks:
            self.assigned_tasks.remove(task_id)
        self.completed_tasks.add(task_id)

    def calculate_system_reward(self, current_time):
        """Calculate total system reward"""
        all_shuttles = []
        for zone_shuttles in self.zone_shuttles.values():
            all_shuttles.extend(zone_shuttles)

        # Extract system state information
        state_info = self.state_extractor.extract_state_info(
            all_shuttles,
            self.equipment_coordinator.transfer_shuttles,
            self.equipment_coordinator.elevators,
            current_time,
            self
        )

        # Calculate system reward
        system_reward = self.reward_function.calculate_total_reward(state_info)

        # Record reward history
        self.reward_history.append({
            'time': current_time,
            'reward': system_reward,
            'cumulative_reward': self.total_system_reward + system_reward
        })

        self.total_system_reward += system_reward
        return system_reward

    def update(self):
        """Update all equipment status and assign new tasks"""
        current_time = self.time_manager.get_current_time()

        # Update all equipment (transfer shuttles, elevators)
        self.equipment_coordinator.update_all_equipment(current_time)

        # Update shuttles
        for zone in self.zone_shuttles:
            for shuttle in self.zone_shuttles[zone]:
                previous_completed_count = len(shuttle.completed_combined_tasks)
                shuttle.update(current_time)

                # Mark newly completed tasks
                if len(shuttle.completed_combined_tasks) > previous_completed_count:
                    newly_completed_task = shuttle.completed_combined_tasks[-1]
                    self.mark_task_completed(newly_completed_task.task_id)

                # Assign next task if shuttle is idle and has no current task
                if shuttle.status == "idle" and shuttle.current_combined_task is None:
                    self.assign_next_task(shuttle)

    def is_all_tasks_completed(self):
        """Check if all tasks are completed"""
        total_tasks = 0
        for zone in self.zone_combined_tasks:
            total_tasks += len(self.zone_combined_tasks[zone])
        return len(self.completed_tasks) >= total_tasks

    def get_progress_summary(self):
        """Get progress summary"""
        progress = {}
        for zone in self.zone_combined_tasks:
            zone_tasks = self.zone_combined_tasks[zone]
            zone_completed = len([task for task in zone_tasks if task.task_id in self.completed_tasks])
            progress[zone] = {
                'total': len(zone_tasks),
                'completed': zone_completed,
                'assigned': len([task for task in zone_tasks if task.task_id in self.assigned_tasks]),
                'available': len([task for task in zone_tasks
                                  if task.task_id not in self.assigned_tasks and
                                  task.task_id not in self.completed_tasks])
            }
        return progress

    def get_reward_summary(self):
        """Get reward summary"""
        all_shuttles = []
        for zone_shuttles in self.zone_shuttles.values():
            all_shuttles.extend(zone_shuttles)

        shuttle_rewards = {shuttle.shuttle_id: shuttle.total_reward for shuttle in all_shuttles}

        return {
            'system_total_reward': self.total_system_reward,
            'shuttle_rewards': shuttle_rewards,
            'reward_history_length': len(self.reward_history)
        }


# ============================================================================
#                            Integrated Code: Warehouse RL Environment
# ============================================================================

class WarehouseRLEnvironment:
    """Warehouse System Reinforcement Learning Environment - Using DDPG Algorithm"""

    def __init__(self, task_data_path=r"C:\Users\hp\Desktop\DEC-MAPPO\MARL-code-pytorch-main\6.保存文件\2-python文件版本-以这份为主\storage_task_100.xlsx"):
        self.task_data_path = task_data_path
        self.warehouse_shape = warehouse_shape
        self.warehouse = warehouse
        self.mass_limits = mass_limits
        self.volume_limits = volume_limits
        self.occupied_items = occupied_items

        # Reward function
        self.reward_function = EnhancedWarehouseRewardFunction()
        self.state_extractor = WarehouseStateExtractor()

        # State dimension - simplified to single state vector
        self.state_dim = 19  # System state dimension

        # Current strategy configuration
        self.current_storage_strategy = "strategy_3"
        self.current_outbound_strategy = "strategy_1"
        self.current_task_selection_strategy = "strategy_1"

        # Environment state
        self.current_episode_reward = 0.0
        self.episode_count = 0

        # ===== Task cache related attributes =====
        self.cached_tasks = None  # Cached task data
        self.cached_combined_tasks = None  # Cached combined tasks
        self.tasks_initialized = False  # Flag to mark if tasks are initialized

        # Initialize fixed tasks (execute only on first creation)
        self._initialize_fixed_tasks()

    def _initialize_fixed_tasks(self):
        """Initialize fixed task configuration (execute only once)"""
        if self.tasks_initialized:
            return

        print(f"\n=== Initializing Fixed Task Configuration ===")

        # Load task data
        task_data = load_tasks_from_excel(self.task_data_path)

        if task_data is None:
            print("Using simulated data")
            task_data = pd.DataFrame({
                'frequency': [random.randint(1, 30) for _ in range(30)],
                'volume': [round(random.uniform(1, 30), 2) for _ in range(30)],
                'weight': [round(random.uniform(1, 25), 2) for _ in range(30)],
                'remaining_time': [round(random.uniform(100, 200), 1) for _ in range(30)]
            })

        # Create task objects
        self.cached_tasks = []
        for i, row in task_data.iterrows():
            task_id = f"in_{i + 1}"
            task = Task(
                task_id=task_id,
                task_type="inbound",
                warehouse_shape=self.warehouse_shape,
                mass=row['weight'],
                volume=row['volume'],
                frequency=int(row['frequency']),
                remaining_time=row.get('remaining_time', None)
            )
            self.cached_tasks.append(task)

        print(f"Successfully cached {len(self.cached_tasks)} fixed tasks")

        # Perform clustering analysis once and cache results
        self._perform_clustering_once()

        # Generate fixed combined task configuration
        self._generate_fixed_combined_tasks()

        self.tasks_initialized = True
        print(f"Task configuration fixation completed, all subsequent episodes will use the same task configuration")

    def _perform_clustering_once(self):
        """Perform clustering analysis once and save results"""
        print("Performing fixed clustering analysis...")

        # Perform Gaussian Mixture Model clustering
        features = []
        for task in self.cached_tasks:
            features.append([task.mass, task.volume, task.frequency])

        features = np.array(features)
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features)

        n_clusters = 3
        # Set fixed random seed to ensure consistent clustering results
        gmm = GaussianMixture(n_components=n_clusters, random_state=42, covariance_type='full')
        cluster_labels = gmm.fit_predict(features_scaled)

        for i, task in enumerate(self.cached_tasks):
            task.cluster = cluster_labels[i]

        # Assign zones (using fixed assignment logic)
        cluster_stats = {}
        for cluster_id in range(n_clusters):
            cluster_tasks = [task for task in self.cached_tasks if task.cluster == cluster_id]
            if cluster_tasks:
                avg_frequency = np.mean([task.frequency for task in cluster_tasks])
                avg_mass = np.mean([task.mass for task in cluster_tasks])
                avg_volume = np.mean([task.volume for task in cluster_tasks])
                cluster_stats[cluster_id] = {
                    'avg_frequency': avg_frequency,
                    'avg_mass': avg_mass,
                    'avg_volume': avg_volume,
                    'task_count': len(cluster_tasks)
                }

        cluster_scores = []
        for cluster_id, stats in cluster_stats.items():
            max_freq = max([s['avg_frequency'] for s in cluster_stats.values()])
            min_freq = min([s['avg_frequency'] for s in cluster_stats.values()])
            max_mass = max([s['avg_mass'] for s in cluster_stats.values()])
            min_mass = min([s['avg_mass'] for s in cluster_stats.values()])

            norm_freq = (stats['avg_frequency'] - min_freq) / (max_freq - min_freq) if max_freq > min_freq else 0.5
            norm_mass = (stats['avg_mass'] - min_mass) / (max_mass - min_mass) if max_mass > min_mass else 0.5

            composite_score = 0.6 * norm_freq + 0.4 * norm_mass
            cluster_scores.append((cluster_id, composite_score, stats))

        cluster_scores.sort(key=lambda x: x[1], reverse=True)

        zone_names = ["Zone A", "Zone B", "Zone C"]
        cluster_to_zone = {}

        for i, (cluster_id, score, stats) in enumerate(cluster_scores):
            zone = zone_names[i] if i < len(zone_names) else "Zone C"
            cluster_to_zone[cluster_id] = zone

        for task in self.cached_tasks:
            task.zone = cluster_to_zone[task.cluster]

        print("Clustering analysis completed, zone assignment results:")
        zone_counts = {}
        for task in self.cached_tasks:
            zone_counts[task.zone] = zone_counts.get(task.zone, 0) + 1
        for zone, count in zone_counts.items():
            print(f"  {zone}: {count} tasks")

    def _generate_fixed_combined_tasks(self):
        """Generate fixed combined task configuration"""
        print("Generating fixed combined task configuration...")

        # Use fixed random seed to ensure the same combined tasks are generated each time
        original_random_state = random.getstate()
        random.seed(42)  # Fixed seed

        try:
            self.cached_combined_tasks = {}

            # Pre-generate combined tasks for each strategy combination
            storage_strategies = ["strategy_1", "strategy_2", "strategy_3"]
            outbound_strategies = ["strategy_1", "strategy_2", "strategy_3", "strategy_4", "strategy_5"]

            for storage_strategy in storage_strategies:
                for outbound_strategy in outbound_strategies:
                    strategy_key = f"{storage_strategy}_{outbound_strategy}"
                    combined_tasks = self._generate_combined_tasks_for_strategy(storage_strategy, outbound_strategy)
                    self.cached_combined_tasks[strategy_key] = combined_tasks
                    print(f"  Strategy combination {strategy_key}: {len(combined_tasks)} combined tasks")

        finally:
            # Restore random state
            random.setstate(original_random_state)

    def _generate_combined_tasks_for_strategy(self, storage_strategy, outbound_strategy):
        """Generate combined tasks for specific strategy combination"""
        # Deep copy tasks to avoid modifying original cache
        import copy
        tasks_copy = copy.deepcopy(self.cached_tasks)

        used_locations = set()
        combined_tasks = []

        # Assign storage locations for inbound tasks
        for task in tasks_copy:
            zone = task.zone
            task_allocated = False

            if storage_strategy == "strategy_1":
                strategy_result = StorageStrategy.strategy_1_random_storage(
                    task, self.warehouse, self.mass_limits, self.volume_limits, zone, used_locations)
                task.selected_location = strategy_result['selected_location']
                task.storage_strategy_result = strategy_result
                if task.selected_location:
                    task_allocated = True
                    used_locations.add(task.selected_location)

                if not task_allocated:
                    warehouse_wide_result = StorageStrategy.strategy_warehouse_wide_random(
                        task, self.warehouse, self.mass_limits, self.volume_limits, used_locations)
                    task.selected_location = warehouse_wide_result['selected_location']
                    task.storage_strategy_result = warehouse_wide_result
                    task.storage_strategy_result['original_strategy'] = 'strategy_1'
                    task.storage_strategy_result['warehouse_wide_fallback'] = True

                    if task.selected_location:
                        task_allocated = True
                        used_locations.add(task.selected_location)
                        original_zone = task.zone
                        actual_zone = warehouse_wide_result.get('assigned_zone', task.zone)
                        task.zone = actual_zone

            elif storage_strategy == "strategy_2":
                success = task.find_candidate_locations_in_zone(
                    self.warehouse, self.mass_limits, self.volume_limits, zone, used_locations)
                if success:
                    strategy_result = StorageStrategy.strategy_2_highest_lmd(task)
                    task.selected_location = strategy_result['selected_location']
                    task.storage_strategy_result = strategy_result
                    if task.selected_location:
                        task_allocated = True
                        used_locations.add(task.selected_location)

                if not task_allocated:
                    fallback_result = StorageStrategy.strategy_1_random_storage(
                        task, self.warehouse, self.mass_limits, self.volume_limits, zone, used_locations)
                    task.selected_location = fallback_result['selected_location']
                    task.storage_strategy_result = fallback_result
                    if task.selected_location:
                        task_allocated = True
                        used_locations.add(task.selected_location)

                if not task_allocated:
                    warehouse_wide_result = StorageStrategy.strategy_warehouse_wide_random(
                        task, self.warehouse, self.mass_limits, self.volume_limits, used_locations)
                    task.selected_location = warehouse_wide_result['selected_location']
                    task.storage_strategy_result = warehouse_wide_result
                    task.storage_strategy_result['original_strategy'] = 'strategy_2'
                    task.storage_strategy_result['warehouse_wide_fallback'] = True

                    if task.selected_location:
                        task_allocated = True
                        used_locations.add(task.selected_location)
                        original_zone = task.zone
                        actual_zone = warehouse_wide_result.get('assigned_zone', task.zone)
                        task.zone = actual_zone

            elif storage_strategy == "strategy_3":
                success = task.find_candidate_locations_in_zone(
                    self.warehouse, self.mass_limits, self.volume_limits, zone, used_locations)
                if success:
                    strategy_result = StorageStrategy.strategy_3_lmd_with_z_priority(task)
                    task.selected_location = strategy_result['selected_location']
                    task.storage_strategy_result = strategy_result
                    if task.selected_location:
                        task_allocated = True
                        used_locations.add(task.selected_location)

                if not task_allocated:
                    backup_strategies = ["strategy_1", "strategy_2"]
                    random.shuffle(backup_strategies)

                    for backup_strategy in backup_strategies:
                        if backup_strategy == "strategy_1":
                            fallback_result = StorageStrategy.strategy_1_random_storage(
                                task, self.warehouse, self.mass_limits, self.volume_limits, zone, used_locations)
                            task.selected_location = fallback_result['selected_location']
                            task.storage_strategy_result = fallback_result
                            task.storage_strategy_result['original_strategy'] = 'strategy_3'
                            task.storage_strategy_result['fallback_strategy'] = 'strategy_1'

                            if task.selected_location:
                                task_allocated = True
                                used_locations.add(task.selected_location)
                                break

                        elif backup_strategy == "strategy_2":
                            success = task.find_candidate_locations_in_zone(
                                self.warehouse, self.mass_limits, self.volume_limits, zone, used_locations)
                            if success:
                                fallback_result = StorageStrategy.strategy_2_highest_lmd(task)
                                task.selected_location = fallback_result['selected_location']
                                task.storage_strategy_result = fallback_result
                                task.storage_strategy_result['original_strategy'] = 'strategy_3'
                                task.storage_strategy_result['fallback_strategy'] = 'strategy_2'

                                if task.selected_location:
                                    task_allocated = True
                                    used_locations.add(task.selected_location)
                                    break

                    if not task_allocated:
                        warehouse_wide_result = StorageStrategy.strategy_warehouse_wide_random(
                            task, self.warehouse, self.mass_limits, self.volume_limits, used_locations)
                        task.selected_location = warehouse_wide_result['selected_location']
                        task.storage_strategy_result = warehouse_wide_result
                        task.storage_strategy_result['original_strategy'] = 'strategy_3'
                        task.storage_strategy_result['final_warehouse_wide'] = True

                        if task.selected_location:
                            task_allocated = True
                            used_locations.add(task.selected_location)
                            original_zone = task.zone
                            actual_zone = warehouse_wide_result.get('assigned_zone', task.zone)
                            task.zone = actual_zone

        # Generate outbound tasks
        for task in tasks_copy:
            if task.selected_location:
                outbound_task = OutboundStrategy.select_outbound_location(
                    task, self.warehouse, self.mass_limits, self.volume_limits,
                    self.warehouse_shape, self.occupied_items, outbound_strategy)

                if outbound_task:
                    combined_task = CombinedTask(
                        f"combined_{task.task_id.split('_')[1]}",
                        task, outbound_task, outbound_strategy)
                    combined_tasks.append(combined_task)

        return combined_tasks

    def reset(self):
        """Reset environment - use cached fixed tasks"""
        self.episode_count += 1
        self.current_episode_reward = 0.0

        print(f"\n=== Episode {self.episode_count}: Using fixed task configuration ===")

        # Use cached tasks and get corresponding combined tasks based on current strategy
        strategy_key = f"{self.current_storage_strategy}_{self.current_outbound_strategy}"

        if strategy_key in self.cached_combined_tasks:
            # Deep copy to avoid modifying cache
            import copy
            self.combined_tasks = copy.deepcopy(self.cached_combined_tasks[strategy_key])
        else:
            # If no pre-generated combined tasks, use default combination
            default_key = "strategy_3_strategy_1"
            if default_key in self.cached_combined_tasks:
                import copy
                self.combined_tasks = copy.deepcopy(self.cached_combined_tasks[default_key])
            else:
                # Final fallback measure
                self.combined_tasks = []

        print(f"Using strategy combination {strategy_key}, loaded {len(self.combined_tasks)} combined tasks")

        # Create warehouse system equipment (this part remains dynamically created)
        self.create_equipment()

        # New: Reset reward function cache
        if hasattr(self, 'enhanced_reward_function'):
            self.enhanced_reward_function.reset_episode_cache()

        # Return initial state
        state = self.get_state()
        return state

    def create_equipment(self):
        """Create warehouse equipment"""
        # Create time manager and motion calculator
        self.time_manager = TimeManager()
        self.motion_calculator = MotionCalculator(
            shuttle_velocity=4.0,
            transfer_velocity=3.0,
            elevator_velocity=4.0,
            shuttle_acceleration=2.0,
            transfer_acceleration=2.0,
            elevator_acceleration=3.0,
            # Physical dimension parameters
            aisle_width=0.6,  # Aisle width: 0.6 meters
            shelf_spacing=0.8,  # Shelf spacing: 0.8 meters
            floor_height=1.2,  # Floor height: 1.2 meters
            shuttle_depth=0.6  # Shuttle depth: 0.6 meters
        )

        # Create transfer shuttles and elevators
        self.transfer_shuttles = create_transfer_shuttles(self.motion_calculator)
        self.elevators = create_elevators(self.motion_calculator)
        self.equipment_coordinator = EquipmentCoordinator(self.transfer_shuttles, self.elevators)

        # Create shuttles
        self.shuttles = []
        shuttle_id = 0

        # Group tasks by zone
        zone_combined_tasks = {}
        for combined_task in self.combined_tasks:
            zone = combined_task.zone
            if zone not in zone_combined_tasks:
                zone_combined_tasks[zone] = []
            zone_combined_tasks[zone].append(combined_task)

        # Count tasks in each zone and allocate shuttles
        zone_task_counts = {}
        for zone, tasks in zone_combined_tasks.items():
            zone_task_counts[zone] = len(tasks)

        total_shuttles = 10
        total_valid_tasks = sum(zone_task_counts.values())

        if total_valid_tasks > 0:
            zone_task_proportions = {
                zone: count / total_valid_tasks
                for zone, count in zone_task_counts.items()
            }
            zone_shuttle_counts = {
                zone: max(1, int(round(proportion * total_shuttles)))
                for zone, proportion in zone_task_proportions.items()
            }

            # Adjust allocation to ensure total matches
            current_total = sum(zone_shuttle_counts.values())
            if current_total != total_shuttles:
                adjustment = total_shuttles - current_total
                sorted_zones = sorted(zone_shuttle_counts.items(), key=lambda x: zone_task_counts[x[0]], reverse=True)
                for zone, count in sorted_zones:
                    if adjustment == 0:
                        break
                    if adjustment > 0:
                        zone_shuttle_counts[zone] += 1
                        adjustment -= 1
                    elif count > 1:
                        zone_shuttle_counts[zone] -= 1
                        adjustment += 1

        # Create shuttles
        for zone in ["Zone A", "Zone B", "Zone C"]:
            count = zone_shuttle_counts.get(zone, 0)
            for i in range(count):
                try:
                    shuttle = ModifiedEnhancedShuttle(
                        shuttle_id, self.warehouse_shape, zone,
                        self.motion_calculator, self.equipment_coordinator, self.reward_function)
                    self.shuttles.append(shuttle)
                    shuttle_id += 1
                except ValueError as e:
                    print(f"Failed to create shuttle: {e}")

        # Create task scheduler
        self.scheduler = ModifiedEnhancedTaskScheduler(
            self.time_manager, self.equipment_coordinator,
            self.current_task_selection_strategy, self.reward_function)

        # Add combined tasks and shuttles to scheduler
        zone_shuttles = {}
        for shuttle in self.shuttles:
            if shuttle.zone not in zone_shuttles:
                zone_shuttles[shuttle.zone] = []
            zone_shuttles[shuttle.zone].append(shuttle)
            self.scheduler.add_shuttles_for_zone(shuttle.zone, [shuttle])

        for zone, tasks in zone_combined_tasks.items():
            self.scheduler.add_combined_tasks_for_zone(zone, tasks)

        # Assign initial tasks
        self.scheduler.assign_initial_tasks()

    def get_state(self):
        """Get current environment state"""
        if not hasattr(self, 'scheduler'):
            # If scheduler not created yet, return zero state
            return np.zeros(self.state_dim)

        # Extract state information
        current_time = self.time_manager.get_current_time()
        state_info = self.state_extractor.extract_state_info(
            self.shuttles, self.transfer_shuttles, self.elevators, current_time, self.scheduler)

        # Build state vector
        state_vector = [
            # Time-related features (2 dimensions)
            current_time / 1000.0,  # Normalized current time
            state_info.get('completed_task_count', 0) / max(state_info.get('total_tasks', 1), 1),  # Completion rate

            # Equipment load features (6 dimensions)
            np.mean(state_info.get('equipment_loads', {}).get('shuttles', [0])),
            np.mean(state_info.get('equipment_loads', {}).get('transfer_shuttles', [0])),
            np.mean(state_info.get('equipment_loads', {}).get('elevators', [0])),
            np.var(state_info.get('equipment_loads', {}).get('shuttles', [0])),
            np.var(state_info.get('equipment_loads', {}).get('transfer_shuttles', [0])),
            np.var(state_info.get('equipment_loads', {}).get('elevators', [0])),

            # Distance and time efficiency (2 dimensions)
            state_info.get('total_distance', 0) / 10000.0,  # Normalized total distance
            state_info.get('total_working_time', 0) / 1000.0,  # Normalized working time

            # Idle time and conflicts (3 dimensions)
            state_info.get('idle_time', 0) / 100.0,  # Normalized idle time
            state_info.get('deadline_violations', 0) / 10.0,  # Normalized violation count
            state_info.get('equipment_conflicts', 0) / 10.0,  # Normalized conflict count

            # Completion status per zone (3 dimensions)
            self._get_zone_completion_rate("Zone A"),
            self._get_zone_completion_rate("Zone B"),
            self._get_zone_completion_rate("Zone C"),

            # Shuttle status (2 dimensions)
            len([s for s in self.shuttles if s.status == "idle"]) / max(len(self.shuttles), 1),  # Idle shuttle ratio
            len([s for s in self.shuttles if s.status != "idle"]) / max(len(self.shuttles), 1),  # Working shuttle ratio

            # Overall performance indicator (1 dimension)
            len(self.scheduler.completed_tasks) / max(len(self.combined_tasks), 1)  # Total completion rate
        ]

        # Ensure state vector has correct length
        state_vector = state_vector[:self.state_dim]
        while len(state_vector) < self.state_dim:
            state_vector.append(0.0)

        return np.array(state_vector, dtype=np.float32)

    def _get_zone_completion_rate(self, zone):
        """Get completion rate for specific zone"""
        zone_tasks = [task for task in self.combined_tasks if task.zone == zone]
        zone_completed = len([task for task in zone_tasks if task.task_id in self.scheduler.completed_tasks])
        return zone_completed / max(len(zone_tasks), 1)

    def step(self, action):
        """Environment step - integrate enhanced reward mechanism"""
        # Keep original action processing code...
        storage_idx = int((action[0] + 1) * 3 / 2)
        storage_idx = min(storage_idx, 2)
        outbound_idx = int((action[1] + 1) * 5 / 2)
        outbound_idx = min(outbound_idx, 4)
        task_idx = int((action[2] + 1) * 4 / 2)
        task_idx = min(task_idx, 3)

        storage_strategies = ["strategy_1", "strategy_2", "strategy_3"]
        outbound_strategies = ["strategy_1", "strategy_2", "strategy_3", "strategy_4", "strategy_5"]
        task_selection_strategies = ["strategy_1", "strategy_2", "strategy_3", "strategy_4"]

        storage_strategy = storage_strategies[storage_idx]
        outbound_strategy = outbound_strategies[outbound_idx]
        task_selection_strategy = task_selection_strategies[task_idx]

        self.current_storage_strategy = storage_strategy
        self.current_outbound_strategy = outbound_strategy
        self.current_task_selection_strategy = task_selection_strategy

        if hasattr(self, 'scheduler'):
            self.scheduler.task_selection_strategy = task_selection_strategy

        # Record previous state
        prev_state_info = None
        if hasattr(self, 'scheduler'):
            prev_state_info = self.state_extractor.extract_state_info(
                self.shuttles, self.transfer_shuttles, self.elevators,
                self.time_manager.get_current_time(), self.scheduler)

        prev_completed = len(self.scheduler.completed_tasks) if hasattr(self, 'scheduler') else 0
        prev_time = self.time_manager.get_current_time()

        # Run simulation steps
        simulation_steps = 50
        for _ in range(simulation_steps):
            if hasattr(self, 'scheduler'):
                self.scheduler.update()
                self.time_manager.advance_time(0.1)

            if hasattr(self, 'scheduler') and self.scheduler.is_all_tasks_completed():
                break

        # Get current state information
        current_time = self.time_manager.get_current_time()
        current_state_info = self.state_extractor.extract_state_info(
            self.shuttles, self.transfer_shuttles, self.elevators, current_time, self.scheduler)

        # Collect detailed shuttle information for reward calculation
        shuttles_info = []
        if hasattr(self, 'shuttles'):
            for shuttle in self.shuttles:
                if hasattr(shuttle, 'get_shuttle_info_for_reward'):
                    shuttles_info.append(shuttle.get_shuttle_info_for_reward())

        # Get current state vector
        current_state_vector = self.get_state()

        # Calculate reward using enhanced reward function
        if not hasattr(self, 'enhanced_reward_function'):
            self.enhanced_reward_function = EnhancedWarehouseRewardFunction()

        # Use new enhanced reward calculation method
        reward_components = self.enhanced_reward_function.calculate_enhanced_total_reward(
            state_info=current_state_info,
            prev_state_info=prev_state_info,
            shuttles_info=shuttles_info,
            state_vector=current_state_vector
        )

        # Total reward
        reward = reward_components['total']

        # Keep original additional reward logic...
        current_completed = len(self.scheduler.completed_tasks) if hasattr(self, 'scheduler') else 0
        time_elapsed = current_time - prev_time

        if current_completed > prev_completed:
            new_tasks_completed = current_completed - prev_completed
            if time_elapsed > 0:
                time_efficiency_per_task = 5.0 / max(time_elapsed / new_tasks_completed, 0.1)
                reward += time_efficiency_per_task * new_tasks_completed * 10

        if hasattr(self, 'scheduler'):
            total_tasks = sum(len(tasks) for tasks in self.scheduler.zone_combined_tasks.values())
            progress_ratio = current_completed / max(total_tasks, 1)
            progress_multiplier = 1 + progress_ratio * 2
            if time_elapsed > 0:
                time_step_reward = (5.0 - min(time_elapsed, 5.0)) * progress_multiplier
                reward += time_step_reward

        self.current_episode_reward += reward

        # Keep original termination judgment logic...
        done = (hasattr(self, 'scheduler') and self.scheduler.is_all_tasks_completed()) or \
               current_time > 5000.0

        if done and hasattr(self, 'scheduler') and self.scheduler.is_all_tasks_completed():
            completion_time_bonus = max(0, (3000.0 - current_time) / 3000.0) * 2000
            reward += completion_time_bonus
            print(f"All tasks completed! Total time: {current_time:.1f} seconds, time bonus: {completion_time_bonus:.1f}")

        next_state = self.get_state()

        # Optional: Record detailed reward breakdown information
        if hasattr(self, 'detailed_reward_logging') and self.detailed_reward_logging:
            print(f"Reward breakdown: {reward_components}")

        return next_state, reward, done


# ============================================================================
#                            DDPG Trainer and Main Program
# ============================================================================

class WarehouseDDPGTrainer:
    """Warehouse System DDPG Trainer"""

    def __init__(self, task_data_path=r"C:\Users\hp\Desktop\DEC-MAPPO\MARL-code-pytorch-main\6.保存文件\2-python文件版本-以这份为主\storage_task_100.xlsx", lr_actor=1e-4, lr_critic=1e-3):
        self.env = WarehouseRLEnvironment(task_data_path)
        self.env.detailed_reward_logging = True  # Add this line
        self.agent = WarehouseDDPG(
            state_dim=self.env.state_dim,
            lr_actor=lr_actor,
            lr_critic=lr_critic
        )

        # Training records
        self.episode_rewards = []
        self.episode_completion_rates = []
        self.strategy_usage = {
            'storage': {'strategy_1': 0, 'strategy_2': 0, 'strategy_3': 0},
            'outbound': {'strategy_1': 0, 'strategy_2': 0, 'strategy_3': 0, 'strategy_4': 0, 'strategy_5': 0},
            'task_selection': {'strategy_1': 0, 'strategy_2': 0, 'strategy_3': 0, 'strategy_4': 0}
        }

        # New: Gantt chart and iteration analysis data
        self.episode_task_data = []  # Detailed task data per episode
        self.episode_completion_times = []  # Total completion time per episode
        self.episode_task_counts = []  # Number of tasks per episode
        self.episode_efficiency_metrics = []  # Efficiency metrics per episode
        self.episode_waiting_data = []



    def train(self, episodes=200, update_freq=5):
        """DDPG Training"""
        print(f"\n=== Starting Warehouse System DDPG Reinforcement Learning Training ===")
        print(f"State dimension: {self.env.state_dim}")
        print(f"Action dimension: 3 (continuous strategy selection)")

        for episode in range(episodes):
            print(f"\n--- Episode {episode + 1}/{episodes} ---")

            # Reset environment
            state = self.env.reset()

            # Reset episode waiting time for all equipment
            if hasattr(self.env, 'shuttles'):
                for shuttle in self.env.shuttles:
                    shuttle.reset_episode_waiting_time()
            if hasattr(self.env, 'transfer_shuttles'):
                for transfer_shuttle in self.env.transfer_shuttles.values():
                    transfer_shuttle.reset_episode_waiting_time()
            if hasattr(self.env, 'elevators'):
                for elevator in self.env.elevators.values():
                    elevator.reset_episode_waiting_time()

            episode_reward = 0
            step_count = 0
            done = False
            episode_start_time = time.time()

            # Reset noise
            self.agent.noise.reset()

            while not done and step_count < 500:
                # Select action
                action, strategies = self.agent.select_action(state, add_noise=True)

                # Record strategy usage
                storage_strategy, outbound_strategy, task_selection_strategy = strategies
                self.strategy_usage['storage'][storage_strategy] += 1
                self.strategy_usage['outbound'][outbound_strategy] += 1
                self.strategy_usage['task_selection'][task_selection_strategy] += 1

                # Environment execution
                next_state, reward, done = self.env.step(action)

                # Store experience
                self.agent.store_transition(state, action, reward, next_state, done)

                # Training
                if len(self.agent.replay_buffer) > 1000:
                    actor_loss, critic_loss = self.agent.train()

                state = next_state
                episode_reward += reward
                step_count += 1

                if step_count % 50 == 0:
                    print(f"  Step {step_count}: Reward: {reward:.2f}")

            # Record episode information
            self.episode_rewards.append(episode_reward)

            # Collect task data
            episode_task_info = self._collect_episode_task_data(episode + 1)
            self.episode_task_data.append(episode_task_info)

            # Collect waiting time data
            episode_waiting_info = self._collect_episode_waiting_data(episode + 1)
            self.episode_waiting_data.append(episode_waiting_info)

            # Collect other statistical information
            total_completion_time = episode_task_info['total_simulation_time']
            task_count = episode_task_info['total_tasks']
            completion_rate = episode_task_info['completion_rate']

            self.episode_completion_times.append(total_completion_time)
            self.episode_task_counts.append(task_count)
            self.episode_completion_rates.append(completion_rate)

            # Calculate efficiency metrics
            efficiency_metrics = {
                'avg_task_time': total_completion_time / max(task_count, 1),
                'completion_rate': completion_rate,
                'total_distance': episode_task_info['total_distance'],
                'avg_distance_per_task': episode_task_info['total_distance'] / max(task_count, 1),
                'episode_duration': time.time() - episode_start_time
            }
            self.episode_efficiency_metrics.append(efficiency_metrics)

            print(f"Episode {episode + 1} completed:")
            print(f"  Total reward: {episode_reward:.2f}")
            print(f"  Completion rate: {completion_rate:.2%}")
            print(f"  Total simulation time: {total_completion_time:.1f} seconds")
            print(f"  Strategy combination: {strategies}")

        print(f"\n=== DDPG Training Completed ===")
        print(f"Average total reward: {np.mean(self.episode_rewards):.2f}")
        print(f"Average completion rate: {np.mean(self.episode_completion_rates):.2%}")
        print(f"Average completion time: {np.mean(self.episode_completion_times):.1f} seconds")

        return self.episode_rewards, self.episode_completion_rates

    def _collect_episode_task_data(self, episode_num):
        """Collect detailed task data for current episode"""
        episode_info = {
            'episode': episode_num,
            'tasks': [],
            'total_tasks': 0,
            'completed_tasks': 0,
            'total_simulation_time': 0,
            'total_distance': 0,
            'completion_rate': 0,
            'shuttles_data': []
        }

        if hasattr(self.env, 'scheduler') and hasattr(self.env, 'shuttles'):
            # Get total simulation time
            episode_info['total_simulation_time'] = self.env.time_manager.get_current_time()

            # Collect task execution data for all shuttles
            all_tasks = []
            total_distance = 0

            for shuttle in self.env.shuttles:
                shuttle_info = {
                    'shuttle_id': shuttle.shuttle_id,
                    'zone': shuttle.zone,
                    'completed_tasks': len(shuttle.completed_combined_tasks),
                    'total_distance': shuttle.total_distance_traveled,
                    'total_working_time': shuttle.total_working_time,
                    'tasks': []
                }

                total_distance += shuttle.total_distance_traveled

                # Collect all tasks for this shuttle
                for task_log in shuttle.task_execution_log:
                    task_info = {
                        'task_id': task_log['task_id'],
                        'shuttle_id': shuttle.shuttle_id,
                        'zone': shuttle.zone,
                        'start_time': task_log['start_time'],
                        'end_time': task_log['end_time'],
                        'duration': task_log['duration'],
                        'inbound_location': task_log.get('inbound_location'),
                        'outbound_location': task_log.get('outbound_location'),
                        'remaining_time': task_log.get('remaining_time'),
                        'storage_strategy': task_log.get('storage_strategy', 'unknown'),
                        'outbound_strategy': task_log.get('outbound_strategy', 'unknown')
                    }
                    shuttle_info['tasks'].append(task_info)
                    all_tasks.append(task_info)

                episode_info['shuttles_data'].append(shuttle_info)

            # Statistics for overall information
            episode_info['tasks'] = sorted(all_tasks, key=lambda x: x['start_time'])
            episode_info['total_tasks'] = len(self.env.combined_tasks) if hasattr(self.env, 'combined_tasks') else 0
            episode_info['completed_tasks'] = len(all_tasks)
            episode_info['total_distance'] = total_distance
            episode_info['completion_rate'] = episode_info['completed_tasks'] / max(episode_info['total_tasks'], 1)

        return episode_info

    def plot_training_results(self):
        """Plot training results"""
        # Modify layout to 2 rows and 3 columns to accommodate 5 subplots
        fig, axes = plt.subplots(2, 3, figsize=(18, 10))
        ax1, ax2, ax3 = axes[0]  # First row: reward curve, completion rate curve, empty space
        ax4, ax5, ax6 = axes[1]  # Second row: three strategy pie charts

        # Training reward curve (unchanged)
        episodes = range(1, len(self.episode_rewards) + 1)
        # Plot total reward curve directly, no longer calculate average step reward
        ax1.plot(episodes, self.episode_rewards, alpha=0.6, label='Total Reward')

        # Smoothed curve
        if len(self.episode_rewards) > 10:
            window_size = min(20, len(self.episode_rewards) // 5)
            smoothed_rewards = []
            for i in range(len(self.episode_rewards)):
                start = max(0, i - window_size + 1)
                smoothed_rewards.append(np.mean(self.episode_rewards[start:i + 1]))
            ax1.plot(episodes, smoothed_rewards, label='Smoothed Reward', linewidth=2)

        ax1.set_xlabel('Episode')
        ax1.set_ylabel('Cumulative Reward')
        ax1.set_title('DDPG Training Reward Curve')
        ax1.legend()
        ax1.grid(True)

        # Completion rate curve (unchanged)
        ax2.plot(episodes, self.episode_completion_rates, alpha=0.6, label='Episode Completion Rate')

        if len(self.episode_completion_rates) > 10:
            window_size = min(20, len(self.episode_completion_rates) // 5)
            smoothed_completion = []
            for i in range(len(self.episode_completion_rates)):
                start = max(0, i - window_size + 1)
                smoothed_completion.append(np.mean(self.episode_completion_rates[start:i + 1]))
            ax2.plot(episodes, smoothed_completion, label='Smoothed Completion Rate', linewidth=2)

        ax2.set_xlabel('Episode')
        ax2.set_ylabel('Task Completion Rate')
        ax2.set_title('Task Completion Rate Curve')
        ax2.legend()
        ax2.grid(True)

        # Hide the third subplot in the first row
        ax3.axis('off')

        # Strategy usage distribution - storage strategy (moved to ax4)
        storage_labels = list(self.strategy_usage['storage'].keys())
        storage_values = list(self.strategy_usage['storage'].values())
        ax4.pie(storage_values, labels=storage_labels, autopct='%1.1f%%', startangle=90)
        ax4.set_title('Storage Strategy Usage Distribution')

        # Strategy usage distribution - outbound strategy (moved to ax5)
        outbound_labels = list(self.strategy_usage['outbound'].keys())
        outbound_values = list(self.strategy_usage['outbound'].values())
        ax5.pie(outbound_values, labels=outbound_labels, autopct='%1.1f%%', startangle=90)
        ax5.set_title('Outbound Strategy Usage Distribution')

        # New: Strategy usage distribution - task selection strategy (added to ax6)
        task_selection_labels = list(self.strategy_usage['task_selection'].keys())
        task_selection_values = list(self.strategy_usage['task_selection'].values())
        ax6.pie(task_selection_values, labels=task_selection_labels, autopct='%1.1f%%', startangle=90)
        ax6.set_title('Task Selection Strategy Usage Distribution')

        plt.tight_layout()

        # Save as PNG file
        current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"DDPG_Training_Reward_Curve_{current_time}.png"
        filepath = get_output_path(filename)
        plt.savefig(filepath, dpi=1200, bbox_inches='tight', format='png')
        plt.draw()
        plt.close()
        print(f"Training results plot saved as: {filename}")

    def evaluate(self, num_episodes=10):
        """Evaluate trained agent"""
        print(f"\n=== Evaluating Trained DDPG Agent ===")

        evaluation_rewards = []
        evaluation_completion_rates = []
        evaluation_completion_times = []

        for episode in range(num_episodes):
            print(f"\nEvaluation Episode {episode + 1}/{num_episodes}")

            # Reset environment
            state = self.env.reset()
            total_episode_reward = 0
            step_count = 0
            done = False

            while not done and step_count < 200:
                # Select action (without adding noise)
                action, strategies = self.agent.select_action(state, add_noise=False)

                # Environment execution
                next_state, reward, done = self.env.step(action)

                total_episode_reward += reward
                state = next_state
                step_count += 1

            evaluation_rewards.append(total_episode_reward)

            # Calculate completion rate and completion time
            if hasattr(self.env, 'scheduler'):
                progress = self.env.scheduler.get_progress_summary()
                total_completed = sum(zone_progress['completed'] for zone_progress in progress.values())
                total_tasks = sum(zone_progress['total'] for zone_progress in progress.values())
                completion_rate = total_completed / max(total_tasks, 1)
                completion_time = self.env.time_manager.get_current_time()

                evaluation_completion_rates.append(completion_rate)
                evaluation_completion_times.append(completion_time)
            else:
                evaluation_completion_rates.append(0.0)
                evaluation_completion_times.append(0.0)

            print(f"Evaluation Result: Total Reward={total_episode_reward:.2f}")
            print(f"Completion Rate={completion_rate:.2%}, Completion Time={completion_time:.1f} seconds")
            print(f"Final Strategy: {strategies}")

        print(f"\n=== Evaluation Results Summary ===")
        print(f"Average Total Reward: {np.mean(evaluation_rewards):.2f} ± {np.std(evaluation_rewards):.2f}")
        print(f"Average Completion Rate: {np.mean(evaluation_completion_rates):.2%} ± {np.std(evaluation_completion_rates):.2%}")
        print(
            f"Average Completion Time: {np.mean(evaluation_completion_times):.1f} ± {np.std(evaluation_completion_times):.1f} seconds")

        return evaluation_rewards, evaluation_completion_rates

    def save_model(self, filepath="ddpg_warehouse_model.pth"):
        """Save trained model"""
        full_filepath = get_output_path(filepath)
        self.agent.save_model(full_filepath)

    def load_model(self, filepath="ddpg_warehouse_model.pth"):
        """Load trained model"""
        self.agent.load_model(filepath)

    def plot_gantt_charts(self, episodes_to_plot=None, max_episodes=10):
        """Plot DDPG Gantt charts - show task completion status for specified episodes"""
        if not self.episode_task_data:
            print("No task data available for plotting")
            return

        # Initialize excel_data list
        excel_data = []

        # Select episodes to plot
        if episodes_to_plot is None:
            total_episodes = len(self.episode_task_data)
            if total_episodes <= max_episodes:
                episodes_to_plot = list(range(total_episodes))
            else:
                episodes_to_plot = [0, total_episodes // 4, total_episodes // 2,
                                    3 * total_episodes // 4, total_episodes - 1]
                episodes_to_plot = episodes_to_plot[:max_episodes]

        num_plots = len(episodes_to_plot)
        fig, axes = plt.subplots(num_plots, 1, figsize=(15, 4 * num_plots))
        if num_plots == 1:
            axes = [axes]

        colors = plt.cm.Set3(np.linspace(0, 1, 12))

        for idx, episode_idx in enumerate(episodes_to_plot):
            ax = axes[idx]
            episode_data = self.episode_task_data[episode_idx]

            # Assign color to each shuttle
            shuttle_colors = {}
            color_idx = 0

            # Plot each task
            y_positions = {}
            y_pos = 0

            for shuttle_data in episode_data['shuttles_data']:
                shuttle_id = shuttle_data['shuttle_id']
                if shuttle_id not in y_positions:
                    y_positions[shuttle_id] = y_pos
                    y_pos += 1

                if shuttle_id not in shuttle_colors:
                    shuttle_colors[shuttle_id] = colors[color_idx % len(colors)]
                    color_idx += 1

                # Plot all tasks for this shuttle
                for task in shuttle_data['tasks']:
                    start_time = task['start_time']
                    duration = task['duration']
                    end_time = task['end_time']

                    # Plot task bar
                    ax.barh(y_positions[shuttle_id], duration, left=start_time,
                            height=0.6, color=shuttle_colors[shuttle_id],
                            alpha=0.7, edgecolor='black', linewidth=0.5)

                    # Add task ID label
                    ax.text(start_time + duration / 2, y_positions[shuttle_id],
                            task['task_id'].split('_')[-1],
                            ha='center', va='center', fontsize=8, fontweight='bold')

                    # Collect Excel data
                    excel_row = {
                        'Episode': episode_data['episode'],
                        'Task_ID': task['task_id'],
                        'Shuttle_ID': shuttle_id,
                        'Zone': task['zone'],
                        'Start_Time': round(start_time, 2),
                        'End_Time': round(end_time, 2),
                        'Duration': round(duration, 2),
                        'Inbound_Location': str(task.get('inbound_location', '')),
                        'Outbound_Location': str(task.get('outbound_location', '')),
                        'Storage_Strategy': task.get('storage_strategy', 'unknown'),
                        'Outbound_Strategy': task.get('outbound_strategy', 'unknown'),
                        'Remaining_Time': task.get('remaining_time', 0) if task.get('remaining_time') is not None else 0
                    }
                    excel_data.append(excel_row)

            # Set chart properties
            ax.set_xlabel('Time (seconds)')
            ax.set_ylabel('Shuttle')
            ax.set_title(f'DDPG Episode {episode_data["episode"]} Task Completion Gantt Chart\n'
                         f'Completion Rate: {episode_data["completion_rate"]:.1%}, '
                         f'Total Time: {episode_data["total_simulation_time"]:.1f}s, '
                         f'Tasks: {episode_data["completed_tasks"]}/{episode_data["total_tasks"]}')

            # Set y-axis labels
            shuttle_labels = [f'Shuttle {sid}' for sid in sorted(y_positions.keys())]
            ax.set_yticks(list(range(len(shuttle_labels))))
            ax.set_yticklabels(shuttle_labels)

            ax.grid(True, alpha=0.3)
            ax.set_xlim(0, episode_data['total_simulation_time'] * 1.05)

        plt.tight_layout()

        # Save chart
        current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"DDPG_Gantt_Chart_{current_time}.png"
        filepath = get_output_path(filename)
        plt.savefig(filepath, dpi=1200, bbox_inches='tight', format='png')
        plt.close()
        print(f"DDPG Gantt Chart saved as: {filename}")

        # Save Excel data
        if excel_data:
            try:
                wb = Workbook()
                ws1 = wb.active
                ws1.title = "DDPG Gantt Chart Task Detailed Data"

                headers = [
                    'Episode', 'Task_ID', 'Shuttle_ID', 'Zone', 'Start_Time',
                    'End_Time', 'Duration', 'Inbound_Location', 'Outbound_Location',
                    'Storage_Strategy', 'Outbound_Strategy', 'Remaining_Time'
                ]

                for col, header in enumerate(headers, 1):
                    ws1.cell(row=1, column=col, value=header)

                for row_idx, data_row in enumerate(excel_data, 2):
                    for col_idx, header in enumerate(headers, 1):
                        ws1.cell(row=row_idx, column=col_idx, value=data_row[header])

                excel_filename = f"DDPG_Gantt_{current_time}.xlsx"
                excel_filepath = get_output_path(excel_filename)
                wb.save(excel_filepath)
                print(f"DDPG Gantt Chart data saved to Excel: {excel_filename}")

            except Exception as e:
                print(f"Error saving DDPG Gantt Chart Excel data: {e}")

    def plot_completion_time_iteration(self):
        """Plot DDPG completion time iteration chart"""
        if not self.episode_completion_times:
            print("No completion time data available for plotting")
            return

        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))

        episodes = range(1, len(self.episode_completion_times) + 1)

        # 1. Total completion time iteration chart
        ax1.plot(episodes, self.episode_completion_times, 'b-', alpha=0.6, label='Total Completion Time')

        # Smoothed curve
        if len(self.episode_completion_times) > 10:
            window_size = min(20, len(self.episode_completion_times) // 5)
            smoothed_times = []
            for i in range(len(self.episode_completion_times)):
                start = max(0, i - window_size + 1)
                smoothed_times.append(np.mean(self.episode_completion_times[start:i + 1]))
            ax1.plot(episodes, smoothed_times, 'r-', linewidth=2, label='Smoothed Curve')

        ax1.set_xlabel('Training Episode')
        ax1.set_ylabel('Total Completion Time (seconds)')
        ax1.set_title('DDPG Total Task Completion Time Iteration Chart')
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # 2. Average task time iteration chart
        avg_task_times = [metrics['avg_task_time'] for metrics in self.episode_efficiency_metrics]
        ax2.plot(episodes, avg_task_times, 'g-', alpha=0.6, label='Average Task Time')

        if len(avg_task_times) > 10:
            window_size = min(20, len(avg_task_times) // 5)
            smoothed_avg = []
            for i in range(len(avg_task_times)):
                start = max(0, i - window_size + 1)
                smoothed_avg.append(np.mean(avg_task_times[start:i + 1]))
            ax2.plot(episodes, smoothed_avg, 'orange', linewidth=2, label='Smoothed Curve')

        ax2.set_xlabel('Training Episode')
        ax2.set_ylabel('Average Task Time (seconds)')
        ax2.set_title('DDPG Average Single Task Completion Time Iteration Chart')
        ax2.legend()
        ax2.grid(True, alpha=0.3)

        # 3. Combined completion rate and efficiency chart
        completion_rates = [metrics['completion_rate'] for metrics in self.episode_efficiency_metrics]
        ax3.plot(episodes, completion_rates, 'purple', alpha=0.6, label='Task Completion Rate')
        ax3.set_xlabel('Training Episode')
        ax3.set_ylabel('Task Completion Rate')
        ax3.set_title('DDPG Task Completion Rate Iteration Chart')
        ax3.legend()
        ax3.grid(True, alpha=0.3)

        # 4. Movement distance efficiency chart
        avg_distances = [metrics['avg_distance_per_task'] for metrics in self.episode_efficiency_metrics]
        ax4.plot(episodes, avg_distances, 'brown', alpha=0.6, label='Average Distance per Task')

        if len(avg_distances) > 10:
            window_size = min(20, len(avg_distances) // 5)
            smoothed_dist = []
            for i in range(len(avg_distances)):
                start = max(0, i - window_size + 1)
                smoothed_dist.append(np.mean(avg_distances[start:i + 1]))
            ax4.plot(episodes, smoothed_dist, 'red', linewidth=2, label='Smoothed Curve')

        ax4.set_xlabel('Training Episode')
        ax4.set_ylabel('Average Movement Distance per Task (m)')
        ax4.set_title('DDPG Movement Efficiency Iteration Chart')
        ax4.legend()
        ax4.grid(True, alpha=0.3)

        plt.tight_layout()

        # Save chart
        current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"DDPG_Completion_Time_Iteration_{current_time}.png"
        filepath = get_output_path(filename)
        plt.savefig(filepath, dpi=1200, bbox_inches='tight', format='png')
        plt.close()
        print(f"DDPG Completion Time Iteration Chart saved as: {filename}")

    def export_training_data(self, filename="ddpg_training_data.xlsx"):
        """Export DDPG training data to Excel file"""
        if not self.episode_completion_times:
            print("No training data available for export")
            return

        try:
            wb = Workbook()

            # Worksheet 1: Basic training data
            ws1 = wb.active
            ws1.title = "DDPG Training Data"

            # Modify header to add "Smoothed Time" column
            headers = ["Training Episode", "Task Completion Time (seconds)", "Smoothed Time (seconds)", "Episode Reward",
                       "Smoothed Reward", "Completed Tasks", "Total Tasks", "Completion Rate (%)",
                       "Average Task Time (seconds)", "Actor Loss", "Critic Loss"]
            for col, header in enumerate(headers, 1):
                ws1.cell(row=1, column=col, value=header)

            # Calculate smoothed time (moving average)
            smoothed_times = []
            if len(self.episode_completion_times) > 10:
                window_size = min(20, len(self.episode_completion_times) // 5)
                for i in range(len(self.episode_completion_times)):
                    start = max(0, i - window_size + 1)
                    smoothed_times.append(np.mean(self.episode_completion_times[start:i + 1]))
            else:
                # No smoothing for small dataset, use original values directly
                smoothed_times = self.episode_completion_times.copy()

            smoothed_rewards = []
            if len(self.episode_rewards) > 10:
                window_size = min(20, len(self.episode_rewards) // 5)
                for i in range(len(self.episode_rewards)):
                    start = max(0, i - window_size + 1)
                    smoothed_rewards.append(np.mean(self.episode_rewards[start:i + 1]))
            else:
                # No smoothing for small dataset, use original values directly
                smoothed_rewards = self.episode_rewards.copy()

            # Populate data
            for i in range(len(self.episode_completion_times)):
                ws1.cell(row=i + 2, column=1, value=i + 1)  # Training Episode
                ws1.cell(row=i + 2, column=2, value=round(self.episode_completion_times[i], 2))  # Original Time
                ws1.cell(row=i + 2, column=3, value=round(smoothed_times[i], 2))  # Smoothed Time

                if i < len(self.episode_rewards):
                    ws1.cell(row=i + 2, column=4, value=round(self.episode_rewards[i], 2))  # Episode Reward
                    ws1.cell(row=i + 2, column=5, value=round(smoothed_rewards[i], 2))  # Smoothed Reward

                if i < len(self.episode_task_data):
                    task_data = self.episode_task_data[i]
                    ws1.cell(row=i + 2, column=6, value=task_data['completed_tasks'])  # Completed Tasks
                    ws1.cell(row=i + 2, column=7, value=task_data['total_tasks'])  # Total Tasks
                    ws1.cell(row=i + 2, column=8, value=round(task_data['completion_rate'] * 100, 2))  # Completion Rate

                if i < len(self.episode_efficiency_metrics):
                    avg_time = self.episode_efficiency_metrics[i]['avg_task_time']
                    ws1.cell(row=i + 2, column=9, value=round(avg_time, 2))  # Average Task Time

                # Actor and Critic losses (if recorded)
                ws1.cell(row=i + 2, column=10, value="N/A")  # Actor Loss
                ws1.cell(row=i + 2, column=11, value="N/A")  # Critic Loss

            # Worksheet 2: Strategy usage statistics
            ws2 = wb.create_sheet(title="DDPG Strategy Usage Statistics")

            # Storage strategy statistics
            ws2.cell(row=1, column=1, value="Storage Strategy")
            ws2.cell(row=1, column=2, value="Usage Count")
            ws2.cell(row=1, column=3, value="Usage Ratio (%)")

            storage_total = sum(self.strategy_usage['storage'].values())
            row = 2
            for strategy, count in self.strategy_usage['storage'].items():
                ws2.cell(row=row, column=1, value=strategy)
                ws2.cell(row=row, column=2, value=count)
                ws2.cell(row=row, column=3, value=round(count / storage_total * 100, 2) if storage_total > 0 else 0)
                row += 1

            # Outbound strategy statistics
            ws2.cell(row=row + 1, column=1, value="Outbound Strategy")
            ws2.cell(row=row + 1, column=2, value="Usage Count")
            ws2.cell(row=row + 1, column=3, value="Usage Ratio (%)")

            outbound_total = sum(self.strategy_usage['outbound'].values())
            row += 2
            for strategy, count in self.strategy_usage['outbound'].items():
                ws2.cell(row=row, column=1, value=strategy)
                ws2.cell(row=row, column=2, value=count)
                ws2.cell(row=row, column=3, value=round(count / outbound_total * 100, 2) if outbound_total > 0 else 0)
                row += 1

            # Task selection strategy statistics
            ws2.cell(row=row + 1, column=1, value="Task Selection Strategy")
            ws2.cell(row=row + 1, column=2, value="Usage Count")
            ws2.cell(row=row + 1, column=3, value="Usage Ratio (%)")

            task_total = sum(self.strategy_usage['task_selection'].values())
            row += 2
            for strategy, count in self.strategy_usage['task_selection'].items():
                ws2.cell(row=row, column=1, value=strategy)
                ws2.cell(row=row, column=2, value=count)
                ws2.cell(row=row, column=3, value=round(count / task_total * 100, 2) if task_total > 0 else 0)
                row += 1

            # Save file
            current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
            full_filename = f"DDPG_{filename.replace('.xlsx', '')}_{current_time}.xlsx"
            full_filepath = get_output_path(full_filename)
            wb.save(full_filepath)

            print(f"DDPG training data exported to: {full_filename}")

        except Exception as e:
            print(f"Error exporting DDPG training data: {e}")

    def print_training_summary(self):
        """Print DDPG training summary report"""
        if not self.episode_task_data:
            print("No training data available")
            return

        print("\n" + "=" * 60)
        print("                  DDPG Training Summary Report")
        print("=" * 60)

        # Basic statistics
        total_episodes = len(self.episode_task_data)
        avg_completion_time = np.mean(self.episode_completion_times)
        std_completion_time = np.std(self.episode_completion_times)
        avg_reward = np.mean(self.episode_rewards)
        std_reward = np.std(self.episode_rewards)
        avg_completion_rate = np.mean(self.episode_completion_rates)

        print(f"Total Training Episodes: {total_episodes}")
        print(f"Average Completion Time: {avg_completion_time:.2f} ± {std_completion_time:.2f} seconds")
        print(f"Average Reward: {avg_reward:.2f} ± {std_reward:.2f}")
        print(f"Average Completion Rate: {avg_completion_rate:.2%}")

        # Learning effect analysis
        if total_episodes >= 20:
            early_episodes = self.episode_completion_times[:total_episodes // 4]
            late_episodes = self.episode_completion_times[-total_episodes // 4:]

            early_avg = np.mean(early_episodes)
            late_avg = np.mean(late_episodes)
            improvement = (early_avg - late_avg) / early_avg * 100

            print(f"\nDDPG Learning Effect Analysis:")
            print(f"Early Stage Average Completion Time: {early_avg:.2f} seconds")
            print(f"Late Stage Average Completion Time: {late_avg:.2f} seconds")
            print(f"Completion Time Improvement: {improvement:.1f}%")

        # Best performance
        best_episode_idx = np.argmin(self.episode_completion_times)
        best_time = self.episode_completion_times[best_episode_idx]
        best_reward = self.episode_rewards[best_episode_idx]

        print(f"\nBest Performance:")
        print(f"Shortest Completion Time: {best_time:.2f} seconds (Episode {best_episode_idx + 1})")
        print(f"Corresponding Reward: {best_reward:.2f}")

        # Strategy preference analysis
        print(f"\nDDPG Strategy Learning Preferences:")
        for strategy_type, usage in self.strategy_usage.items():
            total_usage = sum(usage.values())
            if total_usage > 0:
                print(f"  {strategy_type}:")
                for strategy, count in usage.items():
                    percentage = count / total_usage * 100
                    print(f"    {strategy}: {percentage:.1f}% ({count} times)")

        print("=" * 60)

    def plot_best_episode_gantt(self):
        """Plot and save Gantt chart for Episode with shortest completion time"""
        if not self.episode_completion_times or not self.episode_task_data:
            print("No Episode data available for analysis")
            return

        # Find Episode with shortest completion time
        best_episode_idx = np.argmin(self.episode_completion_times)
        best_time = self.episode_completion_times[best_episode_idx]
        best_episode_data = self.episode_task_data[best_episode_idx]

        print(f"Best Episode: {best_episode_data['episode']}")
        print(f"Shortest Completion Time: {best_time:.2f} seconds")
        print(f"Completion Rate: {best_episode_data['completion_rate']:.2%}")

        # Plot Gantt chart
        fig, ax = plt.subplots(1, 1, figsize=(15, 8))
        colors = plt.cm.Set3(np.linspace(0, 1, 12))

        # Excel data collection
        excel_data = []

        # Assign colors and positions to each shuttle
        shuttle_colors = {}
        y_positions = {}
        y_pos = 0
        color_idx = 0

        for shuttle_data in best_episode_data['shuttles_data']:
            shuttle_id = shuttle_data['shuttle_id']
            if shuttle_id not in y_positions:
                y_positions[shuttle_id] = y_pos
                y_pos += 1

            if shuttle_id not in shuttle_colors:
                shuttle_colors[shuttle_id] = colors[color_idx % len(colors)]
                color_idx += 1

            # Plot all tasks for this shuttle
            for task in shuttle_data['tasks']:
                start_time = task['start_time']
                duration = task['duration']
                end_time = task['end_time']

                # Plot task bar
                ax.barh(y_positions[shuttle_id], duration, left=start_time,
                        height=0.6, color=shuttle_colors[shuttle_id],
                        alpha=0.7, edgecolor='black', linewidth=0.5)

                # Add task ID label
                ax.text(start_time + duration / 2, y_positions[shuttle_id],
                        task['task_id'].split('_')[-1],
                        ha='center', va='center', fontsize=8, fontweight='bold')

                # Collect Excel data
                excel_row = {
                    'Episode': best_episode_data['episode'],
                    'Task_ID': task['task_id'],
                    'Shuttle_ID': shuttle_id,
                    'Zone': task['zone'],
                    'Start_Time': round(start_time, 2),
                    'End_Time': round(end_time, 2),
                    'Duration': round(duration, 2),
                    'Inbound_Location': str(task.get('inbound_location', '')),
                    'Outbound_Location': str(task.get('outbound_location', '')),
                    'Storage_Strategy': task.get('storage_strategy', 'unknown'),
                    'Outbound_Strategy': task.get('outbound_strategy', 'unknown'),
                    'Remaining_Time': task.get('remaining_time', 0) if task.get('remaining_time') is not None else 0
                }
                excel_data.append(excel_row)

        # Set chart properties
        ax.set_xlabel('Time (seconds)')
        ax.set_ylabel('Shuttle')
        ax.set_title(f'Best Episode {best_episode_data["episode"]} Task Completion Gantt Chart (Shortest Time: {best_time:.1f}s)\n'
                     f'Completion Rate: {best_episode_data["completion_rate"]:.1%}, '
                     f'Tasks: {best_episode_data["completed_tasks"]}/{best_episode_data["total_tasks"]}')

        # Set y-axis labels
        shuttle_labels = [f'Shuttle {sid}' for sid in sorted(y_positions.keys())]
        ax.set_yticks(list(range(len(shuttle_labels))))
        ax.set_yticklabels(shuttle_labels)

        ax.grid(True, alpha=0.3)
        ax.set_xlim(0, best_episode_data['total_simulation_time'] * 1.05)

        plt.tight_layout()

        # Save Gantt chart as best_gantt
        current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"best_gantt_{current_time}.png"
        filepath = get_output_path(filename)
        plt.savefig(filepath, dpi=1200, bbox_inches='tight', format='png')
        plt.close()
        print(f"Best Episode Gantt Chart saved as: {filename}")

        # Save Excel data
        if excel_data:
            try:
                wb = Workbook()
                ws1 = wb.active
                ws1.title = "Best Episode Task Data"

                # Add summary information
                ws1.cell(row=1, column=1, value=f"Best Episode: {best_episode_data['episode']}")
                ws1.cell(row=2, column=1, value=f"Shortest Completion Time: {best_time:.2f} seconds")
                ws1.cell(row=3, column=1, value=f"Completion Rate: {best_episode_data['completion_rate']:.2%}")
                ws1.cell(row=4, column=1, value=f"Total Tasks: {best_episode_data['total_tasks']}")
                ws1.cell(row=5, column=1, value=f"Completed Tasks: {best_episode_data['completed_tasks']}")

                # Task detail data headers
                headers = [
                    'Task_ID', 'Shuttle_ID', 'Zone', 'Start_Time', 'End_Time', 'Duration',
                    'Inbound_Location', 'Outbound_Location', 'Storage_Strategy',
                    'Outbound_Strategy', 'Remaining_Time'
                ]

                start_row = 7  # Start task data from row 7
                for col, header in enumerate(headers, 1):
                    ws1.cell(row=start_row, column=col, value=header)

                # Populate task data
                for row_idx, data_row in enumerate(excel_data, start_row + 1):
                    for col_idx, header in enumerate(headers, 1):
                        ws1.cell(row=row_idx, column=col_idx, value=data_row[header])

                # Add statistics worksheet
                ws2 = wb.create_sheet(title="Best Episode Statistical Analysis")

                # Statistics by shuttle
                ws2.cell(row=1, column=1, value="Shuttle Performance Statistics")
                ws2.cell(row=2, column=1, value="Shuttle ID")
                ws2.cell(row=2, column=2, value="Completed Tasks")
                ws2.cell(row=2, column=3, value="Total Working Time")
                ws2.cell(row=2, column=4, value="Average Task Time")

                row = 3
                for shuttle_data in best_episode_data['shuttles_data']:
                    ws2.cell(row=row, column=1, value=shuttle_data['shuttle_id'])
                    ws2.cell(row=row, column=2, value=len(shuttle_data['tasks']))

                    total_time = sum(task['duration'] for task in shuttle_data['tasks'])
                    avg_time = total_time / len(shuttle_data['tasks']) if shuttle_data['tasks'] else 0

                    ws2.cell(row=row, column=3, value=round(total_time, 2))
                    ws2.cell(row=row, column=4, value=round(avg_time, 2))
                    row += 1

                excel_filename = f"best_gantt_data_{current_time}.xlsx"
                excel_filepath = get_output_path(excel_filename)
                wb.save(excel_filepath)
                print(f"Best Episode data saved to Excel: {excel_filename}")

            except Exception as e:
                print(f"Error saving Best Episode Excel data: {e}")

        return best_episode_idx, best_time, excel_data

    def _collect_episode_waiting_data(self, episode_num):
        """Collect waiting time data for current episode"""
        waiting_data = {
            'episode': episode_num,
            'shuttles_waiting': [],
            'transfer_shuttles_waiting': [],
            'elevators_waiting': []
        }

        if hasattr(self.env, 'shuttles'):
            # Collect shuttle waiting times
            for shuttle in self.env.shuttles:
                shuttle_waiting = {
                    'shuttle_id': shuttle.shuttle_id,
                    'zone': shuttle.zone,
                    'total_waiting_time': shuttle.current_episode_waiting_time,
                    'waiting_count': len([w for w in shuttle.waiting_episodes
                                          if w['start_time'] >= shuttle.current_task_start_time]),
                    'avg_waiting_time': 0
                }

                episode_waitings = [w for w in shuttle.waiting_episodes
                                    if w['start_time'] >= shuttle.current_task_start_time]
                if episode_waitings:
                    shuttle_waiting['avg_waiting_time'] = sum(w['duration'] for w in episode_waitings) / len(
                        episode_waitings)

                waiting_data['shuttles_waiting'].append(shuttle_waiting)

        if hasattr(self.env, 'transfer_shuttles'):
            # Collect transfer shuttle waiting times
            for transfer_id, transfer_shuttle in self.env.transfer_shuttles.items():
                transfer_waiting = {
                    'transfer_id': transfer_id,
                    'level': transfer_shuttle.assigned_level,
                    'total_waiting_time': transfer_shuttle.current_episode_waiting_time,
                    'waiting_count': len(transfer_shuttle.waiting_episodes),
                    'avg_waiting_time': (transfer_shuttle.current_episode_waiting_time /
                                         max(len(transfer_shuttle.waiting_episodes), 1))
                }
                waiting_data['transfer_shuttles_waiting'].append(transfer_waiting)

        if hasattr(self.env, 'elevators'):
            # Collect elevator waiting times
            for elevator_id, elevator in self.env.elevators.items():
                elevator_waiting = {
                    'elevator_id': elevator_id,
                    'position_x': elevator.x,
                    'total_waiting_time': elevator.current_episode_waiting_time,
                    'waiting_count': len(elevator.waiting_episodes),
                    'avg_waiting_time': (elevator.current_episode_waiting_time /
                                         max(len(elevator.waiting_episodes), 1))
                }
                waiting_data['elevators_waiting'].append(elevator_waiting)

        return waiting_data

    def export_waiting_time_data(self, filename="equipment_waiting_times.xlsx"):
        """Export equipment waiting time data to Excel file"""
        if not self.episode_waiting_data:
            print("No waiting time data available for export")
            return

        try:
            wb = Workbook()

            # Worksheet 1: Shuttle waiting times
            ws1 = wb.active
            ws1.title = "Shuttle Waiting Times"

            # Shuttle waiting time headers
            shuttle_headers = ["Episode", "Shuttle_ID", "Zone", "Total_Waiting_Time(s)",
                               "Waiting_Count", "Avg_Waiting_Time(s)"]
            for col, header in enumerate(shuttle_headers, 1):
                ws1.cell(row=1, column=col, value=header)

            row = 2
            for episode_data in self.episode_waiting_data:
                for shuttle_data in episode_data['shuttles_waiting']:
                    ws1.cell(row=row, column=1, value=episode_data['episode'])
                    ws1.cell(row=row, column=2, value=shuttle_data['shuttle_id'])
                    ws1.cell(row=row, column=3, value=shuttle_data['zone'])
                    ws1.cell(row=row, column=4, value=round(shuttle_data['total_waiting_time'], 2))
                    ws1.cell(row=row, column=5, value=shuttle_data['waiting_count'])
                    ws1.cell(row=row, column=6, value=round(shuttle_data['avg_waiting_time'], 2))
                    row += 1

            # Worksheet 2: Transfer shuttle waiting times
            ws2 = wb.create_sheet(title="Transfer Shuttle Waiting Times")

            transfer_headers = ["Episode", "Transfer_ID", "Level", "Total_Waiting_Time(s)",
                                "Waiting_Count", "Avg_Waiting_Time(s)"]
            for col, header in enumerate(transfer_headers, 1):
                ws2.cell(row=1, column=col, value=header)

            row = 2
            for episode_data in self.episode_waiting_data:
                for transfer_data in episode_data['transfer_shuttles_waiting']:
                    ws2.cell(row=row, column=1, value=episode_data['episode'])
                    ws2.cell(row=row, column=2, value=transfer_data['transfer_id'])
                    ws2.cell(row=row, column=3, value=transfer_data['level'])
                    ws2.cell(row=row, column=4, value=round(transfer_data['total_waiting_time'], 2))
                    ws2.cell(row=row, column=5, value=transfer_data['waiting_count'])
                    ws2.cell(row=row, column=6, value=round(transfer_data['avg_waiting_time'], 2))
                    row += 1

            # Worksheet 3: Elevator waiting times
            ws3 = wb.create_sheet(title="Elevator Waiting Times")

            elevator_headers = ["Episode", "Elevator_ID", "Position_X", "Total_Waiting_Time(s)",
                                "Waiting_Count", "Avg_Waiting_Time(s)"]
            for col, header in enumerate(elevator_headers, 1):
                ws3.cell(row=1, column=col, value=header)

            row = 2
            for episode_data in self.episode_waiting_data:
                for elevator_data in episode_data['elevators_waiting']:
                    ws3.cell(row=row, column=1, value=episode_data['episode'])
                    ws3.cell(row=row, column=2, value=elevator_data['elevator_id'])
                    ws3.cell(row=row, column=3, value=elevator_data['position_x'])
                    ws3.cell(row=row, column=4, value=round(elevator_data['total_waiting_time'], 2))
                    ws3.cell(row=row, column=5, value=elevator_data['waiting_count'])
                    ws3.cell(row=row, column=6, value=round(elevator_data['avg_waiting_time'], 2))
                    row += 1

            # Save file
            current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
            full_filename = f"{filename.replace('.xlsx', '')}_{current_time}.xlsx"
            full_filepath = get_output_path(full_filename)
            wb.save(full_filepath)

            print(f"Equipment waiting time data exported to: {full_filename}")

        except Exception as e:
            print(f"Error exporting waiting time data: {e}")


class OUNoise:
    """Ornstein-Uhlenbeck noise generator for exploration - with decay functionality"""

    def __init__(self, size, mu=0.0, theta=0.15, sigma=0.2, decay_rate=0.995, min_sigma=0.01):
        self.size = size
        self.mu = mu * np.ones(size)
        self.theta = theta
        self.sigma_initial = sigma  # Save initial noise intensity
        self.sigma = sigma
        self.decay_rate = decay_rate  # Noise decay rate
        self.min_sigma = min_sigma  # Minimum noise intensity
        self.reset()

    def reset(self):
        """Reset noise state"""
        self.state = copy.deepcopy(self.mu)

    def sample(self):
        """Generate noise sample"""
        dx = self.theta * (self.mu - self.state) + self.sigma * np.random.randn(self.size)
        self.state += dx
        return self.state

    def decay_noise(self):
        """Decay noise intensity"""
        self.sigma = max(self.sigma * self.decay_rate, self.min_sigma)

    def get_noise_level(self):
        """Get current noise level"""
        return self.sigma / self.sigma_initial

def main_ddpg_warehouse_training():
    """Main function for DDPG warehouse system training"""
    print("=== Intelligent Warehouse System + DDPG Reinforcement Learning ===")
    print("System Features:")
    print("- Uses DDPG algorithm for continuous strategy selection")
    print("- Actor network outputs continuous values mapped to discrete strategies")
    print("- Critic network evaluates state-action values")
    print("- Supports smooth exploration and optimization of strategies")
    print("- Retains complete warehouse system functionality")

    # Create DDPG trainer
    trainer = WarehouseDDPGTrainer(
        task_data_path=r"C:\Users\hp\Desktop\DEC-MAPPO\MARL-code-pytorch-main\6.保存文件\2-python文件版本-以这份为主\storage_task_100.xlsx",
        lr_actor=1e-4,
        lr_critic=1e-3
    )
    try:
        print("\nStarting DDPG training...")
        episode_rewards, completion_rates = trainer.train(episodes=200, update_freq=5)

        print("\nGenerating DDPG analysis report...")
        trainer.print_training_summary()
        trainer.plot_completion_time_iteration()
        trainer.plot_gantt_charts(episodes_to_plot=None, max_episodes=8)
        trainer.plot_training_results()

        print("\nStarting evaluation...")
        eval_rewards, eval_completion_rates = trainer.evaluate(num_episodes=10)

        print("\nExporting DDPG training data...")
        trainer.export_training_data("ddpg_training_data.xlsx")

        print("\nExporting equipment waiting time data...")
        trainer.export_waiting_time_data("equipment_waiting_times.xlsx")

        print("\nSaving model...")
        trainer.save_model("ddpg_warehouse_model.pth")

        print("\n=== DDPG Training and Evaluation Completed ===")
        print("DDPG System Advantages:")
        print("1. Continuous action space allows for more refined strategy adjustment")
        print("2. Deterministic policy network provides stable decision-making")
        print("3. Experience replay improves sample utilization efficiency")
        print("4. Target networks ensure training stability")
        print("5. Suitable for strategy optimization problems in warehouse systems")
        # Add after existing analysis report generation code
        print("\nGenerating best Episode Gantt chart...")
        best_idx, best_time, best_data = trainer.plot_best_episode_gantt()

        return trainer

    except Exception as e:
        print(f"Error occurred during DDPG training: {e}")
        import traceback
        traceback.print_exc()
        return None


# Add motion analysis test in main function
def test_motion_improvements():
    """Test motion improvement effects"""
    # Create new motion calculator
    new_calculator = MotionCalculator(
        shuttle_velocity=3.0, shuttle_acceleration=2.0,
        transfer_velocity=3.0, transfer_acceleration=2.0,
        elevator_velocity=4.0, elevator_acceleration=3.0
    )

    # Create old motion calculator (simulation)
    class OldMotionCalculator:
        def calculate_shuttle_travel_time(self, distance):
            return distance / 4.0

        def calculate_transfer_travel_time(self, distance):
            return distance / 3.0

        def calculate_elevator_travel_time(self, distance):
            return distance / 4.0

    old_calculator = OldMotionCalculator()

    # Analysis tool
    analyzer = EnhancedMotionAnalysis()

    # Test different distances
    test_distances = [1, 2, 5, 10, 15, 20, 30, 40]

    analyzer.print_motion_comparison(old_calculator, new_calculator, test_distances)

    print("\n=== Detailed Motion Profile Analysis ===")
    for distance in [5, 15, 30]:
        profile = new_calculator.get_motion_profile(
            distance, new_calculator.shuttle_velocity, new_calculator.shuttle_acceleration)

        print(f"\nShuttle motion profile for distance {distance}m:")
        print(f"  Profile type: {profile['profile_type']}")
        print(f"  Total time: {profile['total_time']:.2f}s")
        print(f"  Acceleration time: {profile['accel_time']:.2f}s")
        print(f"  Uniform velocity time: {profile['uniform_time']:.2f}s")
        print(f"  Deceleration time: {profile['decel_time']:.2f}s")
        print(f"  Peak velocity: {profile['peak_velocity']:.2f}m/s")
        print(f"  Acceleration distance: {profile['accel_distance']:.2f}m")
        print(f"  Uniform velocity distance: {profile['uniform_distance']:.2f}m")

# Add motion test at the end of main function
if __name__ == "__main__":
    print("=== Intelligent Warehouse System + DDPG Reinforcement Learning ===")
    print("Select running mode:")
    print("1. DDPG reinforcement learning training mode")
    print("2. Load trained model for testing")
    print("3. Motion parameter comparison test")  # New option

    choice = input("Please enter your choice (1/2/3): ").strip()

    if choice == "1":
        # DDPG reinforcement learning training
        trainer = main_ddpg_warehouse_training()

    elif choice == "2":
        # Load model for testing
        print("\n=== Load trained DDPG model for testing ===")
        try:
            trainer = WarehouseDDPGTrainer()
            trainer.load_model("ddpg_warehouse_model.pth")
            eval_rewards, eval_completion_rates = trainer.evaluate(num_episodes=5)
            print("Model testing completed")
        except Exception as e:
            print(f"Failed to load model: {e}")

    elif choice == "3":
        # Motion parameter comparison test
        print("\n=== Motion Parameter Improvement Effect Test ===")
        test_motion_improvements()

        # Show specific acceleration calculation examples
        calculator = MotionCalculator(
            shuttle_velocity=3.0, shuttle_acceleration=2.0,
            transfer_velocity=3.0, transfer_acceleration=2.0,
            elevator_velocity=4.0, elevator_acceleration=3.0
        )

        print("\n=== Specific Calculation Examples ===")
        example_distances = [2, 10, 25]

        for dist in example_distances:
            shuttle_time = calculator.calculate_shuttle_travel_time(dist)
            profile = calculator.get_motion_profile(dist, 3.0, 2.0)

            print(f"\nShuttle moving {dist}m:")
            print(f"  Total time: {shuttle_time:.2f}s")
            print(f"  Motion mode: {profile['profile_type']}")

            if profile['profile_type'] == 'triangular':
                print(f"  Note: Short distance, maximum velocity not reached")
                print(f"  Peak velocity: {profile['peak_velocity']:.2f}m/s (< 3.0m/s)")
            else:
                print(f"  Note: Long distance, maximum velocity reached and maintained")
                print(f"  Uniform velocity running time: {profile['uniform_time']:.2f}s")

    else:
        print("Invalid choice, program exited")