import numpy as np
import random
import matplotlib.pyplot as plt
import pandas as pd
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import ListedColormap
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
import time
import math
import os
from datetime import datetime
from typing import Dict, List, Tuple
from collections import defaultdict, deque, namedtuple
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import openpyxl
from openpyxl import Workbook
from collections import Counter
import scipy.stats as stats

# Set Chinese font
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# ============================================================================
#                            Code 1: Original Warehouse System
# ============================================================================

#  Create a three-dimensional shelf, with the coordinate range starting from 1. Therefore, the actual size of the array needs to be increased by 1.
warehouse_shape = (16, 40, 14)
warehouse = np.zeros((warehouse_shape[0] + 1, warehouse_shape[1] + 1, warehouse_shape[2] + 1),
                     dtype=int)

#
total_slots = warehouse_shape[0] * warehouse_shape[1] * warehouse_shape[2]
num_occupied = int(total_slots * 0.52)
occupied_indices = random.sample(range(1, total_slots + 1), num_occupied)

for idx in occupied_indices:
    idx_0based = idx - 1
    x = idx_0based // (warehouse_shape[1] * warehouse_shape[2]) + 1  # X-axis (1-16)
    y = (idx_0based % (warehouse_shape[1] * warehouse_shape[2])) // warehouse_shape[2] + 1  # Y-axis (1 - 40)
    z = idx_0based % warehouse_shape[2] + 1  # Z-axis (1-14)
    warehouse[x, y, z] = 1

print(f"Total number of warehouse storage locations: {total_slots}")
occupied = np.sum(warehouse) - warehouse[0].sum() - warehouse[:, 0].sum() - warehouse[:, :, 0].sum()
print(f"Occupied storage space quantity: {occupied} ({occupied / total_slots * 100:.2f}%)")

# Set quality and volume limits for each storage location
mass_limits = np.zeros((warehouse_shape[0] + 1, warehouse_shape[1] + 1, warehouse_shape[2] + 1))
volume_limits = np.zeros((warehouse_shape[0] + 1, warehouse_shape[1] + 1, warehouse_shape[2] + 1))

for x in range(1, warehouse_shape[0] + 1):
    for y in range(1, warehouse_shape[1] + 1):
        for z in range(1, warehouse_shape[2] + 1):
            mass_limits[x, y, z] = round(random.uniform(1, 25), 2)
            volume_limits[x, y, z] = round(random.uniform(1, 30), 2)

# Create the goods information for the occupied storage locations
occupied_items = {}
for x in range(1, warehouse_shape[0] + 1):
    for y in range(1, warehouse_shape[1] + 1):
        for z in range(1, warehouse_shape[2] + 1):
            if warehouse[x, y, z] == 1:
                occupied_items[(x, y, z)] = {
                    'mass': round(random.uniform(1, 25), 2),
                    'volume': round(random.uniform(1, 30), 2),
                    'frequency': random.randint(1, 30)
                }

# I/O port (in and out port) configuration
IO_POINTS = {
    1: (1, 1, 1),
    2: (8, 1, 1),
    3: (16, 1, 1)
}


def select_io_point_and_elevator(x_coordinate):
    if x_coordinate <= 6:
        return 1, 1
    elif 6 < x_coordinate <= 10:
        return 2, 2
    else:
        return 3, 3


# The function for reading Excel files
def load_tasks_from_excel(file_path="storage_task_100.xlsx"):
    """Read task information from the Excel file"""
    try:
        # 读取Excel文件
        df = pd.read_excel(file_path, sheet_name=0)  # Read the first sheet

        print(f"=== Successfully read the Excel file: {file_path} ===")
        print(f"The document contains {len(df)} task")
        print(f"Column name: {list(df.columns)}")

        # Check if the necessary columns exist
        required_columns = ['frequency', 'volume', 'weight']
        missing_columns = [col for col in required_columns if col not in df.columns]

        if missing_columns:
            print(f"Warning: Missing necessary columns: {missing_columns}")
            return None

        # 显示数据概览
        print(f"\nData Overview:")
        print(f"  Frequency range: {df['frequency'].min():.1f} - {df['frequency'].max():.1f}")
        print(f"  Volume range: {df['volume'].min():.2f} - {df['volume'].max():.2f}")
        print(f"  Weight range: {df['weight'].min():.2f} - {df['weight'].max():.2f}")
        if 'remaining_time' in df.columns:
            print(f"  Remaining time range: {df['remaining_time'].min():.2f} - {df['remaining_time'].max():.2f}")

        return df

    except FileNotFoundError:
        print(f"Error: File not found {file_path}")
        print("Please ensure that the file is located in the current directory.")
        return None
    except Exception as e:
        print(f"An error occurred while reading the Excel file.: {e}")
        return None


# ============================================================================
#  Reward Function System (Maintaining the original complete reward system)
# ============================================================================

class WarehouseRewardFunction:
    """Design of Reward Function for Intelligent Warehouse System"""

    def __init__(self,
                 time_weight=0.7,  # Time-related reward weight
                 load_balance_weight=0.3,  # Load balancing reward weight
                 efficiency_weight=0,  # Efficiency Reward Weight
                 penalty_weight=0):  # Punishment weight

        self.time_weight = time_weight
        self.load_balance_weight = load_balance_weight
        self.efficiency_weight = efficiency_weight
        self.penalty_weight = penalty_weight

        # The reference value is used for normalization.
        self.baseline_task_time = 120.0
        self.baseline_total_time = 3000.0
        self.max_variance = 1000.0

    def calculate_task_completion_reward(self, task_completion_time: float,
                                         remaining_time: float = None) -> float:

        # Base time bonus: The shorter the completion time, the higher the bonus.
        time_efficiency = max(0, (self.baseline_task_time - task_completion_time) / self.baseline_task_time)
        base_reward = 100 * (1 + time_efficiency)

        # Emergency severity bonus: The higher the remaining time for a task, the greater the reward for its completion.
        urgency_bonus = 0
        if remaining_time is not None:
            if remaining_time <= 20:
                urgency_bonus = 50  # Extra reward for extremely urgent tasks
            elif remaining_time <= 40:
                urgency_bonus = 30  # Emergency Task Bonus
            elif remaining_time <= 60:
                urgency_bonus = 15  # Additional rewards for more urgent tasks

        return base_reward + urgency_bonus

    def calculate_time_performance_reward(self, current_time: float,
                                          total_tasks: int,
                                          completed_tasks: int) -> float:

        if completed_tasks == 0:
            return 0

        # Calculate the current average task completion time
        avg_completion_time = current_time / completed_tasks

        # Time efficiency bonus: The faster you complete the task, the higher the reward will be.
        time_efficiency = max(0, (self.baseline_task_time - avg_completion_time) / self.baseline_task_time)

        # Progress bonus: The higher the completion rate, the higher the bonus.
        progress_ratio = completed_tasks / total_tasks
        progress_reward = 200 * progress_ratio * (1 + time_efficiency)

        return progress_reward

    def calculate_load_balance_reward(self, equipment_loads: Dict[str, List[float]]) -> float:

        total_balance_reward = 0

        for equipment_type, loads in equipment_loads.items():
            if len(loads) <= 1:
                continue


            mean_load = np.mean(loads)
            variance = np.var(loads)


            balance_score = max(0, 1 - variance / self.max_variance)


            utilization_score = self._calculate_utilization_score(mean_load)

            equipment_reward = 50 * balance_score * utilization_score
            total_balance_reward += equipment_reward

        return total_balance_reward

    def _calculate_utilization_score(self, utilization: float) -> float:

        if 0.6 <= utilization <= 0.8:
            return 1.0
        elif utilization < 0.6:
            return utilization / 0.6
        else:
            return max(0, 2 - utilization)

    def calculate_efficiency_reward(self, total_distance: float,
                                    total_working_time: float,
                                    completed_tasks: int) -> float:

        if completed_tasks == 0:
            return 0


        avg_distance_per_task = total_distance / completed_tasks
        distance_efficiency = max(0, 1 - avg_distance_per_task / 1000)


        avg_work_time_per_task = total_working_time / completed_tasks
        work_efficiency = max(0, 1 - avg_work_time_per_task / 50)

        efficiency_reward = 100 * (distance_efficiency + work_efficiency) / 2
        return efficiency_reward

    def calculate_penalty(self, idle_time: float,
                          deadline_violations: int,
                          equipment_conflicts: int) -> float:
        """
        Calculate the penalty term

        Args:
            idle_time: idle_time:
            deadline_violations: Number of deadline violations
            equipment_conflicts: Number of equipment conflicts

        Returns:
            Penalty value (negative number)
        """
        penalty = 0


        penalty += idle_time * 10


        penalty += deadline_violations * 100


        penalty += equipment_conflicts * 50

        return -penalty

    # WarehouseRewardFunction.calculate_total_reward
    def calculate_total_reward(self, state_info: Dict) -> float:
        """
        强时间导向的奖励函数
        """
        current_time = state_info.get('current_time', 0)
        completed_task_count = state_info.get('completed_task_count', 0)
        total_tasks = state_info.get('total_tasks', 1)

        if completed_task_count == 0:
            return -current_time * 0.05
        avg_time_per_task = current_time / completed_task_count


        baseline_time = 80.0
        time_efficiency = max(0, (baseline_time - avg_time_per_task) / baseline_time)
        time_reward = 200 * time_efficiency

        if avg_time_per_task > baseline_time:
            time_penalty = -50 * ((avg_time_per_task - baseline_time) / baseline_time)
            time_reward += time_penalty

        progress_ratio = completed_task_count / total_tasks
        progress_reward = progress_ratio * 150


        completion_bonus = 0
        if progress_ratio >= 1.0:
            expected_total_time = 2000.0
            if current_time < expected_total_time:

                time_saved_ratio = (expected_total_time - current_time) / expected_total_time
                completion_bonus = 1000 * time_saved_ratio
            else:

                overtime_ratio = (current_time - expected_total_time) / expected_total_time
                completion_bonus = -200 * overtime_ratio

        total_reward = time_reward + progress_reward + completion_bonus

        return total_reward

    def get_shaped_reward(self, state_info: Dict, next_state_info: Dict) -> float:
        """
        Calculate the shaping reward (an immediate reward based on state transitions)

        Args:
            state_info: Current status information
            next_state_info: Next status information

        Returns:
            Shape-up Reward
        """

        current_reward = self.calculate_total_reward(state_info)
        next_reward = self.calculate_total_reward(next_state_info)

        # Basic Shape-Shaping Reward
        shaped_reward = next_reward - current_reward

        # Additional immediate incentives
        immediate_incentive = 0


        current_completed = state_info.get('completed_task_count', 0)
        next_completed = next_state_info.get('completed_task_count', 0)
        if next_completed > current_completed:
            immediate_incentive += (next_completed - current_completed) * 10


        current_variance = self._calculate_total_variance(state_info.get('equipment_loads', {}))
        next_variance = self._calculate_total_variance(next_state_info.get('equipment_loads', {}))
        if next_variance < current_variance:
            immediate_incentive += (current_variance - next_variance) * 0.1

        return shaped_reward + immediate_incentive

    def _calculate_total_variance(self, equipment_loads: Dict[str, List[float]]) -> float:
        """Calculate the total variance of load for all devices"""
        total_variance = 0
        for loads in equipment_loads.values():
            if len(loads) > 1:
                total_variance += np.var(loads)
        return total_variance


class WarehouseStateExtractor:
    """Warehouse System Status Extractor"""

    def __init__(self):
        self.previous_state = None

    def extract_state_info(self, shuttles, transfer_shuttles, elevators,
                           current_time, scheduler) -> Dict:
        """
        Extract status information from the warehouse system

        Args:
            shuttles: List of shuttle vehicles
            transfer_shuttles: Reprinted Dictionary of Vehicles
            elevators: Lift Dictionary
            current_time: The current time
            scheduler: Task Scheduler

        Returns:
            Status information dictionary
        """

        total_tasks = sum(len(tasks) for tasks in scheduler.zone_combined_tasks.values())
        completed_tasks = len(scheduler.completed_tasks)


        shuttle_loads = []
        transfer_loads = []
        elevator_loads = []

        # Shuttle load capacity
        for shuttle in shuttles:
            load = len(shuttle.completed_combined_tasks) / max(current_time / 100, 1)  # 任务完成率
            shuttle_loads.append(min(load, 1.0))

        # Transfer Shuttle load capacity
        for transfer_shuttle in transfer_shuttles.values():
            load = len(transfer_shuttle.completed_transfers) / max(current_time / 100, 1)
            transfer_loads.append(min(load, 1.0))

        # Lift load capacity
        for elevator in elevators.values():
            load = len(elevator.completed_lifts) / max(current_time / 100, 1)
            elevator_loads.append(min(load, 1.0))

        # Calculate the total distance and working time
        total_distance = sum(shuttle.total_distance_traveled for shuttle in shuttles)
        total_distance += sum(ts.total_distance_traveled for ts in transfer_shuttles.values())
        total_distance += sum(el.total_distance_traveled for el in elevators.values())

        total_working_time = sum(shuttle.total_working_time for shuttle in shuttles)

        # Calculate the idle time
        idle_time = 0
        for shuttle in shuttles:
            if shuttle.status == "idle":
                idle_time += 1

        # Extract the detailed information of the completed tasks
        completed_task_info = []
        for shuttle in shuttles:
            for task_info in shuttle.task_execution_log:
                completed_task_info.append({
                    'completion_time': task_info['duration'],
                    'remaining_time': task_info.get('remaining_time')
                })

        state_info = {
            'current_time': current_time,
            'total_tasks': total_tasks,
            'completed_task_count': completed_tasks,
            'completed_tasks': completed_task_info,
            'equipment_loads': {
                'shuttles': shuttle_loads,
                'transfer_shuttles': transfer_loads,
                'elevators': elevator_loads
            },
            'total_distance': total_distance,
            'total_working_time': total_working_time,
            'idle_time': idle_time,
            'deadline_violations': sum(getattr(shuttle, 'deadline_violations', 0) for shuttle in shuttles),
            'equipment_conflicts': sum(getattr(shuttle, 'equipment_conflicts', 0) for shuttle in shuttles)
        }

        return state_info


# ============================================================================
#                            Code 2: DQN Reinforcement Learning Framework
# ============================================================================

class DQNNetwork(nn.Module):
    """
    DQN neural network, used for strategy selection in the warehousing system
    """

    def __init__(self, state_dim, action_dim, hidden_dim=256):
        super(DQNNetwork, self).__init__()

        # 特征提取层
        self.feature_layers = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU()
        )

        # Strategy output layer - Outputs the Q-values of the combined actions
        self.q_values = nn.Linear(hidden_dim // 2, action_dim)

        self.apply(self._init_weights)

    def _init_weights(self, module):
        """Weight initialization"""
        if isinstance(module, nn.Linear):
            torch.nn.init.xavier_uniform_(module.weight)
            torch.nn.init.constant_(module.bias, 0)

    def forward(self, state):
        """Forward propagation"""
        features = self.feature_layers(state)
        q_values = self.q_values(features)
        return q_values


class ReplayBuffer:
    """Experience buffer zone"""

    def __init__(self, capacity=100000, batch_size=32):
        self.capacity = capacity
        self.batch_size = batch_size
        self.buffer = deque(maxlen=capacity)
        self.experience = namedtuple("Experience",
                                     field_names=["state", "action", "reward", "next_state", "done"])

    def add(self, state, action, reward, next_state, done):
        """Add experience to the buffer zone"""
        exp = self.experience(state, action, reward, next_state, done)
        self.buffer.append(exp)

    def sample(self, batch_size=None):
        """Randomly sample a batch of experiences from the buffer zone"""
        if batch_size is None:
            batch_size = self.batch_size

        experiences = random.sample(self.buffer, k=batch_size)

        states = torch.from_numpy(np.vstack([e.state for e in experiences if e is not None])).float()
        actions = torch.from_numpy(np.vstack([e.action for e in experiences if e is not None])).long()
        rewards = torch.from_numpy(np.vstack([e.reward for e in experiences if e is not None])).float()
        next_states = torch.from_numpy(np.vstack([e.next_state for e in experiences if e is not None])).float()
        dones = torch.from_numpy(np.vstack([e.done for e in experiences if e is not None]).astype(np.uint8)).float()

        return (states, actions, rewards, next_states, dones)

    def __len__(self):
        """Return the current size of the buffer area"""
        return len(self.buffer)


class WarehouseDQNAgent:
    """Warehouse system DQN agent"""

    def __init__(self, state_dim, lr=0.0003, gamma=0.95, epsilon=1.0, epsilon_min=0.05,  # 提高最小epsilon
                 epsilon_decay=0.998, buffer_size=100000, batch_size=128,  # 减慢衰减
                 update_every=4, target_update_every=1000):
        """
        Initialize the DQN agent

        Args:
            state_dim: Dimension of State
            lr: Learning rate
            gamma: Discount factor
            epsilon: ε-greedy strategy initial value
            epsilon_min: ε-min value
            epsilon_decay: εAttenuation rate
            buffer_size: Adjust the size of the deceleration zone based on experience
            batch_size: Batch size
            update_every: How often should the network be updated?
            target_update_every: How often to update the target network?
        """
        self.state_dim = state_dim
        self.lr = lr
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.batch_size = batch_size
        self.update_every = update_every
        self.target_update_every = target_update_every


        self.best_completion_time = float('inf')
        self.performance_stagnation_count = 0
        self.last_10_performance = deque(maxlen=10)


        self.storage_strategies = ["strategy_1", "strategy_2", "strategy_3"]
        self.outbound_strategies = ["strategy_1", "strategy_2", "strategy_3", "strategy_4", "strategy_5"]
        self.task_selection_strategies = ["strategy_1", "strategy_2", "strategy_3", "strategy_4"]


        self.action_dim = len(self.storage_strategies) * len(self.outbound_strategies) * len(
            self.task_selection_strategies)


        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"DQN uses equipment: {self.device}")


        self.q_network_local = DQNNetwork(state_dim, self.action_dim).to(self.device)
        self.q_network_target = DQNNetwork(state_dim, self.action_dim).to(self.device)
        self.optimizer = optim.Adam(self.q_network_local.parameters(), lr=lr)

        # Initialize the weights of the target network
        self.hard_update(self.q_network_local, self.q_network_target)

        # Experience buffer zone
        self.memory = ReplayBuffer(buffer_size, batch_size)

        # Training statistics
        self.t_step = 0
        self.update_count = 0
        self.loss_history = []
        self.q_values_history = []

        print(f"The DQN agent has been initialized successfully:")
        print(f"  Dimension of State: {state_dim}")
        print(f"  Action dimension: {self.action_dim}")
        print(f"  Storage strategy: {len(self.storage_strategies)}type")
        print(f"  Outbound inventory strategy: {len(self.outbound_strategies)}type")
        print(f"  Task selection strategy: {len(self.task_selection_strategies)}type")

    def action_to_strategies(self, action):
        """Convert the action index into a strategy combination"""

        storage_idx = action // (len(self.outbound_strategies) * len(self.task_selection_strategies))
        remaining = action % (len(self.outbound_strategies) * len(self.task_selection_strategies))
        outbound_idx = remaining // len(self.task_selection_strategies)
        task_idx = remaining % len(self.task_selection_strategies)

        storage_strategy = self.storage_strategies[storage_idx]
        outbound_strategy = self.outbound_strategies[outbound_idx]
        task_selection_strategy = self.task_selection_strategies[task_idx]

        return storage_strategy, outbound_strategy, task_selection_strategy

    def strategies_to_action(self, storage_strategy, outbound_strategy, task_selection_strategy):
        """Convert the strategy combination into an action index"""
        try:
            storage_idx = self.storage_strategies.index(storage_strategy)
            outbound_idx = self.outbound_strategies.index(outbound_strategy)
            task_idx = self.task_selection_strategies.index(task_selection_strategy)

            action = (storage_idx * len(self.outbound_strategies) * len(self.task_selection_strategies) +
                      outbound_idx * len(self.task_selection_strategies) + task_idx)

            return action
        except ValueError as e:
            print(f"Strategy misalignment: {e}")
            return 0  # 默认返回第一个动作

    def select_strategies(self, state):
        """Use the ε-greedy strategy to select actions and convert them into a policy combination."""
        state = torch.from_numpy(state).float().unsqueeze(0).to(self.device)
        self.q_network_local.eval()
        with torch.no_grad():
            action_values = self.q_network_local(state)
        self.q_network_local.train()

        # ε-Greed strategy
        if random.random() > self.epsilon:
            action = np.argmax(action_values.cpu().data.numpy())
        else:
            action = random.choice(np.arange(self.action_dim))


        return self.action_to_strategies(action), action

    def step(self, state, action, reward, next_state, done):
        """Save the experience and learn at the appropriate time"""

        self.memory.add(state, action, reward, next_state, done)

        # Learn every update_every steps.
        self.t_step = (self.t_step + 1) % self.update_every
        if self.t_step == 0:
            # If you have sufficient experience, start learning
            if len(self.memory) > self.batch_size:
                experiences = self.memory.sample()
                self.learn(experiences)

    def learn(self, experiences):
        """Learn from experience and update the Q network"""
        states, actions, rewards, next_states, dones = experiences


        states = states.to(self.device)
        actions = actions.to(self.device)
        rewards = rewards.to(self.device)
        next_states = next_states.to(self.device)
        dones = dones.to(self.device)


        Q_expected = self.q_network_local(states).gather(1, actions)


        Q_targets_next = self.q_network_target(next_states).detach().max(1)[0].unsqueeze(1)


        Q_targets = rewards + (self.gamma * Q_targets_next * (1 - dones))

        loss = F.mse_loss(Q_expected, Q_targets)
        self.loss_history.append(loss.item())


        self.q_values_history.append(Q_expected.mean().item())


        self.optimizer.zero_grad()
        loss.backward()

        torch.nn.utils.clip_grad_norm_(self.q_network_local.parameters(), 1.0)
        self.optimizer.step()


        if self.update_count % self.target_update_every == 0:
            self.soft_update(self.q_network_local, self.q_network_target, tau=0.001)

        self.update_count += 1

    def soft_update(self, local_model, target_model, tau):
        """Soft update of target network parameters"""
        for target_param, local_param in zip(target_model.parameters(), local_model.parameters()):
            target_param.data.copy_(tau * local_param.data + (1.0 - tau) * target_param.data)

    def hard_update(self, local_model, target_model):
        """Hard update of target network parameters"""
        for target_param, local_param in zip(target_model.parameters(), local_model.parameters()):
            target_param.data.copy_(local_param.data)

    def update_epsilon(self):
        """Update the epsilon value"""
        self.epsilon = max(self.epsilon_min, self.epsilon_decay * self.epsilon)

    def adaptive_update_epsilon(self, current_performance):
        """Improved adaptive epsilon adjustment"""
        self.last_10_performance.append(current_performance)


        self.epsilon = max(self.epsilon_min, self.epsilon_decay * self.epsilon)


        if len(self.last_10_performance) >= 5:
            recent_avg = np.mean(list(self.last_10_performance)[-3:])
            earlier_avg = np.mean(list(self.last_10_performance)[-5:-2])


            if recent_avg > earlier_avg * 1.05:
                self.epsilon = min(0.4, self.epsilon * 1.3)
                self.performance_stagnation_count += 1
                print(f"  It was detected that there was a decline in performance. The exploration rate has been increased to {self.epsilon:.3f}")
            elif recent_avg > earlier_avg * 0.98:
                self.performance_stagnation_count += 1
            else:
                self.performance_stagnation_count = 0


            if self.performance_stagnation_count >= 8:
                self.epsilon = 0.6
                self.performance_stagnation_count = 0
                print("  Performance continues to have issues. Reset the exploration rate to 0.6.")

    def save_model(self, filepath):
        """Save the model"""
        checkpoint = {
            'q_network_local_state_dict': self.q_network_local.state_dict(),
            'q_network_target_state_dict': self.q_network_target.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'epsilon': self.epsilon,
            'loss_history': self.loss_history,
            'q_values_history': self.q_values_history,
            'update_count': self.update_count
        }
        torch.save(checkpoint, filepath)
        print(f"The DQN model has been saved to: {filepath}")

    def load_model(self, filepath):
        """Load the model"""
        checkpoint = torch.load(filepath, map_location=self.device)
        self.q_network_local.load_state_dict(checkpoint['q_network_local_state_dict'])
        self.q_network_target.load_state_dict(checkpoint['q_network_target_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.epsilon = checkpoint['epsilon']
        self.loss_history = checkpoint.get('loss_history', [])
        self.q_values_history = checkpoint.get('q_values_history', [])
        self.update_count = checkpoint.get('update_count', 0)
        print(f"The DQN model has been loaded from {filepath} ")

    def get_training_stats(self):
        """Obtain training statistics information"""
        return {
            'update_count': self.update_count,
            'epsilon': self.epsilon,
            'memory_size': len(self.memory),
            'recent_loss': np.mean(self.loss_history[-10:]) if self.loss_history else 0,
            'recent_q_value': np.mean(self.q_values_history[-10:]) if self.q_values_history else 0
        }

# ============================================================================
#                      Tasks and Strategies Category
# ============================================================================

class Task:
    def __init__(self, task_id, task_type, warehouse_shape, mass=None, volume=None, frequency=None,
                 remaining_time=None):
        self.task_id = task_id
        self.task_type = task_type
        self.warehouse_shape = warehouse_shape


        self.mass = mass if mass is not None else round(random.uniform(1, 25), 2)
        self.volume = volume if volume is not None else round(random.uniform(1, 30), 2)
        self.frequency = frequency if frequency is not None else random.randint(1, 30)
        self.remaining_time = remaining_time

        self.zone = None
        self.cluster = None
        self.candidate_locations = []
        self.selected_location = None
        self.storage_strategy_result = None

    def find_candidate_locations_in_zone(self, warehouse, mass_limits, volume_limits, zone, used_locations):
        """Search for the five best candidate storage locations within the designated storage area"""
        valid_locations = []

        for x in range(1, self.warehouse_shape[0] + 1):
            for y in range(1, self.warehouse_shape[1] + 1):
                for z in range(1, self.warehouse_shape[2] + 1):
                    if Task._determine_zone(x, y, z) == zone:
                        location_key = (x, y, z)
                        if (warehouse[x, y, z] == 0 and
                                self.mass <= mass_limits[x, y, z] and
                                self.volume <= volume_limits[x, y, z] and
                                location_key not in used_locations):
                            lmd_value = (mass_limits[x, y, z] / self.mass) * (volume_limits[x, y, z] / self.volume)
                            valid_locations.append((x, y, z, lmd_value))

        if valid_locations:
            valid_locations.sort(key=lambda x: x[3], reverse=True)
            top_5_locations = valid_locations[:5]
            self.candidate_locations = top_5_locations
            return True
        else:
            self.candidate_locations = []
            return False

    @staticmethod
    def _determine_zone(x, y, z):
        """Determine the cargo area to which the coordinates belong"""
        if 1 <= x <= 8 and 1 <= y <= 28 and 1 <= z <= 8:
            return "A Area"
        elif ((1 <= x <= 8 and 1 <= y <= 34 and 9 <= z <= 11) or
              (1 <= x <= 8 and 29 <= y <= 34 and 1 <= z <= 8) or
              (9 <= x <= 12 and 1 <= y <= 34 and 1 <= z <= 11)):
            return "B Area"
        elif ((1 <= x <= 12 and 1 <= y <= 40 and 12 <= z <= 14) or
              (1 <= x <= 12 and 35 <= y <= 40 and 1 <= z <= 11) or
              (13 <= x <= 16 and 1 <= y <= 40 and 1 <= z <= 14)):
            return "C Area"
        else:
            return "Uncharted Area"

    def __str__(self):
        remaining_str = f", Remaining time: {self.remaining_time:.2f}" if self.remaining_time is not None else ""
        if self.selected_location:
            return f"Task ID: {self.task_id}, Type: Inventory, Quality: {self.mass}kg, Volume: {self.volume}dm³, " \
                   f"Frequency: {self.frequency}times/week{remaining_str}, Storage area: {self.zone}, Select the storage location: {self.selected_location}"
        else:
            return f"Task ID: {self.task_id}, Type: Inventory, Quality:  {self.mass}kg, Volume: {self.volume}dm³, " \
                   f"Frequency: {self.frequency}times/week{remaining_str}, Storage area: {self.zone}"


# Define the outbound task class
class OutboundTask:
    def __init__(self, task_id, source_location, warehouse_shape):
        self.task_id = task_id
        self.task_type = "outbound"
        self.source_location = source_location
        self.warehouse_shape = warehouse_shape
        self.zone = Task._determine_zone(source_location[0], source_location[1], source_location[2])
        self.mass = None
        self.volume = None
        self.frequency = None
        self.lmd_value = None

    def set_item_properties(self, mass, volume, frequency):
        """Set the attributes of the goods"""
        self.mass = mass
        self.volume = volume
        self.frequency = frequency

    def calculate_lmd(self, mass_limits, volume_limits):
        """Calculate the LMD value"""
        if self.mass and self.volume:
            x, y, z = self.source_location
            self.lmd_value = (mass_limits[x, y, z] / self.mass) * (volume_limits[x, y, z] / self.volume)
            return self.lmd_value
        return None

    def __str__(self):
        return f"Task ID: {self.task_id}, Type: Outbound, Outbound Location: {self.source_location}, Storage area: {self.zone}"


# Define the composite task class
class CombinedTask:
    def __init__(self, task_id, inbound_task, outbound_task, outbound_strategy="strategy_1"):
        self.task_id = task_id
        self.inbound_task = inbound_task
        self.outbound_task = outbound_task
        self.zone = inbound_task.zone
        self.outbound_strategy = outbound_strategy

    def __str__(self):
        return f"组合任务 {self.task_id}: 入库{self.inbound_task.selected_location} + 出库{self.outbound_task.source_location} (出库策略: {self.outbound_strategy})"


# Improved storage strategy class - Supports 3 types of strategy selection
class StorageStrategy:
    @staticmethod
    def strategy_1_random_storage(task, warehouse, mass_limits, volume_limits, zone, used_locations):
        """Strategy 1: Random Storage Principle - Select a random empty storage space within the warehouse area for storage."""

        valid_locations = []

        for x in range(1, task.warehouse_shape[0] + 1):
            for y in range(1, task.warehouse_shape[1] + 1):
                for z in range(1, task.warehouse_shape[2] + 1):
                    if Task._determine_zone(x, y, z) == zone:
                        location_key = (x, y, z)

                        if (warehouse[x, y, z] == 0 and
                                task.mass <= mass_limits[x, y, z] and
                                task.volume <= volume_limits[x, y, z] and
                                location_key not in used_locations):

                            lmd_value = (mass_limits[x, y, z] / task.mass) * (volume_limits[x, y, z] / task.volume)
                            valid_locations.append((x, y, z, lmd_value))

        if valid_locations:

            selected_candidate = random.choice(valid_locations)
            x, y, z, lmd = selected_candidate
            return {
                'strategy': 'Random storage',
                'selected_location': (x, y, z),
                'lmd_value': lmd,
                'z_coordinate': z,
                'reason': f'Randomly select a storage location from the {len(valid_locations)} eligible empty storage locations within the {zone} area ({x},{y},{z})'
            }
        else:
            return {
                'strategy': 'Random storage',
                'selected_location': None,
                'reason': f'No suitable empty storage spaces were found in the{zone}'
            }

    @staticmethod
    def strategy_2_highest_lmd(task):
        """Strategy 2"""
        if task.candidate_locations:

            best_candidate = task.candidate_locations[0]
            x, y, z, lmd = best_candidate
            return {
                'strategy': 'Highest matching degree',
                'selected_location': (x, y, z),
                'lmd_value': lmd,
                'z_coordinate': z,
                'reason': f'Choose the one with the highest LMD value({lmd:.4f})storage location({x},{y},{z})'
            }
        else:
            return {
                'strategy': 'Highest matching degree',
                'selected_location': None,
                'reason': 'No candidate storage location'
            }

    @staticmethod
    def strategy_3_lmd_with_z_priority(task, lmd_threshold_ratio=0.95):
        """Strategy 3"""
        if task.candidate_locations:
            max_lmd = task.candidate_locations[0][3]
            lmd_threshold = max_lmd * lmd_threshold_ratio

            qualified_locations = []
            for x, y, z, lmd in task.candidate_locations:
                if lmd >= lmd_threshold:
                    qualified_locations.append((x, y, z, lmd))

            if qualified_locations:

                best_location = min(qualified_locations, key=lambda loc: loc[2])
                x, y, z, lmd = best_location
                return {
                    'strategy': 'Match degree + Z coordinate priority',
                    'selected_location': (x, y, z),
                    'lmd_value': lmd,
                    'z_coordinate': z,
                    'reason': f'At LMD≥{lmd_threshold:.4f} {len(qualified_locations)}Select the storage location with the smallest z-coordinate {z} among all the locations'
                }
            else:

                x, y, z, lmd = task.candidate_locations[0]
                return {
                    'strategy': 'Match degree + Z coordinate priority',
                    'selected_location': (x, y, z),
                    'lmd_value': lmd,
                    'z_coordinate': z,
                    'reason': f'If there is no available storage location that meets the LMD threshold, select the storage location with the highest LMD value.'
                }
        else:
            return {
                'strategy': 'Match degree + Z coordinate priority',
                'selected_location': None,
                'reason': 'No candidate storage location'
            }

    @staticmethod
    def select_storage_location(task, strategy_name="strategy_3", warehouse=None, mass_limits=None, volume_limits=None,
                                zone=None, used_locations=None):
        """Select the storage location based on the strategy name"""
        if strategy_name == "strategy_1":
            return StorageStrategy.strategy_1_random_storage(task, warehouse, mass_limits, volume_limits, zone,
                                                             used_locations)
        elif strategy_name == "strategy_2":
            return StorageStrategy.strategy_2_highest_lmd(task)
        elif strategy_name == "strategy_3":
            return StorageStrategy.strategy_3_lmd_with_z_priority(task)
        else:
            return StorageStrategy.strategy_3_lmd_with_z_priority(task)

    @staticmethod
    def strategy_warehouse_wide_random(task, warehouse, mass_limits, volume_limits, used_locations):
        valid_locations = []

        for x in range(1, task.warehouse_shape[0] + 1):
            for y in range(1, task.warehouse_shape[1] + 1):
                for z in range(1, task.warehouse_shape[2] + 1):
                    location_key = (x, y, z)
                    if (warehouse[x, y, z] == 0 and
                            task.mass <= mass_limits[x, y, z] and
                            task.volume <= volume_limits[x, y, z] and
                            location_key not in used_locations):
                        lmd_value = (mass_limits[x, y, z] / task.mass) * (volume_limits[x, y, z] / task.volume)
                        location_zone = Task._determine_zone(x, y, z)
                        valid_locations.append((x, y, z, lmd_value, location_zone))

        if valid_locations:
            # Randomly select one from all the eligible empty storage spaces.
            selected_candidate = random.choice(valid_locations)
            x, y, z, lmd, zone = selected_candidate
            return {
                'strategy': 'Random storage throughout the entire warehouse',
                'selected_location': (x, y, z),
                'lmd_value': lmd,
                'z_coordinate': z,
                'assigned_zone': zone,
                'reason': f'Throughout the entire warehouse area{len(valid_locations)}Randomly select a cargo position from the available cargo positions that meet the requirements ({x},{y},{z}), assigned to{zone}'
            }
        else:
            return {
                'strategy': 'Random storage throughout the entire warehouse',
                'selected_location': None,
                'reason': 'No suitable empty storage spaces were found throughout the entire warehouse'
            }


class OutboundStrategy:
    """Outbound Strategy Class """

    @staticmethod
    def strategy_1_shortest_distance(inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape,
                                     occupied_items=None):
        """Strategy 1: Principle of Shortest Distance"""
        if not inbound_task.selected_location:
            return None

        target_x, target_y, target_z = inbound_task.selected_location
        available_locations = []


        for y in range(1, warehouse_shape[1] + 1):
            if (warehouse[target_x, y, target_z] == 1 and
                    (target_x, y, target_z) != inbound_task.selected_location):
                distance = abs(y - target_y)
                available_locations.append(((target_x, y, target_z), distance))

        if available_locations:
            available_locations.sort(key=lambda x: x[1])
            selected_location = available_locations[0][0]


            outbound_task = OutboundTask(
                f"out_{inbound_task.task_id.split('_')[1]}",
                selected_location,
                warehouse_shape
            )


            x, y, z = selected_location
            if occupied_items and selected_location in occupied_items:
                item_info = occupied_items[selected_location]
                outbound_task.set_item_properties(item_info['mass'], item_info['volume'], item_info['frequency'])
            else:
                outbound_task.set_item_properties(
                    round(random.uniform(1, 25), 2),
                    round(random.uniform(1, 30), 2),
                    random.randint(1, 30)
                )

            outbound_task.calculate_lmd(mass_limits, volume_limits)

            return outbound_task
        else:
            return None

    @staticmethod
    def strategy_2_lmd_similarity(inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape,
                                  occupied_items=None):
        """Strategy 2: Principle of Close Item Position Matching"""
        if not inbound_task.selected_location:
            return None

        inbound_zone = inbound_task.zone
        target_x, target_y, target_z = inbound_task.selected_location


        inbound_lmd = (mass_limits[target_x, target_y, target_z] / inbound_task.mass) * \
                      (volume_limits[target_x, target_y, target_z] / inbound_task.volume)

        available_locations = []


        for x in range(1, warehouse_shape[0] + 1):
            for y in range(1, warehouse_shape[1] + 1):
                for z in range(1, warehouse_shape[2] + 1):
                    location = (x, y, z)
                    if (Task._determine_zone(x, y, z) == inbound_zone and
                            warehouse[x, y, z] == 1 and
                            location != inbound_task.selected_location and
                            location in occupied_items):


                        item_info = occupied_items[location]
                        outbound_lmd = (mass_limits[x, y, z] / item_info['mass']) * \
                                       (volume_limits[x, y, z] / item_info['volume'])


                        lmd_diff = abs(outbound_lmd - inbound_lmd)
                        available_locations.append((location, lmd_diff, outbound_lmd))

        if available_locations:
            available_locations.sort(key=lambda x: x[1])
            selected_location, min_lmd_diff, selected_lmd = available_locations[0]

            outbound_task = OutboundTask(
                f"out_{inbound_task.task_id.split('_')[1]}",
                selected_location,
                warehouse_shape
            )


            item_info = occupied_items[selected_location]
            outbound_task.set_item_properties(item_info['mass'], item_info['volume'], item_info['frequency'])
            outbound_task.calculate_lmd(mass_limits, volume_limits)

            return outbound_task
        else:
            return None

    @staticmethod
    def strategy_3_random_selection(inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape,
                                    occupied_items=None):
        """Strategy 3: Random Selection"""
        if not inbound_task.selected_location:
            return None

        inbound_zone = inbound_task.zone
        available_locations = []


        for x in range(1, warehouse_shape[0] + 1):
            for y in range(1, warehouse_shape[1] + 1):
                for z in range(1, warehouse_shape[2] + 1):
                    location = (x, y, z)
                    if (Task._determine_zone(x, y, z) == inbound_zone and
                            warehouse[x, y, z] == 1 and
                            location != inbound_task.selected_location):
                        available_locations.append(location)

        if available_locations:
            selected_location = random.choice(available_locations)

            outbound_task = OutboundTask(
                f"out_{inbound_task.task_id.split('_')[1]}",
                selected_location,
                warehouse_shape
            )

            # Set the attributes of the goods
            if occupied_items and selected_location in occupied_items:
                item_info = occupied_items[selected_location]
                outbound_task.set_item_properties(item_info['mass'], item_info['volume'], item_info['frequency'])
            else:
                outbound_task.set_item_properties(
                    round(random.uniform(1, 25), 2),
                    round(random.uniform(1, 30), 2),
                    random.randint(1, 30)
                )

            outbound_task.calculate_lmd(mass_limits, volume_limits)

            return outbound_task
        else:
            return None

    @staticmethod
    def strategy_4_highest_frequency(inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape,
                                     occupied_items=None):
        """Strategy 4: Prioritize Inventory Inbound and Outbound Frequency"""
        if not inbound_task.selected_location:
            return None

        inbound_zone = inbound_task.zone
        available_locations = []


        for x in range(1, warehouse_shape[0] + 1):
            for y in range(1, warehouse_shape[1] + 1):
                for z in range(1, warehouse_shape[2] + 1):
                    location = (x, y, z)
                    if (Task._determine_zone(x, y, z) == inbound_zone and
                            warehouse[x, y, z] == 1 and
                            location != inbound_task.selected_location and
                            location in occupied_items):

                        item_info = occupied_items[location]
                        frequency = item_info['frequency']
                        available_locations.append((location, frequency))

        if available_locations:
            available_locations.sort(key=lambda x: x[1], reverse=True)
            max_frequency = available_locations[0][1]

            highest_freq_locations = [loc for loc, freq in available_locations if freq == max_frequency]

            selected_location = random.choice(highest_freq_locations)


            outbound_task = OutboundTask(
                f"out_{inbound_task.task_id.split('_')[1]}",
                selected_location,
                warehouse_shape
            )

            # 设置货物属性
            item_info = occupied_items[selected_location]
            outbound_task.set_item_properties(item_info['mass'], item_info['volume'], item_info['frequency'])
            outbound_task.calculate_lmd(mass_limits, volume_limits)

            return outbound_task
        else:
            return None

    @staticmethod
    def strategy_5_lmd_distance_combined(inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape,
                                         occupied_items=None):
        """Strategy 5: Combine Strategy 2 and Strategy 1"""
        if not inbound_task.selected_location:
            return None

        inbound_zone = inbound_task.zone
        target_x, target_y, target_z = inbound_task.selected_location

        # Calculate the LMD value of the storage location for the incoming goods
        inbound_lmd = (mass_limits[target_x, target_y, target_z] / inbound_task.mass) * \
                      (volume_limits[target_x, target_y, target_z] / inbound_task.volume)

        available_locations = []

        # Search for non-empty storage locations within the same storage area
        for x in range(1, warehouse_shape[0] + 1):
            for y in range(1, warehouse_shape[1] + 1):
                for z in range(1, warehouse_shape[2] + 1):
                    location = (x, y, z)
                    if (Task._determine_zone(x, y, z) == inbound_zone and
                            warehouse[x, y, z] == 1 and
                            location != inbound_task.selected_location and
                            location in occupied_items):

                        item_info = occupied_items[location]
                        outbound_lmd = (mass_limits[x, y, z] / item_info['mass']) * \
                                       (volume_limits[x, y, z] / item_info['volume'])


                        lmd_diff = abs(outbound_lmd - inbound_lmd)
                        distance = math.sqrt((x - target_x) ** 2 + (y - target_y) ** 2 + (z - target_z) ** 2)

                        available_locations.append((location, lmd_diff, distance, outbound_lmd))

        if available_locations:
            available_locations.sort(key=lambda x: x[1])
            top_5_lmd = available_locations[:5]

            top_5_lmd.sort(key=lambda x: x[2])
            selected_location, lmd_diff, min_distance, selected_lmd = top_5_lmd[0]

            # Create an outbound delivery task
            outbound_task = OutboundTask(
                f"out_{inbound_task.task_id.split('_')[1]}",
                selected_location,
                warehouse_shape
            )

            # Set the attributes of the goods
            item_info = occupied_items[selected_location]
            outbound_task.set_item_properties(item_info['mass'], item_info['volume'], item_info['frequency'])
            outbound_task.calculate_lmd(mass_limits, volume_limits)

            return outbound_task
        else:
            return None

    @staticmethod
    def select_outbound_location(inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape,
                                 occupied_items=None, strategy_name="strategy_1"):
        """Select the outbound location based on the strategy name"""
        strategy_functions = {
            "strategy_1": OutboundStrategy.strategy_1_shortest_distance,
            "strategy_2": OutboundStrategy.strategy_2_lmd_similarity,
            "strategy_3": OutboundStrategy.strategy_3_random_selection,
            "strategy_4": OutboundStrategy.strategy_4_highest_frequency,
            "strategy_5": OutboundStrategy.strategy_5_lmd_distance_combined
        }

        if strategy_name in strategy_functions:
            return strategy_functions[strategy_name](
                inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape, occupied_items
            )
        else:
            return OutboundStrategy.strategy_1_shortest_distance(
                inbound_task, warehouse, mass_limits, volume_limits, warehouse_shape, occupied_items
            )


# ============================================================================
#                        Equipment category
# ============================================================================

# Define a time manager
class TimeManager:
    def __init__(self):
        self.current_time = 0.0

    def get_current_time(self):
        return self.current_time

    def advance_time(self, delta_time):
        self.current_time += delta_time

    def reset(self):
        self.current_time = 0.0


# Define the motion calculator
class MotionCalculator:
    def __init__(self,
                 shuttle_velocity=3.0, transfer_velocity=3.0, elevator_velocity=4.0,
                 shuttle_acceleration=2.0, transfer_acceleration=2.0, elevator_acceleration=3.0,
                 aisle_width=0.6,
                 shelf_spacing=0.8,
                 floor_height=0.8,
                 shuttle_depth=0.6):

        # Maximum speed
        self.shuttle_velocity = shuttle_velocity
        self.transfer_velocity = transfer_velocity
        self.elevator_velocity = elevator_velocity

        # Acceleration
        self.shuttle_acceleration = shuttle_acceleration
        self.transfer_acceleration = transfer_acceleration
        self.elevator_acceleration = elevator_acceleration


        self.aisle_width = aisle_width
        self.shelf_spacing = shelf_spacing
        self.floor_height = floor_height
        self.shuttle_depth = shuttle_depth


        self.single_aisle_distance = aisle_width
        self.single_shelf_distance = shelf_spacing
        self.single_floor_distance = floor_height

    def _calculate_travel_time_with_acceleration(self, distance, max_velocity, acceleration):
        """
        Calculate the moving time taking into account acceleration

        Args:
            distance: Distance moved (m)
            max_velocity: Maximum speed (m/s)
            acceleration: Acceleration (m/s²)

        Returns:
            The time required for movement (s)
        """
        if distance <= 0:
            return 0.0

        critical_distance = max_velocity * max_velocity / acceleration

        if distance <= critical_distance:
            travel_time = 2 * math.sqrt(distance / acceleration)
        else:
            t_accel = max_velocity / acceleration
            t_decel = t_accel
            s_accel = 0.5 * acceleration * t_accel * t_accel
            s_decel = s_accel
            s_uniform = distance - s_accel - s_decel
            t_uniform = s_uniform / max_velocity
            travel_time = t_accel + t_uniform + t_decel

        return travel_time

    def calculate_shuttle_travel_time(self, distance):
        """Calculate the time required for the shuttle vehicle to travel the specified distance"""
        return self._calculate_travel_time_with_acceleration(
            distance, self.shuttle_velocity, self.shuttle_acceleration)

    def calculate_transfer_travel_time(self, distance):
        """Calculate the time required for the transfer shuttle to travel the specified distance"""
        return self._calculate_travel_time_with_acceleration(
            distance, self.transfer_velocity, self.transfer_acceleration)

    def calculate_elevator_travel_time(self, distance):
        """Calculate the time required for the hoist to move the specified distance"""
        return self._calculate_travel_time_with_acceleration(
            distance, self.elevator_velocity, self.elevator_acceleration)

    def calculate_distance(self, pos1, pos2):
        return math.sqrt(
            (pos2[0] - pos1[0]) ** 2 +
            (pos2[1] - pos1[1]) ** 2 +
            (pos2[2] - pos1[2]) ** 2
        )

    def get_motion_profile(self, distance, max_velocity, acceleration):
        """
        Obtain the motion contour information

        Returns:
            dict: Including detailed information about each stage of the movement
        """
        if distance <= 0:
            return {"type": "no_motion", "total_time": 0}

        critical_distance = max_velocity * max_velocity / acceleration

        if distance <= critical_distance:
            total_time = 2 * math.sqrt(distance / acceleration)
            max_speed_reached = math.sqrt(distance * acceleration)

            return {
                "type": "triangular",
                "total_time": total_time,
                "max_speed_reached": max_speed_reached,
                "accel_time": total_time / 2,
                "decel_time": total_time / 2,
                "uniform_time": 0,
                "accel_distance": distance / 2,
                "uniform_distance": 0,
                "decel_distance": distance / 2
            }
        else:
            t_accel = max_velocity / acceleration
            s_accel = 0.5 * acceleration * t_accel * t_accel
            s_decel = s_accel
            t_decel = t_accel
            s_uniform = distance - s_accel - s_decel
            t_uniform = s_uniform / max_velocity
            total_time = t_accel + t_uniform + t_decel

            return {
                "type": "trapezoidal",
                "total_time": total_time,
                "max_speed_reached": max_velocity,
                "accel_time": t_accel,
                "uniform_time": t_uniform,
                "decel_time": t_decel,
                "accel_distance": s_accel,
                "uniform_distance": s_uniform,
                "decel_distance": s_decel
            }

    def calculate_shuttle_travel_time_by_coordinates(self, start_pos, end_pos):
        """
        Calculate the moving time of the shuttle vehicle based on the coordinates (taking into account the actual physical distance)
        """
        x1, y1, z1 = start_pos
        x2, y2, z2 = end_pos


        y_distance = abs(y2 - y1) * self.aisle_width


        depth_moves = 0
        if x1 != x2 or z1 != z2:
            depth_moves = max(abs(x2 - x1), abs(z2 - z1))

        total_distance = y_distance + depth_moves * self.shuttle_depth

        return self._calculate_travel_time_with_acceleration(
            total_distance, self.shuttle_velocity, self.shuttle_acceleration)

    def calculate_shuttle_travel_time(self, coordinate_distance, movement_type="y_axis"):
        """
        Calculate the moving time of the shuttle based on the coordinate differences
        """
        if movement_type == "y_axis":
            actual_distance = coordinate_distance * self.aisle_width
        elif movement_type == "depth":
            actual_distance = coordinate_distance * self.shuttle_depth
        else:
            actual_distance = coordinate_distance

        return self._calculate_travel_time_with_acceleration(
            actual_distance, self.shuttle_velocity, self.shuttle_acceleration)

    def calculate_transfer_travel_time_by_coordinates(self, start_pos, end_pos):
        """
        Calculate the moving time of the transfer vehicle based on the coordinates
        """
        x1, y1, z1 = start_pos
        x2, y2, z2 = end_pos

        x_distance = abs(x2 - x1) * self.shelf_spacing

        return self._calculate_travel_time_with_acceleration(
            x_distance, self.transfer_velocity, self.transfer_acceleration)

    def calculate_transfer_travel_time(self, coordinate_distance):
        """
        Calculate the moving time of the transfer vehicle based on the difference in x-coordinates.
        """
        actual_distance = coordinate_distance * self.shelf_spacing
        return self._calculate_travel_time_with_acceleration(
            actual_distance, self.transfer_velocity, self.transfer_acceleration)

    def calculate_elevator_travel_time_by_coordinates(self, start_pos, end_pos):
        """
        Calculate the moving time of the elevator based on the coordinates
        """
        x1, y1, z1 = start_pos
        x2, y2, z2 = end_pos

        z_distance = abs(z2 - z1) * self.floor_height

        return self._calculate_travel_time_with_acceleration(
            z_distance, self.elevator_velocity, self.elevator_acceleration)

    def calculate_elevator_travel_time(self, coordinate_distance):
        """
        Calculate the moving time of the elevator based on the z-coordinate difference (taking into account the actual floor height)
        """
        actual_distance = coordinate_distance * self.floor_height
        return self._calculate_travel_time_with_acceleration(
            actual_distance, self.elevator_velocity, self.elevator_acceleration)

    def calculate_actual_distance(self, pos1, pos2):
        """
        Calculate the actual physical distance between the two points (taking into account the actual dimensions of each axis)
        """
        x1, y1, z1 = pos1
        x2, y2, z2 = pos2


        x_actual = abs(x2 - x1) * self.shelf_spacing
        y_actual = abs(y2 - y1) * self.aisle_width
        z_actual = abs(z2 - z1) * self.floor_height


        actual_distance = math.sqrt(x_actual ** 2 + y_actual ** 2 + z_actual ** 2)

        return actual_distance



def test_motion_with_acceleration():
    """A motion calculator that takes acceleration into account for testing"""
    calculator = MotionCalculator(
        shuttle_velocity=3.0, shuttle_acceleration=2.0,
        transfer_velocity=3.0, transfer_acceleration=2.0,
        elevator_velocity=4.0, elevator_acceleration=3.0
    )


    test_distances = [1, 2, 4.5, 10, 20]

    print("Shuttle vehicle motion analysis (maximum speed: 3 m/s, acceleration: 2 m/s²):")
    print(f"{'distance(m)':<8} {'time(s)':<8} {'Shape type':<12} {'max speed(m/s)':<15}")
    print("-" * 55)

    for distance in test_distances:
        time = calculator.calculate_shuttle_travel_time(distance)
        profile = calculator.get_motion_profile(distance, 3.0, 2.0)
        print(f"{distance:<8} {time:<8.2f} {profile['type']:<12} {profile['max_speed_reached']:<15.2f}")

    print(f"\nCritical distance: {3.0 * 3.0 / 2.0:.1f}m ")


# Compare the differences between the new and old calculation methods
def compare_old_vs_new_motion():

    def old_calculate_time(distance, velocity):
        return distance / velocity if distance > 0 else 0

    calculator = MotionCalculator()

    distances = [1, 2, 4.5, 10, 20, 50]

    print("\nCompare the differences between the new and old calculation methods:")
    print(f"{'distance(m)':<8} {'old method(s)':<10} {'new methods(s)':<10} {'Differences(s)':<8} {'Relative difference(%)':<12}")
    print("-" * 55)

    for distance in distances:
        old_time = old_calculate_time(distance, 3.0)
        new_time = calculator.calculate_shuttle_travel_time(distance)
        diff = new_time - old_time
        relative_diff = (diff / old_time) * 100 if old_time > 0 else 0

        print(f"{distance:<8} {old_time:<10.2f} {new_time:<10.2f} {diff:<8.2f} {relative_diff:<12.1f}")


class TransferShuttle:
    """Reconnaissance vehicle - Responsible for the x-axis movement of the shuttle vehicle, and carrying the shuttle vehicle for cross-aisle transportation"""

    def __init__(self, transfer_id, assigned_level, motion_calculator):
        self.transfer_id = transfer_id
        self.assigned_level = assigned_level
        self.motion_calculator = motion_calculator


        self.x, self.y, self.z = 1, 1, assigned_level
        self.initial_position = (self.x, self.y, self.z)


        self.status = "idle"
        self.carried_shuttle = None
        self.target_position = None
        self.movement_start_time = 0.0
        self.movement_duration = 0.0
        self.total_distance_traveled = 0.0
        self.total_working_time = 0.0

        # Task Queue: Stores information about the shuttle vehicles that need to be repositioned.
        self.transfer_queue = []
        self.completed_transfers = []


        self.idle_time_total = 0.0
        self.idle_start_time = None
        self.episode_idle_times = []
        self.current_episode_idle_time = 0.0

    def add_transfer_request(self, shuttle, target_x, current_time):
        """Request for Reprint Permission"""
        transfer_request = {
            'shuttle': shuttle,
            'pickup_x': shuttle.x,
            'target_x': target_x,
            'pickup_y': shuttle.y,
            'created_time': current_time,
            'shuttle_id': shuttle.shuttle_id
        }
        self.transfer_queue.append(transfer_request)

    def start_next_transfer(self, current_time):
        """Start to carry out the next copy task"""
        if self.status != "idle" or not self.transfer_queue:
            return False

        current_request = self.transfer_queue.pop(0)
        shuttle = current_request['shuttle']
        pickup_x = current_request['pickup_x']

        # Move to the loading position
        if self.x != pickup_x:
            self.target_position = (pickup_x, 1, self.assigned_level)
            coordinate_distance = abs(self.x - pickup_x)
            self.movement_duration = self.motion_calculator.calculate_transfer_travel_time(coordinate_distance)
            self.movement_start_time = current_time
            actual_distance = coordinate_distance * self.motion_calculator.shelf_spacing
            self.total_distance_traveled += actual_distance
            self.status = "moving_to_pickup"
            self.current_request = current_request
        else:
            self._pickup_shuttle(current_request, current_time)

        return True

    def _pickup_shuttle(self, request, current_time):
        shuttle = request['shuttle']
        self.carried_shuttle = shuttle
        self.current_request = request

        shuttle.status = "on_transfer_shuttle"
        shuttle.x = self.x

        target_x = request['target_x']
        if self.x != target_x:
            self.target_position = (target_x, 1, self.assigned_level)
            distance = abs(self.x - target_x)
            self.movement_duration = self.motion_calculator.calculate_transfer_travel_time(distance)
            self.movement_start_time = current_time
            self.total_distance_traveled += distance
            self.status = "moving_to_dropoff"
        else:
            self._dropoff_shuttle(current_time)

    def _dropoff_shuttle(self, current_time):
        if self.carried_shuttle:
            shuttle = self.carried_shuttle
            shuttle.status = "idle"
            shuttle.x = self.x

            transfer_info = {
                'shuttle_id': shuttle.shuttle_id,
                'start_time': self.current_request['created_time'],
                'end_time': current_time,
                'duration': current_time - self.current_request['created_time'],
                'from_x': self.current_request['pickup_x'],
                'to_x': self.current_request['target_x']
            }
            self.completed_transfers.append(transfer_info)


            shuttle.on_transfer_completed(current_time)

            self.carried_shuttle = None
            self.current_request = None

        self.status = "idle"
        self.target_position = None

    def update(self, current_time):
        """Update the status of the transfer vehicle"""
        if self.status == "idle":
            if self.idle_start_time is None:
                self.idle_start_time = current_time


            if self.start_next_transfer(current_time):
                if self.idle_start_time is not None:
                    idle_duration = current_time - self.idle_start_time
                    self.idle_time_total += idle_duration
                    self.current_episode_idle_time += idle_duration
                    self.idle_start_time = None
            return
        else:
            if self.idle_start_time is not None:
                idle_duration = current_time - self.idle_start_time
                self.idle_time_total += idle_duration
                self.current_episode_idle_time += idle_duration
                self.idle_start_time = None

        elapsed_time = current_time - self.movement_start_time

        if elapsed_time >= self.movement_duration:
            if self.status == "moving_to_pickup":
                self.x = self.target_position[0]
                self._pickup_shuttle(self.current_request, current_time)
            elif self.status == "moving_to_dropoff":
                self.x = self.target_position[0]
                if self.carried_shuttle:
                    self.carried_shuttle.x = self.x
                self._dropoff_shuttle(current_time)

    def get_position(self):
        return (self.x, self.y, self.z)

    def __str__(self):
        return f"transfer shuttle {self.transfer_id} (tier{self.assigned_level}): location ({self.x}, {self.y}, {self.z}), status: {self.status}"

    def reset_episode_stats(self):
        """Reset the episode statistics data"""
        if self.idle_start_time is not None:
            pass

        self.episode_idle_times.append(self.current_episode_idle_time)
        self.current_episode_idle_time = 0.0



class Elevator:
    """Lift equipment category"""

    def __init__(self, elevator_id, initial_x, motion_calculator):
        self.elevator_id = elevator_id
        self.motion_calculator = motion_calculator


        self.x, self.y, self.z = initial_x, 1, 1
        self.initial_position = (self.x, self.y, self.z)


        self.status = "idle"  # idle, carrying_shuttle, moving_to_pickup, moving_to_dropoff
        self.carried_shuttle = None
        self.target_position = None
        self.movement_start_time = 0.0
        self.movement_duration = 0.0
        self.total_distance_traveled = 0.0
        self.total_working_time = 0.0


        self.lift_queue = []
        self.completed_lifts = []


        self.idle_time_total = 0.0
        self.idle_start_time = None
        self.episode_idle_times = []
        self.current_episode_idle_time = 0.0

    def add_lift_request(self, shuttle, target_z, current_time):
        """Request for adding an lift"""
        lift_request = {
            'shuttle': shuttle,
            'pickup_z': shuttle.z,
            'target_z': target_z,
            'pickup_x': shuttle.x,
            'created_time': current_time,
            'shuttle_id': shuttle.shuttle_id
        }
        self.lift_queue.append(lift_request)

    def start_next_lift(self, current_time):
        """Start to carry out the next promotion task"""
        if self.status != "idle" or not self.lift_queue:
            return False

        current_request = self.lift_queue.pop(0)
        shuttle = current_request['shuttle']
        pickup_z = current_request['pickup_z']
        pickup_x = current_request['pickup_x']


        if self.z != pickup_z:
            self.target_position = (self.x, 1, pickup_z)
            coordinate_distance = abs(self.z - pickup_z)
            self.movement_duration = self.motion_calculator.calculate_elevator_travel_time(coordinate_distance)
            self.movement_start_time = current_time
            actual_distance = coordinate_distance * self.motion_calculator.floor_height
            self.total_distance_traveled += actual_distance
            self.status = "moving_to_pickup"
            self.current_request = current_request
        else:
            self._pickup_shuttle(current_request, current_time)

        return True

    def _pickup_shuttle(self, request, current_time):
        """Carrying shuttle vehicle"""
        shuttle = request['shuttle']
        self.carried_shuttle = shuttle
        self.current_request = request

        shuttle.status = "on_elevator"
        shuttle.z = self.z


        target_z = request['target_z']
        if self.z != target_z:
            self.target_position = (self.x, 1, target_z)
            distance = abs(self.z - target_z)
            self.movement_duration = self.motion_calculator.calculate_elevator_travel_time(distance)
            self.movement_start_time = current_time
            self.total_distance_traveled += distance
            self.status = "moving_to_dropoff"
        else:
            self._dropoff_shuttle(current_time)

    def _dropoff_shuttle(self, current_time):
        if self.carried_shuttle:
            shuttle = self.carried_shuttle
            shuttle.status = "idle"
            shuttle.z = self.z


            lift_info = {
                'shuttle_id': shuttle.shuttle_id,
                'start_time': self.current_request['created_time'],
                'end_time': current_time,
                'duration': current_time - self.current_request['created_time'],
                'from_z': self.current_request['pickup_z'],
                'to_z': self.current_request['target_z']
            }
            self.completed_lifts.append(lift_info)


            shuttle.on_lift_completed(current_time)

            self.carried_shuttle = None
            self.current_request = None

        self.status = "idle"
        self.target_position = None

    def update(self, current_time):
        if self.status == "idle":
            if self.idle_start_time is None:
                self.idle_start_time = current_time

            if self.start_next_lift(current_time):
                if self.idle_start_time is not None:
                    idle_duration = current_time - self.idle_start_time
                    self.idle_time_total += idle_duration
                    self.current_episode_idle_time += idle_duration
                    self.idle_start_time = None
            return
        else:
            if self.idle_start_time is not None:
                idle_duration = current_time - self.idle_start_time
                self.idle_time_total += idle_duration
                self.current_episode_idle_time += idle_duration
                self.idle_start_time = None

        elapsed_time = current_time - self.movement_start_time

        if elapsed_time >= self.movement_duration:
            if self.status == "moving_to_pickup":
                self.z = self.target_position[2]
                self._pickup_shuttle(self.current_request, current_time)
            elif self.status == "moving_to_dropoff":
                self.z = self.target_position[2]
                if self.carried_shuttle:
                    self.carried_shuttle.z = self.z
                self._dropoff_shuttle(current_time)

    def get_position(self):
        return (self.x, self.y, self.z)

    def __str__(self):
        return f"lift {self.elevator_id} (x={self.x}): location ({self.x}, {self.y}, {self.z}), status: {self.status}"

    def reset_episode_stats(self):
        """Reset the episode statistics data"""
        self.episode_idle_times.append(self.current_episode_idle_time)
        self.current_episode_idle_time = 0.0


# Equipment Coordinator: Coordinates the operations of transfer vehicles, elevators and shuttle vehicles
class EquipmentCoordinator:

    def __init__(self, transfer_shuttles, elevators):
        self.transfer_shuttles = transfer_shuttles
        self.elevators = elevators

    def request_x_movement(self, shuttle, target_x, current_time):
        """Request for movement of the x-axis"""
        # 根据穿梭车当前z坐标选择对应的转载车
        current_z = shuttle.z
        if current_z in self.transfer_shuttles:
            transfer_shuttle = self.transfer_shuttles[current_z]
            transfer_shuttle.add_transfer_request(shuttle, target_x, current_time)
            return True
        else:
            return False

    def request_z_movement(self, shuttle, target_z, current_time, preferred_elevator_id=None):
        """Request for movement of the z-axis"""
        if preferred_elevator_id and preferred_elevator_id in self.elevators:
            selected_elevator = self.elevators[preferred_elevator_id]
            selected_elevator.add_lift_request(shuttle, target_z, current_time)
            return True
        else:
            shuttle_x = shuttle.x
            min_distance = float('inf')
            selected_elevator = None

            for elevator in self.elevators.values():
                distance = abs(elevator.x - shuttle_x)
                if distance < min_distance:
                    min_distance = distance
                    selected_elevator = elevator

            if selected_elevator:
                selected_elevator.add_lift_request(shuttle, target_z, current_time)
                return True
            else:
                return False

    def update_all_equipment(self, current_time):
        for transfer_shuttle in self.transfer_shuttles.values():
            transfer_shuttle.update(current_time)

        for elevator in self.elevators.values():
            elevator.update(current_time)



class ModifiedEnhancedShuttle:
    """The modified shuttle vehicle type"""

    def __init__(self, shuttle_id, warehouse_shape, zone, motion_calculator, equipment_coordinator,
                 reward_function=None):
        self.shuttle_id = shuttle_id
        self.warehouse_shape = warehouse_shape
        self.zone = zone
        self.motion_calculator = motion_calculator
        self.equipment_coordinator = equipment_coordinator
        self.reward_function = reward_function or WarehouseRewardFunction()


        self.x, self.y, self.z = self._generate_zone_coordinates(zone)
        self.initial_position = (self.x, self.y, self.z)


        self.current_combined_task = None
        self.status = "idle"
        self.current_phase = "idle"
        self.target_position = None
        self.movement_start_time = 0.0
        self.movement_duration = 0.0
        self.total_distance_traveled = 0.0
        self.total_working_time = 0.0
        self.completed_combined_tasks = []


        self.cumulative_execution_time = 0.0


        self.total_reward = 0.0
        self.reward_history = []
        self.deadline_violations = 0
        self.equipment_conflicts = 0


        self.movement_plan = []
        self.current_movement_step = 0
        self.waiting_for_equipment = None
        self.selected_io_point = None
        self.selected_elevator_id = None


        self.task_execution_log = []
        self.current_task_start_time = 0.0


        self.waiting_time_total = 0.0
        self.waiting_start_time = None
        self.current_episode_waiting_time = 0.0


        self.waiting_for_transfer_time = 0.0
        self.waiting_for_elevator_time = 0.0
        self.equipment_waiting_log = []

    def _generate_zone_coordinates(self, zone):
        """Generate random coordinates that conform to the boundaries of the cargo area based on the cargo area itself"""
        max_attempts = 1000

        for _ in range(max_attempts):
            if zone == "A Area":
                x = random.randint(1, 8)
                y = random.randint(1, 28)
                z = random.randint(1, 8)
            elif zone == "B Area":
                sub_areas = [
                    {"x_range": (1, 8), "y_range": (1, 34), "z_range": (9, 11)},
                    {"x_range": (1, 8), "y_range": (29, 34), "z_range": (1, 8)},
                    {"x_range": (9, 12), "y_range": (1, 34), "z_range": (1, 11)}
                ]
                area = random.choice(sub_areas)
                x = random.randint(area["x_range"][0], area["x_range"][1])
                y = random.randint(area["y_range"][0], area["y_range"][1])
                z = random.randint(area["z_range"][0], area["z_range"][1])
            elif zone == "C Area":
                sub_areas = [
                    {"x_range": (1, 12), "y_range": (1, 40), "z_range": (12, 14)},
                    {"x_range": (1, 12), "y_range": (35, 40), "z_range": (1, 11)},
                    {"x_range": (13, 16), "y_range": (1, 40), "z_range": (1, 14)}
                ]
                area = random.choice(sub_areas)
                x = random.randint(area["x_range"][0], area["x_range"][1])
                y = random.randint(area["y_range"][0], area["y_range"][1])
                z = random.randint(area["z_range"][0], area["z_range"][1])
            else:
                x = random.randint(1, self.warehouse_shape[0])
                y = random.randint(1, self.warehouse_shape[1])
                z = random.randint(1, self.warehouse_shape[2])

            if Task._determine_zone(x, y, z) == zone:
                return x, y, z

        raise ValueError(f"Unable to assign to the storage area {zone} Generate valid coordinates")

    def calculate_reward(self, current_time, scheduler=None):
        """Calculate the reward for the current state"""
        if not scheduler:
            return 0.0


        state_extractor = WarehouseStateExtractor()

        dummy_transfer_shuttles = {}
        dummy_elevators = {}

        state_info = state_extractor.extract_state_info(
            [self], dummy_transfer_shuttles, dummy_elevators,
            current_time, scheduler
        )

        reward = self.reward_function.calculate_total_reward(state_info)
        self.reward_history.append({
            'time': current_time,
            'reward': reward,
            'cumulative_reward': self.total_reward + reward
        })

        return reward

    def update_reward(self, reward):
        """Update cumulative rewards"""
        self.total_reward += reward

    def create_movement_plan(self, target_location, phase_type="normal"):
        """Create a complete motion plan, including the required movements along the x, y, and z axes."""
        if not target_location:
            return []

        target_x, target_y, target_z = target_location
        current_x, current_y, current_z = self.x, self.y, self.z


        ELEVATOR_POSITIONS = [1, 8, 16]

        plan = []

        if phase_type == "to_io":
            if current_y != 1:
                plan.append({
                    'type': 'y_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (current_x, 1, current_z),
                    'equipment': 'self'
                })
                current_y = 1


            if current_z != target_z:
                nearest_elevator_x = min(ELEVATOR_POSITIONS, key=lambda x: abs(x - current_x))


                if current_x != nearest_elevator_x:
                    plan.append({
                        'type': 'x_movement',
                        'from': (current_x, current_y, current_z),
                        'to': (nearest_elevator_x, current_y, current_z),
                        'equipment': 'transfer_shuttle'
                    })
                    current_x = nearest_elevator_x


                plan.append({
                    'type': 'z_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (current_x, current_y, target_z),
                    'equipment': 'elevator'
                })
                current_z = target_z


            if current_x != target_x:
                plan.append({
                    'type': 'x_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (target_x, current_y, current_z),
                    'equipment': 'transfer_shuttle'
                })
                current_x = target_x

        elif phase_type == "return_to_io":
            if current_y != 1:
                plan.append({
                    'type': 'y_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (current_x, 1, current_z),
                    'equipment': 'self'
                })
                current_y = 1

            if current_z != target_z:
                nearest_elevator_x = min(ELEVATOR_POSITIONS, key=lambda x: abs(x - current_x))


                if current_x != nearest_elevator_x:
                    plan.append({
                        'type': 'x_movement',
                        'from': (current_x, current_y, current_z),
                        'to': (nearest_elevator_x, current_y, current_z),
                        'equipment': 'transfer_shuttle'
                    })
                    current_x = nearest_elevator_x


                plan.append({
                    'type': 'z_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (current_x, current_y, target_z),
                    'equipment': 'elevator'
                })
                current_z = target_z


            if current_x != target_x:
                plan.append({
                    'type': 'x_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (target_x, current_y, current_z),
                    'equipment': 'transfer_shuttle'
                })

        else:
            if current_z != target_z:
                nearest_elevator_x = min(ELEVATOR_POSITIONS, key=lambda x: abs(x - current_x))


                if current_x != nearest_elevator_x:
                    plan.append({
                        'type': 'x_movement',
                        'from': (current_x, current_y, current_z),
                        'to': (nearest_elevator_x, current_y, current_z),
                        'equipment': 'transfer_shuttle'
                    })
                    current_x = nearest_elevator_x

                plan.append({
                    'type': 'z_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (current_x, current_y, target_z),
                    'equipment': 'elevator'
                })
                current_z = target_z


            if current_x != target_x:
                plan.append({
                    'type': 'x_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (target_x, current_y, current_z),
                    'equipment': 'transfer_shuttle'
                })
                current_x = target_x

            if current_y != target_y:
                plan.append({
                    'type': 'y_movement',
                    'from': (current_x, current_y, current_z),
                    'to': (target_x, target_y, target_z),
                    'equipment': 'self'
                })

        return plan

    def start_combined_task(self, combined_task, current_time):
        """Start to carry out the combined task"""
        if self.status != "idle" or not combined_task:
            return False

        self.current_combined_task = combined_task
        self.current_phase = "to_io_for_inbound"
        self.current_task_start_time = current_time

        # Select the I/O ports and elevator based on the location of the incoming task.
        inbound_x = combined_task.inbound_task.selected_location[0]
        io_point_id, elevator_id = select_io_point_and_elevator(inbound_x)
        self.selected_io_point = io_point_id
        self.selected_elevator_id = elevator_id
        io_location = IO_POINTS[io_point_id]

        # Create a movement plan for the I/O ports
        self.movement_plan = self.create_movement_plan(io_location, "to_io")
        self.current_movement_step = 0

        if self.movement_plan:
            self._start_next_movement_step(current_time)
            return True
        else:
            # The inventory picking operation has already begun at the I/O port.
            self._start_inbound_pickup_operation(current_time)
            return True

    def _start_next_movement_step(self, current_time):
        """Start the next movement step"""
        if self.current_movement_step < len(self.movement_plan):
            step = self.movement_plan[self.current_movement_step]
            equipment = step['equipment']

            if equipment == 'elevator':
                target_z = step['to'][2]
                success = self.equipment_coordinator.request_z_movement(self, target_z, current_time,
                                                                        self.selected_elevator_id)
                if success:
                    self.status = "waiting_equipment"
                    self.waiting_for_equipment = "elevator"
                    self.waiting_start_time = current_time
                else:
                    self.equipment_conflicts += 1

            elif equipment == 'transfer_shuttle':
                target_x = step['to'][0]
                success = self.equipment_coordinator.request_x_movement(self, target_x, current_time)
                if success:
                    self.status = "waiting_equipment"
                    self.waiting_for_equipment = "transfer_shuttle"
                    self.waiting_start_time = current_time
                else:
                    self.equipment_conflicts += 1

            elif equipment == 'self':
                self._start_y_movement(step['to'], current_time)
        else:
            self._start_current_phase_operation(current_time)

    def _start_y_movement(self, target_position, current_time):
        target_x, target_y, target_z = target_position
        current_pos = (self.x, self.y, self.z)

        self.target_position = target_position
        coordinate_distance = abs(target_y - self.y)  # y轴坐标差值
        self.movement_duration = self.motion_calculator.calculate_shuttle_travel_time(
            coordinate_distance, "y_axis")
        actual_distance = coordinate_distance * self.motion_calculator.aisle_width
        self.total_distance_traveled += actual_distance
        self.movement_start_time = current_time
        self.status = "moving_y"

    def on_transfer_completed(self, current_time):
        """Callback for the completion of the transfer vehicle transfer operation"""
        if self.waiting_for_equipment == "transfer_shuttle":

            if self.waiting_start_time is not None:
                waiting_duration = current_time - self.waiting_start_time
                self.waiting_for_transfer_time += waiting_duration
                self.current_episode_waiting_time += waiting_duration
                self.waiting_time_total += waiting_duration


                self.equipment_waiting_log.append({
                    'equipment_type': 'transfer_shuttle',
                    'start_time': self.waiting_start_time,
                    'end_time': current_time,
                    'duration': waiting_duration,
                    'task_id': getattr(self.current_combined_task, 'task_id', 'unknown')
                })

                self.waiting_start_time = None

            self.waiting_for_equipment = None
            self.status = "idle"
            self.current_movement_step += 1
            self._start_next_movement_step(current_time)

    def on_lift_completed(self, current_time):

        if self.waiting_for_equipment == "elevator":

            if self.waiting_start_time is not None:
                waiting_duration = current_time - self.waiting_start_time
                self.waiting_for_elevator_time += waiting_duration
                self.current_episode_waiting_time += waiting_duration
                self.waiting_time_total += waiting_duration


                self.equipment_waiting_log.append({
                    'equipment_type': 'elevator',
                    'start_time': self.waiting_start_time,
                    'end_time': current_time,
                    'duration': waiting_duration,
                    'task_id': getattr(self.current_combined_task, 'task_id', 'unknown')
                })

                self.waiting_start_time = None

            self.waiting_for_equipment = None
            self.status = "idle"
            self.current_movement_step += 1
            self._start_next_movement_step(current_time)

    def _start_current_phase_operation(self, current_time):
        if self.current_phase == "to_io_for_inbound":
            self._start_inbound_pickup_operation(current_time)
        elif self.current_phase == "inbound_phase":
            self._start_inbound_storage_operation(current_time)
        elif self.current_phase == "to_io_for_outbound":
            self._start_outbound_delivery_operation(current_time)
        elif self.current_phase == "outbound_phase":
            self._start_outbound_pickup_operation(current_time)

    def _start_inbound_pickup_operation(self, current_time):
        """Start conducting inventory pickup operations at the I/O ports."""
        self.status = "working"
        self.movement_start_time = current_time
        self.movement_duration = 2.0

    def _start_inbound_storage_operation(self, current_time):
        """Start the inventory storage operation"""
        self.status = "working"
        self.movement_start_time = current_time
        self.movement_duration = 2.0

    def _start_outbound_pickup_operation(self, current_time):
        """Start the outbound delivery and pickup operation"""
        self.status = "working"
        self.movement_start_time = current_time
        self.movement_duration = 2.0

    def _start_outbound_delivery_operation(self, current_time):
        """Start the outbound unloading operation at the I/O port"""
        self.status = "working"
        self.movement_start_time = current_time
        self.movement_duration = 2.0

    def update(self, current_time):
        """Update the status of the shuttle vehicle"""
        if self.status in ["idle", "waiting_equipment", "on_transfer_shuttle", "on_elevator"]:
            return

        elapsed_time = current_time - self.movement_start_time

        if elapsed_time >= self.movement_duration:
            if self.status == "moving_y":
                self.x, self.y, self.z = self.target_position
                self.target_position = None
                self.status = "idle"
                self.current_movement_step += 1
                self._start_next_movement_step(current_time)

            elif self.status == "working":
                self._complete_current_phase(current_time)

    def _complete_current_phase(self, current_time):
        if self.current_phase == "to_io_for_inbound":
            self.current_phase = "inbound_phase"
            self.total_working_time += 2.0

            self.movement_plan = self.create_movement_plan(self.current_combined_task.inbound_task.selected_location)
            self.current_movement_step = 0

            if self.movement_plan:
                self._start_next_movement_step(current_time)
            else:
                self._start_inbound_storage_operation(current_time)

        elif self.current_phase == "inbound_phase":
            self.current_phase = "outbound_phase"
            self.total_working_time += 2.0

            self.movement_plan = self.create_movement_plan(self.current_combined_task.outbound_task.source_location)
            self.current_movement_step = 0

            if self.movement_plan:
                self._start_next_movement_step(current_time)
            else:
                self._start_outbound_pickup_operation(current_time)

        elif self.current_phase == "outbound_phase":
            self.current_phase = "to_io_for_outbound"
            self.total_working_time += 2.0

            io_point_id, elevator_id = select_io_point_and_elevator(self.x)
            self.selected_io_point = io_point_id
            self.selected_elevator_id = elevator_id

            io_location = IO_POINTS[self.selected_io_point]
            self.movement_plan = self.create_movement_plan(io_location, "return_to_io")
            self.current_movement_step = 0

            if self.movement_plan:
                self._start_next_movement_step(current_time)
            else:
                self._start_outbound_delivery_operation(current_time)

        elif self.current_phase == "to_io_for_outbound":
            self.total_working_time += 2.0
            self.complete_current_combined_task(current_time)

    def complete_current_combined_task(self, current_time):
        """Complete the current task set"""
        if self.current_combined_task:
            self.completed_combined_tasks.append(self.current_combined_task)

            task_duration = current_time - self.current_task_start_time
            self.cumulative_execution_time += task_duration

            remaining_time = getattr(self.current_combined_task.inbound_task, 'dynamic_remaining_time',
                                     getattr(self.current_combined_task.inbound_task, 'remaining_time', None))

            # Calculate reward for task completion
            task_reward = self.reward_function.calculate_task_completion_reward(task_duration, remaining_time)
            self.update_reward(task_reward)

            # Check for deadline violations
            if remaining_time is not None and task_duration > remaining_time:
                self.deadline_violations += 1

            task_info = {
                'task_id': self.current_combined_task.task_id,
                'start_time': self.current_task_start_time,
                'end_time': current_time,
                'duration': task_duration,
                'inbound_location': self.current_combined_task.inbound_task.selected_location,
                'outbound_location': self.current_combined_task.outbound_task.source_location,
                'io_point': self.selected_io_point,
                'remaining_time': remaining_time,
                'task_type': 'combined',
                'storage_strategy': getattr(self.current_combined_task.inbound_task, 'storage_strategy_result', {}).get(
                    'strategy', 'unknown'),
                'outbound_strategy': getattr(self.current_combined_task, 'outbound_strategy', 'unknown'),
                'task_reward': task_reward,  # 新增奖励记录
                'deadline_violated': remaining_time is not None and task_duration > remaining_time
            }
            self.task_execution_log.append(task_info)

            self.current_combined_task = None

        self.status = "idle"
        self.current_phase = "idle"
        self.target_position = None
        self.movement_plan = []
        self.current_movement_step = 0
        self.selected_io_point = None
        self.selected_elevator_id = None

    def get_position(self):
        return (self.x, self.y, self.z)

    def __str__(self):
        return f"Shuttle {self.shuttle_id} (Zone:{self.zone}): Position ({self.x}, {self.y}, {self.z}), Status: {self.status}, Total Reward: {self.total_reward:.2f}"

    def reset_episode_stats(self):
        self.waiting_episodes.append(self.current_episode_waiting_time)
        self.current_episode_waiting_time = 0.0


# Create the function for the copy vehicle
def create_transfer_shuttles(motion_calculator):
    """Create 14 shuttle vehicles, each responsible for the 1st to 14th floors."""
    transfer_shuttles = {}

    for level in range(1, 15):  # 1到14层
        transfer_shuttle = TransferShuttle(
            transfer_id=level,
            assigned_level=level,
            motion_calculator=motion_calculator
        )
        transfer_shuttles[level] = transfer_shuttle

    return transfer_shuttles


# Create the function for the elevator
def create_elevators(motion_calculator):
    elevators = {}

    elevator_positions = [1, 8, 16]
    for i, x_pos in enumerate(elevator_positions, 1):
        elevator = Elevator(
            elevator_id=i,
            initial_x=x_pos,
            motion_calculator=motion_calculator
        )
        elevators[i] = elevator

    return elevators


# Modified task scheduler strategy: Supports collaboration between transfer vehicles and elevators, and integrates reward function
class ModifiedEnhancedTaskScheduler:
    """Modified Enhanced Task Scheduler - Supports collaboration between transfer vehicles and elevators, I/O port processes, and integrates reward function"""

    def __init__(self, time_manager, equipment_coordinator, task_selection_strategy="strategy_1", reward_function=None):
        self.time_manager = time_manager
        self.equipment_coordinator = equipment_coordinator
        self.task_selection_strategy = task_selection_strategy
        self.zone_combined_tasks = {}
        self.zone_shuttles = {}
        self.assigned_tasks = set()
        self.completed_tasks = set()


        self.reward_function = reward_function or WarehouseRewardFunction()
        self.state_extractor = WarehouseStateExtractor()
        self.reward_history = []
        self.total_system_reward = 0.0

    def _get_strategy_description(self):
        """Get strategy description"""
        descriptions = {
            "strategy_1": "Strategy 1: Priority based on remaining time (tasks with shorter remaining_time are processed first)",
            "strategy_2": "Strategy 2: Short distance priority (tasks with smaller z-coordinate are prioritized)",
            "strategy_3": "Strategy 3: Random selection",
            "strategy_4": "Strategy 4: Remaining time + short distance priority (select smaller z-coordinate when times are equal)"
        }
        return descriptions.get(self.task_selection_strategy, "Unknown strategy")

    def add_combined_tasks_for_zone(self, zone, combined_tasks):
        """Add combined tasks for storage zone"""
        if zone not in self.zone_combined_tasks:
            self.zone_combined_tasks[zone] = []
        self.zone_combined_tasks[zone].extend(combined_tasks)

    def add_shuttles_for_zone(self, zone, shuttles):
        """Add shuttle vehicles for storage zone"""
        if zone not in self.zone_shuttles:
            self.zone_shuttles[zone] = []
        self.zone_shuttles[zone].extend(shuttles)

    def get_available_tasks_for_zone(self, zone):
        """Get available combined tasks in storage zone"""
        if zone not in self.zone_combined_tasks:
            return []

        available_tasks = []
        for task in self.zone_combined_tasks[zone]:
            if (task.task_id not in self.assigned_tasks and
                    task.task_id not in self.completed_tasks):
                available_tasks.append(task)
        return available_tasks

    def _select_task_by_strategy(self, available_tasks):
        if not available_tasks:
            return None

        if self.task_selection_strategy == "strategy_1":
            return self._select_task_by_remaining_time(available_tasks)
        elif self.task_selection_strategy == "strategy_2":
            return self._select_task_by_distance_priority(available_tasks)
        elif self.task_selection_strategy == "strategy_3":
            return self._select_task_randomly(available_tasks)
        elif self.task_selection_strategy == "strategy_4":
            return self._select_task_by_time_and_distance(available_tasks)
        else:
            return self._select_task_by_remaining_time(available_tasks)

    def _select_task_by_remaining_time(self, available_tasks):
        """Strategy 1"""
        tasks_with_time = [task for task in available_tasks
                           if hasattr(task.inbound_task, 'remaining_time') and
                           task.inbound_task.remaining_time is not None]

        if tasks_with_time:
            selected_task = min(tasks_with_time, key=lambda t: t.inbound_task.remaining_time)
            return selected_task
        elif available_tasks:
            selected_task = random.choice(available_tasks)
            return selected_task
        return None

    def _select_task_by_distance_priority(self, available_tasks):
        """Strategy 2"""
        tasks_with_location = [task for task in available_tasks
                               if task.inbound_task.selected_location is not None]

        if tasks_with_location:
            selected_task = min(tasks_with_location, key=lambda t: t.inbound_task.selected_location[2])
            return selected_task
        return None

    def _select_task_randomly(self, available_tasks):
        """Strategy 3"""
        if available_tasks:
            selected_task = random.choice(available_tasks)
            return selected_task
        return None

    def _select_task_by_time_and_distance(self, available_tasks):
        """Strategy 4"""
        tasks_with_time = [task for task in available_tasks
                           if hasattr(task.inbound_task, 'remaining_time') and
                           task.inbound_task.remaining_time is not None and
                           task.inbound_task.selected_location is not None]

        if tasks_with_time:
            selected_task = min(tasks_with_time,
                                key=lambda t: (t.inbound_task.remaining_time,
                                               t.inbound_task.selected_location[2]))
            return selected_task
        elif available_tasks:
            return self._select_task_by_distance_priority(available_tasks)
        return None

    def assign_combined_task_to_shuttle(self, shuttle, combined_task):
        """Assign combined tasks to shuttle vehicles"""
        if combined_task.task_id not in self.assigned_tasks:
            # Update the task's remaining time based on the shuttle's cumulative execution time
            original_remaining_time = getattr(combined_task.inbound_task, 'remaining_time', None)
            if original_remaining_time is not None:
                # Calculate dynamic remaining time: original remaining time - shuttle's cumulative execution time
                dynamic_remaining_time = max(0, original_remaining_time - shuttle.cumulative_execution_time)
                combined_task.inbound_task.dynamic_remaining_time = dynamic_remaining_time
            else:
                combined_task.inbound_task.dynamic_remaining_time = None

            self.assigned_tasks.add(combined_task.task_id)
            if shuttle.start_combined_task(combined_task, self.time_manager.get_current_time()):
                return True
        return False

    def assign_initial_tasks(self):
        for zone in self.zone_combined_tasks:
            if zone in self.zone_shuttles:
                available_tasks = self.get_available_tasks_for_zone(zone)
                shuttles = self.zone_shuttles[zone]

                for shuttle in shuttles:
                    if shuttle.status == "idle" and available_tasks:
                        selected_task = self._select_task_by_strategy(available_tasks)
                        if selected_task and self.assign_combined_task_to_shuttle(shuttle, selected_task):
                            available_tasks.remove(selected_task)

    def assign_next_task(self, shuttle):
        """Assign the next task to the shuttle vehicle for completing the mission"""
        zone = shuttle.zone
        available_tasks = self.get_available_tasks_for_zone(zone)

        if available_tasks:
            selected_task = self._select_task_by_strategy(available_tasks)
            if selected_task and self.assign_combined_task_to_shuttle(shuttle, selected_task):
                return True
        return False

    def mark_task_completed(self, task_id):
        """Mark task as completed"""
        if task_id in self.assigned_tasks:
            self.assigned_tasks.remove(task_id)
        self.completed_tasks.add(task_id)

    def calculate_system_reward(self, current_time):
        """Calculate total system reward"""
        all_shuttles = []
        for zone_shuttles in self.zone_shuttles.values():
            all_shuttles.extend(zone_shuttles)

        # Extract system state information
        state_info = self.state_extractor.extract_state_info(
            all_shuttles,
            self.equipment_coordinator.transfer_shuttles,
            self.equipment_coordinator.elevators,
            current_time,
            self
        )

        # Calculate system reward
        system_reward = self.reward_function.calculate_total_reward(state_info)

        # Record reward history
        self.reward_history.append({
            'time': current_time,
            'reward': system_reward,
            'cumulative_reward': self.total_system_reward + system_reward
        })

        self.total_system_reward += system_reward
        return system_reward

    def update(self):
        """Update status of all equipment and assign new tasks"""
        current_time = self.time_manager.get_current_time()

        # Update all equipment (transfer vehicles, elevators)
        self.equipment_coordinator.update_all_equipment(current_time)

        # Update shuttle vehicles
        for zone in self.zone_shuttles:
            for shuttle in self.zone_shuttles[zone]:
                previous_completed_count = len(shuttle.completed_combined_tasks)
                shuttle.update(current_time)

                # Mark task as completed if there are newly finished tasks
                if len(shuttle.completed_combined_tasks) > previous_completed_count:
                    newly_completed_task = shuttle.completed_combined_tasks[-1]
                    self.mark_task_completed(newly_completed_task.task_id)

                # Assign next task if shuttle is idle after completing tasks and has no current task
                if shuttle.status == "idle" and shuttle.current_combined_task is None:
                    self.assign_next_task(shuttle)

    def is_all_tasks_completed(self):
        total_tasks = 0
        for zone in self.zone_combined_tasks:
            total_tasks += len(self.zone_combined_tasks[zone])
        return len(self.completed_tasks) >= total_tasks

    def get_progress_summary(self):
        progress = {}
        for zone in self.zone_combined_tasks:
            zone_tasks = self.zone_combined_tasks[zone]
            zone_completed = len([task for task in zone_tasks if task.task_id in self.completed_tasks])
            progress[zone] = {
                'total': len(zone_tasks),
                'completed': zone_completed,
                'assigned': len([task for task in zone_tasks if task.task_id in self.assigned_tasks]),
                'available': len([task for task in zone_tasks
                                  if task.task_id not in self.assigned_tasks and
                                  task.task_id not in self.completed_tasks])
            }
        return progress

    def get_reward_summary(self):
        all_shuttles = []
        for zone_shuttles in self.zone_shuttles.values():
            all_shuttles.extend(zone_shuttles)

        shuttle_rewards = {shuttle.shuttle_id: shuttle.total_reward for shuttle in all_shuttles}

        return {
            'system_total_reward': self.total_system_reward,
            'shuttle_rewards': shuttle_rewards,
            'reward_history_length': len(self.reward_history)
        }


# ============================================================================
#           Reinforcement learning trainer and main program
# ============================================================================

class WarehouseRLEnvironment:
    """Warehouse system reinforcement learning environment - Adapted for DQN"""

    def __init__(self, task_data_path="storage_task_100.xlsx"):
        self.task_data_path = task_data_path
        self.warehouse_shape = warehouse_shape
        self.warehouse = warehouse
        self.mass_limits = mass_limits
        self.volume_limits = volume_limits
        self.occupied_items = occupied_items

        # Reward function
        self.reward_function = WarehouseRewardFunction()
        self.state_extractor = WarehouseStateExtractor()

        # State dimension - Unified state representation designed for DQN
        self.state_dim = 20  # Global state dimension

        # Current strategy configuration
        self.current_storage_strategy = "strategy_3"
        self.current_outbound_strategy = "strategy_1"
        self.current_task_selection_strategy = "strategy_1"

        # Environment state
        self.current_episode_reward = 0.0
        self.episode_count = 0

        # ===== Task cache-related attributes (retain original logic) =====
        self.cached_tasks = None  # Cached task data
        self.cached_combined_tasks = None  # Cached combined tasks
        self.tasks_initialized = False  # Flag indicating whether tasks are initialized

        # Initialize fixed tasks (execute only on first creation)
        self._initialize_fixed_tasks()

    def _initialize_fixed_tasks(self):
        """Initialize fixed task configuration (execute only once)"""
        if self.tasks_initialized:
            return

        print(f"\n=== Initializing fixed task configuration ===")

        # Load task data
        task_data = load_tasks_from_excel(self.task_data_path)

        if task_data is None:
            print("Using simulated data")
            task_data = pd.DataFrame({
                'frequency': [random.randint(1, 30) for _ in range(30)],
                'volume': [round(random.uniform(1, 30), 2) for _ in range(30)],
                'weight': [round(random.uniform(1, 25), 2) for _ in range(30)],
                'remaining_time': [round(random.uniform(100, 200), 1) for _ in range(30)]
            })

        # Create task objects
        self.cached_tasks = []
        for i, row in task_data.iterrows():
            task_id = f"in_{i + 1}"
            task = Task(
                task_id=task_id,
                task_type="inbound",
                warehouse_shape=self.warehouse_shape,
                mass=row['weight'],
                volume=row['volume'],
                frequency=int(row['frequency']),
                remaining_time=row.get('remaining_time', None)
            )
            self.cached_tasks.append(task)

        print(f"Successfully cached {len(self.cached_tasks)} fixed tasks")

        # Perform clustering analysis once and cache results
        self._perform_clustering_once()

        # Generate fixed combined task configuration
        self._generate_fixed_combined_tasks()

        self.tasks_initialized = True
        print(f"Task configuration fixed completed, all subsequent episodes will use the same task configuration")

    def _perform_clustering_once(self):
        """Perform clustering analysis once and save results"""
        print("Performing fixed clustering analysis...")

        # Conduct Gaussian Mixture Model clustering
        features = []
        for task in self.cached_tasks:
            features.append([task.mass, task.volume, task.frequency])

        features = np.array(features)
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features)

        n_clusters = 3
        # Set fixed random seed to ensure consistent clustering results
        gmm = GaussianMixture(n_components=n_clusters, random_state=42, covariance_type='full')
        cluster_labels = gmm.fit_predict(features_scaled)

        for i, task in enumerate(self.cached_tasks):
            task.cluster = cluster_labels[i]

        # Assign storage zones (using fixed assignment logic)
        cluster_stats = {}
        for cluster_id in range(n_clusters):
            cluster_tasks = [task for task in self.cached_tasks if task.cluster == cluster_id]
            if cluster_tasks:
                avg_frequency = np.mean([task.frequency for task in cluster_tasks])
                avg_mass = np.mean([task.mass for task in cluster_tasks])
                avg_volume = np.mean([task.volume for task in cluster_tasks])
                cluster_stats[cluster_id] = {
                    'avg_frequency': avg_frequency,
                    'avg_mass': avg_mass,
                    'avg_volume': avg_volume,
                    'task_count': len(cluster_tasks)
                }

        cluster_scores = []
        for cluster_id, stats in cluster_stats.items():
            max_freq = max([s['avg_frequency'] for s in cluster_stats.values()])
            min_freq = min([s['avg_frequency'] for s in cluster_stats.values()])
            max_mass = max([s['avg_mass'] for s in cluster_stats.values()])
            min_mass = min([s['avg_mass'] for s in cluster_stats.values()])

            norm_freq = (stats['avg_frequency'] - min_freq) / (max_freq - min_freq) if max_freq > min_freq else 0.5
            norm_mass = (stats['avg_mass'] - min_mass) / (max_mass - min_mass) if max_mass > min_mass else 0.5

            composite_score = 0.6 * norm_freq + 0.4 * norm_mass
            cluster_scores.append((cluster_id, composite_score, stats))

        cluster_scores.sort(key=lambda x: x[1], reverse=True)

        zone_names = ["A Area", "B Area", "C Area"]
        cluster_to_zone = {}

        for i, (cluster_id, score, stats) in enumerate(cluster_scores):
            zone = zone_names[i] if i < len(zone_names) else "C Area"
            cluster_to_zone[cluster_id] = zone

        for task in self.cached_tasks:
            task.zone = cluster_to_zone[task.cluster]

        print("Clustering analysis completed, storage zone assignment results:")
        zone_counts = {}
        for task in self.cached_tasks:
            zone_counts[task.zone] = zone_counts.get(task.zone, 0) + 1
        for zone, count in zone_counts.items():
            print(f"  {zone}: {count} tasks")

    def _generate_fixed_combined_tasks(self):
        """Generate fixed combined task configuration"""
        print("Generating fixed combined task configuration...")

        # Use fixed random seed to ensure the same combined tasks are generated each time
        original_random_state = random.getstate()
        random.seed(42)  # Fixed seed

        try:
            self.cached_combined_tasks = {}

            # Pre-generate combined tasks for each strategy combination
            storage_strategies = ["strategy_1", "strategy_2", "strategy_3"]
            outbound_strategies = ["strategy_1", "strategy_2", "strategy_3", "strategy_4", "strategy_5"]

            for storage_strategy in storage_strategies:
                for outbound_strategy in outbound_strategies:
                    strategy_key = f"{storage_strategy}_{outbound_strategy}"
                    combined_tasks = self._generate_combined_tasks_for_strategy(storage_strategy, outbound_strategy)
                    self.cached_combined_tasks[strategy_key] = combined_tasks
                    print(f"  Strategy combination {strategy_key}: {len(combined_tasks)} combined tasks")

        finally:
            # Restore random state
            random.setstate(original_random_state)


    def _generate_combined_tasks_for_strategy(self, storage_strategy, outbound_strategy):
        """Generate combination tasks for specific strategy combinations"""
        import copy
        tasks_copy = copy.deepcopy(self.cached_tasks)

        used_locations = set()
        combined_tasks = []

        for task in tasks_copy:
            zone = task.zone
            task_allocated = False

            if storage_strategy == "strategy_1":
                strategy_result = StorageStrategy.strategy_1_random_storage(
                    task, self.warehouse, self.mass_limits, self.volume_limits, zone, used_locations)
                task.selected_location = strategy_result['selected_location']
                task.storage_strategy_result = strategy_result
                if task.selected_location:
                    task_allocated = True
                    used_locations.add(task.selected_location)

                if not task_allocated:
                    warehouse_wide_result = StorageStrategy.strategy_warehouse_wide_random(
                        task, self.warehouse, self.mass_limits, self.volume_limits, used_locations)
                    task.selected_location = warehouse_wide_result['selected_location']
                    task.storage_strategy_result = warehouse_wide_result
                    task.storage_strategy_result['original_strategy'] = 'strategy_1'
                    task.storage_strategy_result['warehouse_wide_fallback'] = True

                    if task.selected_location:
                        task_allocated = True
                        used_locations.add(task.selected_location)
                        original_zone = task.zone
                        actual_zone = warehouse_wide_result.get('assigned_zone', task.zone)
                        task.zone = actual_zone

            elif storage_strategy == "strategy_2":
                success = task.find_candidate_locations_in_zone(
                    self.warehouse, self.mass_limits, self.volume_limits, zone, used_locations)
                if success:
                    strategy_result = StorageStrategy.strategy_2_highest_lmd(task)
                    task.selected_location = strategy_result['selected_location']
                    task.storage_strategy_result = strategy_result
                    if task.selected_location:
                        task_allocated = True
                        used_locations.add(task.selected_location)

                if not task_allocated:
                    fallback_result = StorageStrategy.strategy_1_random_storage(
                        task, self.warehouse, self.mass_limits, self.volume_limits, zone, used_locations)
                    task.selected_location = fallback_result['selected_location']
                    task.storage_strategy_result = fallback_result
                    if task.selected_location:
                        task_allocated = True
                        used_locations.add(task.selected_location)

                if not task_allocated:
                    warehouse_wide_result = StorageStrategy.strategy_warehouse_wide_random(
                        task, self.warehouse, self.mass_limits, self.volume_limits, used_locations)
                    task.selected_location = warehouse_wide_result['selected_location']
                    task.storage_strategy_result = warehouse_wide_result
                    task.storage_strategy_result['original_strategy'] = 'strategy_2'
                    task.storage_strategy_result['warehouse_wide_fallback'] = True

                    if task.selected_location:
                        task_allocated = True
                        used_locations.add(task.selected_location)
                        original_zone = task.zone
                        actual_zone = warehouse_wide_result.get('assigned_zone', task.zone)
                        task.zone = actual_zone

            elif storage_strategy == "strategy_3":
                success = task.find_candidate_locations_in_zone(
                    self.warehouse, self.mass_limits, self.volume_limits, zone, used_locations)
                if success:
                    strategy_result = StorageStrategy.strategy_3_lmd_with_z_priority(task)
                    task.selected_location = strategy_result['selected_location']
                    task.storage_strategy_result = strategy_result
                    if task.selected_location:
                        task_allocated = True
                        used_locations.add(task.selected_location)

                if not task_allocated:
                    backup_strategies = ["strategy_1", "strategy_2"]
                    random.shuffle(backup_strategies)

                    for backup_strategy in backup_strategies:
                        if backup_strategy == "strategy_1":
                            fallback_result = StorageStrategy.strategy_1_random_storage(
                                task, self.warehouse, self.mass_limits, self.volume_limits, zone, used_locations)
                            task.selected_location = fallback_result['selected_location']
                            task.storage_strategy_result = fallback_result
                            task.storage_strategy_result['original_strategy'] = 'strategy_3'
                            task.storage_strategy_result['fallback_strategy'] = 'strategy_1'

                            if task.selected_location:
                                task_allocated = True
                                used_locations.add(task.selected_location)
                                break

                        elif backup_strategy == "strategy_2":
                            success = task.find_candidate_locations_in_zone(
                                self.warehouse, self.mass_limits, self.volume_limits, zone, used_locations)
                            if success:
                                fallback_result = StorageStrategy.strategy_2_highest_lmd(task)
                                task.selected_location = fallback_result['selected_location']
                                task.storage_strategy_result = fallback_result
                                task.storage_strategy_result['original_strategy'] = 'strategy_3'
                                task.storage_strategy_result['fallback_strategy'] = 'strategy_2'

                                if task.selected_location:
                                    task_allocated = True
                                    used_locations.add(task.selected_location)
                                    break

                    if not task_allocated:
                        warehouse_wide_result = StorageStrategy.strategy_warehouse_wide_random(
                            task, self.warehouse, self.mass_limits, self.volume_limits, used_locations)
                        task.selected_location = warehouse_wide_result['selected_location']
                        task.storage_strategy_result = warehouse_wide_result
                        task.storage_strategy_result['original_strategy'] = 'strategy_3'
                        task.storage_strategy_result['final_warehouse_wide'] = True

                        if task.selected_location:
                            task_allocated = True
                            used_locations.add(task.selected_location)
                            original_zone = task.zone
                            actual_zone = warehouse_wide_result.get('assigned_zone', task.zone)
                            task.zone = actual_zone

        # Generate outbound delivery tasks
        for task in tasks_copy:
            if task.selected_location:
                outbound_task = OutboundStrategy.select_outbound_location(
                    task, self.warehouse, self.mass_limits, self.volume_limits,
                    self.warehouse_shape, self.occupied_items, outbound_strategy)

                if outbound_task:
                    combined_task = CombinedTask(
                        f"combined_{task.task_id.split('_')[1]}",
                        task, outbound_task, outbound_strategy)
                    combined_tasks.append(combined_task)

        return combined_tasks

    def reset(self):
        """Reset the environment - Use the cached fixed tasks and return the state required by DQN"""
        self.episode_count += 1
        self.current_episode_reward = 0.0

        print(f"\n=== Episode {self.episode_count}: Using fixed task configuration ===")

        # Use cached tasks and get corresponding combined tasks based on current strategy
        strategy_key = f"{self.current_storage_strategy}_{self.current_outbound_strategy}"

        if strategy_key in self.cached_combined_tasks:
            # Deep copy to avoid modifying cache
            import copy
            self.combined_tasks = copy.deepcopy(self.cached_combined_tasks[strategy_key])
        else:
            # Use default combination if no pre-generated combined tasks exist
            default_key = "strategy_3_strategy_1"
            if default_key in self.cached_combined_tasks:
                import copy
                self.combined_tasks = copy.deepcopy(self.cached_combined_tasks[default_key])
            else:
                # Final fallback measure
                self.combined_tasks = []

        print(f"Using strategy combination {strategy_key}, loaded {len(self.combined_tasks)} combined tasks")

        # Create warehouse system equipment (this part remains dynamically created)
        self.create_equipment()

        # Reset episode statistics for all equipment
        for shuttle in self.shuttles:
            shuttle.reset_episode_stats()

        for transfer_shuttle in self.transfer_shuttles.values():
            transfer_shuttle.reset_episode_stats()

        for elevator in self.elevators.values():
            elevator.reset_episode_stats()

        # Return initial state
        state = self.get_state()
        return state

    def get_state(self):
        """Get current environment state - Unified state representation designed for DQN"""
        if not hasattr(self, 'scheduler'):
            # Return zero state if scheduler has not been created yet
            return np.zeros(self.state_dim)

        # Extract state information
        current_time = self.time_manager.get_current_time()
        state_info = self.state_extractor.extract_state_info(
            self.shuttles, self.transfer_shuttles, self.elevators, current_time, self.scheduler)

        # Construct unified state vector (20 dimensions)
        state_vector = [
            # Time and progress-related features (4 dimensions)
            current_time / 1000.0,  # Normalized current time
            state_info.get('completed_task_count', 0) / max(state_info.get('total_tasks', 1), 1),
            # Task completion rate
            (state_info.get('total_tasks', 1) - state_info.get('completed_task_count', 0)) / max(
                state_info.get('total_tasks', 1), 1),  # Remaining task rate
            len(self.scheduler.assigned_tasks) / max(state_info.get('total_tasks', 1), 1),  # Assigned task rate

            # Equipment load features (6 dimensions)
            np.mean(state_info.get('equipment_loads', {}).get('shuttles', [0])),
            np.mean(state_info.get('equipment_loads', {}).get('transfer_shuttles', [0])),
            np.mean(state_info.get('equipment_loads', {}).get('elevators', [0])),
            np.var(state_info.get('equipment_loads', {}).get('shuttles', [0])),
            np.var(state_info.get('equipment_loads', {}).get('transfer_shuttles', [0])),
            np.var(state_info.get('equipment_loads', {}).get('elevators', [0])),

            # Efficiency and distance features (3 dimensions)
            state_info.get('total_distance', 0) / 10000.0,  # Normalized total distance
            state_info.get('total_working_time', 0) / 1000.0,  # Normalized total working time
            state_info.get('idle_time', 0) / 100.0,  # Normalized idle time

            # Storage zone completion status (3 dimensions)
            self._get_zone_completion_rate("Zone A"),
            self._get_zone_completion_rate("Zone B"),
            self._get_zone_completion_rate("Zone C"),

            # Shuttle status statistics (2 dimensions)
            len([s for s in self.shuttles if s.status == "idle"]) / max(len(self.shuttles), 1),  # Idle shuttle ratio
            sum(shuttle.total_reward for shuttle in self.shuttles) / (len(self.shuttles) * 1000),  # Average reward

            # Conflict and violation statistics (2 dimensions)
            state_info.get('deadline_violations', 0) / 10.0,  # Normalized deadline violation count
            state_info.get('equipment_conflicts', 0) / 10.0  # Normalized equipment conflict count
        ]

        # Ensure state vector has the correct length
        state_vector = state_vector[:self.state_dim]
        while len(state_vector) < self.state_dim:
            state_vector.append(0.0)

        return np.array(state_vector, dtype=np.float32)

    def step(self, action):
        """Environment step - DQN version, input action index"""
        # Convert action index to strategy combination (this conversion should be done in the agent)
        # Assume the strategy combination is provided externally here
        if isinstance(action, tuple) and len(action) == 3:
            storage_strategy, outbound_strategy, task_selection_strategy = action
        else:
            # If action index is passed in, a conversion mechanism is required
            print(f"Warning: step() received non-strategy-combination action: {action}")
            # Use current strategy as default
            storage_strategy = self.current_storage_strategy
            outbound_strategy = self.current_outbound_strategy
            task_selection_strategy = self.current_task_selection_strategy

        # Update current strategy configuration
        self.current_storage_strategy = storage_strategy
        self.current_outbound_strategy = outbound_strategy
        self.current_task_selection_strategy = task_selection_strategy

        # Reprocess tasks if strategy changes
        if hasattr(self, 'scheduler'):
            self.scheduler.task_selection_strategy = task_selection_strategy

        # Record current state for comparison
        prev_completed = len(self.scheduler.completed_tasks) if hasattr(self, 'scheduler') else 0
        prev_time = self.time_manager.get_current_time()

        # Run simulation steps
        simulation_steps = 50
        for _ in range(simulation_steps):
            if hasattr(self, 'scheduler'):
                self.scheduler.update()
                self.time_manager.advance_time(0.1)

            if hasattr(self, 'scheduler') and self.scheduler.is_all_tasks_completed():
                break

        # Calculate reward
        current_time = self.time_manager.get_current_time()
        state_info = self.state_extractor.extract_state_info(
            self.shuttles, self.transfer_shuttles, self.elevators, current_time, self.scheduler)

        reward = self.reward_function.calculate_total_reward(state_info)

        # Enhance immediate time-based reward
        current_completed = len(self.scheduler.completed_tasks) if hasattr(self, 'scheduler') else 0
        time_elapsed = current_time - prev_time

        # Give time efficiency reward if new tasks are completed
        if current_completed > prev_completed:
            new_tasks_completed = current_completed - prev_completed
            if time_elapsed > 0:
                # Time efficiency: faster completion leads to higher reward
                time_per_task = time_elapsed / new_tasks_completed
                if time_per_task < 80:  # Fast completion
                    speed_bonus = (80 - time_per_task) / 80 * 100 * new_tasks_completed
                    reward += speed_bonus
                else:  # Penalty for slow completion
                    speed_penalty = -(time_per_task - 80) / 80 * 50 * new_tasks_completed
                    reward += speed_penalty

        # Add progress incentive: higher time reward per step as completion approaches
        if hasattr(self, 'scheduler'):
            total_tasks = sum(len(tasks) for tasks in self.scheduler.zone_combined_tasks.values())
            progress_ratio = current_completed / max(total_tasks, 1)

            # Time pressure: penalty for slow progress with long elapsed time
            expected_time = progress_ratio * 2000  # Expected timeline
            if expected_time > 0 and current_time > expected_time * 1.2:  # 20% overtime
                time_pressure_penalty = -10 * (current_time - expected_time) / expected_time
                reward += time_pressure_penalty

        self.current_episode_reward += reward

        # Check if episode is done
        done = (hasattr(self, 'scheduler') and self.scheduler.is_all_tasks_completed()) or \
               current_time > 5000.0  # Maximum simulation time

        # Give substantial completion time reward if all tasks are finished
        if done and hasattr(self, 'scheduler') and self.scheduler.is_all_tasks_completed():
            completion_time_bonus = max(0, (3000.0 - current_time) / 3000.0) * 2000  # Max 2000 points
            reward += completion_time_bonus
            print(f"All tasks completed! Total time: {current_time:.1f}s, Time bonus: {completion_time_bonus:.1f}")

        # Get next state
        next_state = self.get_state()

        return next_state, reward, done

    def _get_zone_completion_rate(self, zone):
        """Get completion rate of specific storage zone"""
        zone_tasks = [task for task in self.combined_tasks if task.zone == zone]
        zone_completed = len([task for task in zone_tasks if task.task_id in self.scheduler.completed_tasks])
        return zone_completed / max(len(zone_tasks), 1)

    # Retain original methods for equipment creation, etc.
    def create_equipment(self):
        """Create warehouse equipment"""
        # Create time manager and motion calculator
        self.time_manager = TimeManager()
        self.motion_calculator = MotionCalculator(
            shuttle_velocity=3.0,
            transfer_velocity=3.0,
            elevator_velocity=4.0,
            shuttle_acceleration=2.0,
            transfer_acceleration=2.0,
            elevator_acceleration=3.0,
            # Physical dimension parameters
            aisle_width=0.6,
            shelf_spacing=0.8,
            floor_height=1.2,
            shuttle_depth=0.6
        )

        # Create transfer vehicles and elevators
        self.transfer_shuttles = create_transfer_shuttles(self.motion_calculator)
        self.elevators = create_elevators(self.motion_calculator)
        self.equipment_coordinator = EquipmentCoordinator(self.transfer_shuttles, self.elevators)

        # Create shuttle vehicles
        self.shuttles = []
        shuttle_id = 0

        # Group tasks by storage zone
        zone_combined_tasks = {}
        for combined_task in self.combined_tasks:
            zone = combined_task.zone
            if zone not in zone_combined_tasks:
                zone_combined_tasks[zone] = []
            zone_combined_tasks[zone].append(combined_task)

        # Count tasks in each zone and allocate shuttle vehicles
        zone_task_counts = {}
        for zone, tasks in zone_combined_tasks.items():
            zone_task_counts[zone] = len(tasks)

        total_shuttles = 10
        total_valid_tasks = sum(zone_task_counts.values())

        if total_valid_tasks > 0:
            zone_task_proportions = {
                zone: count / total_valid_tasks
                for zone, count in zone_task_counts.items()
            }
            zone_shuttle_counts = {
                zone: max(1, int(round(proportion * total_shuttles)))
                for zone, proportion in zone_task_proportions.items()
            }

            # Adjust allocation to ensure total count matches
            current_total = sum(zone_shuttle_counts.values())
            if current_total != total_shuttles:
                adjustment = total_shuttles - current_total
                sorted_zones = sorted(zone_shuttle_counts.items(), key=lambda x: zone_task_counts[x[0]], reverse=True)
                for zone, count in sorted_zones:
                    if adjustment == 0:
                        break
                    if adjustment > 0:
                        zone_shuttle_counts[zone] += 1
                        adjustment -= 1
                    elif count > 1:
                        zone_shuttle_counts[zone] -= 1
                        adjustment += 1

        # Create shuttle vehicles
        for zone in ["Zone A", "Zone B", "Zone C"]:
            count = zone_shuttle_counts.get(zone, 0)
            for i in range(count):
                try:
                    shuttle = ModifiedEnhancedShuttle(
                        shuttle_id, self.warehouse_shape, zone,
                        self.motion_calculator, self.equipment_coordinator, self.reward_function)
                    self.shuttles.append(shuttle)
                    shuttle_id += 1
                except ValueError as e:
                    print(f"Failed to create shuttle vehicle: {e}")

        # Create task scheduler
        self.scheduler = ModifiedEnhancedTaskScheduler(
            self.time_manager, self.equipment_coordinator,
            self.current_task_selection_strategy, self.reward_function)

        # Add combined tasks and shuttle vehicles to scheduler
        zone_shuttles = {}
        for shuttle in self.shuttles:
            if shuttle.zone not in zone_shuttles:
                zone_shuttles[shuttle.zone] = []
            zone_shuttles[shuttle.zone].append(shuttle)
            self.scheduler.add_shuttles_for_zone(shuttle.zone, [shuttle])

        for zone, tasks in zone_combined_tasks.items():
            self.scheduler.add_combined_tasks_for_zone(zone, tasks)

        # Assign initial tasks
        self.scheduler.assign_initial_tasks()


class WarehouseDQNTrainer:
    """Warehouse system DQN reinforcement learning trainer"""

    def __init__(self, task_data_path="storage_task_100.xlsx", lr=0.001, output_dir="output"):
        self.env = WarehouseRLEnvironment(task_data_path)
        self.agent = WarehouseDQNAgent(
            state_dim=self.env.state_dim,
            lr=lr
        )
        # New: Track the best episode
        self.best_episode_idx = -1
        self.best_completion_time = float('inf')
        self.best_episode_data = None

        self.output_dir = output_dir
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
            print(f"Created output directory: {self.output_dir}")

        # Training records
        self.episode_rewards = []
        self.episode_completion_rates = []
        self.strategy_usage = {
            'storage': {'strategy_1': 0, 'strategy_2': 0, 'strategy_3': 0},
            'outbound': {'strategy_1': 0, 'strategy_2': 0, 'strategy_3': 0, 'strategy_4': 0, 'strategy_5': 0},
            'task_selection': {'strategy_1': 0, 'strategy_2': 0, 'strategy_3': 0, 'strategy_4': 0}
        }


        self.episode_task_data = []
        self.episode_completion_times = []
        self.episode_task_counts = []
        self.episode_efficiency_metrics = []

    def train(self, episodes=200, save_every=50):
        """DQN training"""
        print(f"\n=== Starting DQN reinforcement learning training for warehouse system ===")
        print(f"State dimension: {self.env.state_dim}")
        print(f"Action dimension: {self.agent.action_dim}")
        print(f"Number of strategy combinations: {self.agent.action_dim}")

        # Initialize variables needed during training
        best_completion_time = float('inf')
        no_improvement_count = 0
        early_stop_patience = 200  # Early stopping patience

        for episode in range(episodes):
            print(f"\n--- Episode {episode + 1}/{episodes} ---")

            # Reset environment
            state = self.env.reset()
            episode_reward = 0
            step_count = 0
            done = False
            episode_start_time = time.time()

            while not done and step_count < 200:
                # Select strategy combination and action
                strategies, action = self.agent.select_strategies(state)
                storage_strategy, outbound_strategy, task_selection_strategy = strategies

                # Record strategy usage
                self.strategy_usage['storage'][storage_strategy] += 1
                self.strategy_usage['outbound'][outbound_strategy] += 1
                self.strategy_usage['task_selection'][task_selection_strategy] += 1

                # Execute environment step
                next_state, reward, done = self.env.step(strategies)

                # Agent learning step
                self.agent.step(state, action, reward, next_state, done)

                state = next_state
                episode_reward += reward
                step_count += 1

                if step_count % 50 == 0:
                    print(f"  Step {step_count}: Reward: {reward:.2f}")

            # Update epsilon
            self.agent.update_epsilon()

            # Collect task data
            episode_task_info = self._collect_episode_task_data(episode + 1)
            completion_time = episode_task_info['total_simulation_time']
            completion_rate = episode_task_info['completion_rate']

            # Performance monitoring and adaptive adjustment
            if completion_rate > 0.9:  # Compare time only when completion rate is high
                if completion_time < best_completion_time:
                    best_completion_time = completion_time
                    no_improvement_count = 0
                    print(f"🎉 New best completion time: {completion_time:.1f}s")

                    # New: Update global best episode information
                    if completion_time < self.best_completion_time:
                        self.best_completion_time = completion_time
                        self.best_episode_idx = episode
                        self.best_episode_data = episode_task_info  # Save best episode data

                    # Save best model
                    self.agent.save_model(os.path.join(self.output_dir, "best_dqn_model.pth"))
                else:
                    no_improvement_count += 1

            # Adaptive epsilon adjustment
            self.agent.adaptive_update_epsilon(completion_time)

            # Record data
            self.episode_rewards.append(episode_reward)
            self.episode_completion_times.append(completion_time)
            self.episode_completion_rates.append(completion_rate)
            self.episode_task_data.append(episode_task_info)

            print(f"Episode {episode + 1} completed:")
            print(f"  Total reward: {episode_reward:.2f}")
            print(f"  Completion time: {completion_time:.1f}s (Best: {best_completion_time:.1f})")
            print(f"  Completion rate: {completion_rate:.2%}")
            print(f"  Epsilon: {self.agent.epsilon:.3f}")
            print(f"  No improvement count: {no_improvement_count}")

            # Early stopping check
            if no_improvement_count >= early_stop_patience:
                print(f"\nEarly stopping triggered: No improvement for {early_stop_patience} episodes")
                break

            # Calculate efficiency metrics
            total_completion_time = episode_task_info['total_simulation_time']
            task_count = episode_task_info['total_tasks']

            efficiency_metrics = {
                'avg_task_time': total_completion_time / max(task_count, 1),
                'completion_rate': completion_rate,
                'total_distance': episode_task_info['total_distance'],
                'avg_distance_per_task': episode_task_info['total_distance'] / max(task_count, 1),
                'episode_duration': time.time() - episode_start_time
            }
            self.episode_efficiency_metrics.append(efficiency_metrics)

            print(f"  Total simulation time: {total_completion_time:.1f}s")

            # Get training statistics
            stats = self.agent.get_training_stats()
            print(f"  Memory size: {stats['memory_size']}")
            if stats['recent_loss'] > 0:
                print(f"  Recent loss: {stats['recent_loss']:.4f}")

            # Save model periodically
            if (episode + 1) % save_every == 0:
                self.agent.save_model(os.path.join(self.output_dir, f"dqn_warehouse_episode_{episode + 1}.pth"))

        print(f"\n=== DQN training completed ===")
        print(f"Average total reward: {np.mean(self.episode_rewards):.2f}")
        print(f"Average completion rate: {np.mean(self.episode_completion_rates):.2%}")
        print(f"Average completion time: {np.mean(self.episode_completion_times):.1f}s")

        if self.best_episode_data:
            print(
                f"Best Episode: Episode {self.best_episode_idx + 1}, Completion time: {self.best_completion_time:.1f}s")
            self.save_best_episode_gantt()

        return self.episode_rewards, self.episode_completion_rates

    def _collect_episode_task_data(self, episode_num):
        """Collect detailed task data for current episode - Enhanced version with waiting time statistics"""
        episode_info = {
            'episode': episode_num,
            'tasks': [],
            'total_tasks': 0,
            'completed_tasks': 0,
            'total_simulation_time': 0,
            'total_distance': 0,
            'completion_rate': 0,
            'shuttles_data': [],
            # New: Waiting time statistics
            'waiting_time_stats': {
                'shuttles': {},
                'transfer_shuttles': {},
                'elevators': {}
            }
        }

        if hasattr(self.env, 'scheduler') and hasattr(self.env, 'shuttles'):
            # Get total simulation time
            episode_info['total_simulation_time'] = self.env.time_manager.get_current_time()

            # Collect task execution data for all shuttle vehicles
            all_tasks = []
            total_distance = 0

            for shuttle in self.env.shuttles:
                shuttle_info = {
                    'shuttle_id': shuttle.shuttle_id,
                    'zone': shuttle.zone,
                    'completed_tasks': len(shuttle.completed_combined_tasks),
                    'total_distance': shuttle.total_distance_traveled,
                    'total_working_time': shuttle.total_working_time,
                    'tasks': [],
                    # New waiting time information
                    'current_episode_waiting_time': shuttle.current_episode_waiting_time,
                    'waiting_for_transfer_time': shuttle.waiting_for_transfer_time,
                    'waiting_for_elevator_time': shuttle.waiting_for_elevator_time,
                    'total_waiting_time': shuttle.waiting_time_total,
                    'waiting_episodes_history': shuttle.waiting_episodes.copy()
                }

                total_distance += shuttle.total_distance_traveled

                # Collect all tasks for this shuttle
                for task_log in shuttle.task_execution_log:
                    task_info = {
                        'task_id': task_log['task_id'],
                        'shuttle_id': shuttle.shuttle_id,
                        'zone': shuttle.zone,
                        'start_time': task_log['start_time'],
                        'end_time': task_log['end_time'],
                        'duration': task_log['duration'],
                        'inbound_location': task_log.get('inbound_location'),
                        'outbound_location': task_log.get('outbound_location'),
                        'remaining_time': task_log.get('remaining_time'),
                        'storage_strategy': task_log.get('storage_strategy', 'unknown'),
                        'outbound_strategy': task_log.get('outbound_strategy', 'unknown')
                    }
                    shuttle_info['tasks'].append(task_info)
                    all_tasks.append(task_info)

                episode_info['shuttles_data'].append(shuttle_info)

                # Store shuttle waiting time statistics
                episode_info['waiting_time_stats']['shuttles'][shuttle.shuttle_id] = {
                    'current_episode_waiting': shuttle.current_episode_waiting_time,
                    'total_waiting': shuttle.waiting_time_total,
                    'transfer_waiting': shuttle.waiting_for_transfer_time,
                    'elevator_waiting': shuttle.waiting_for_elevator_time
                }

            # Collect transfer shuttle waiting time data
            if hasattr(self.env, 'transfer_shuttles'):
                for transfer_id, transfer_shuttle in self.env.transfer_shuttles.items():
                    episode_info['waiting_time_stats']['transfer_shuttles'][transfer_id] = {
                        'current_episode_idle': transfer_shuttle.current_episode_idle_time,
                        'total_idle': transfer_shuttle.idle_time_total
                    }

            # Collect elevator waiting time data
            if hasattr(self.env, 'elevators'):
                for elevator_id, elevator in self.env.elevators.items():
                    episode_info['waiting_time_stats']['elevators'][elevator_id] = {
                        'current_episode_idle': elevator.current_episode_idle_time,
                        'total_idle': elevator.idle_time_total
                    }

            # Calculate overall statistics
            episode_info['tasks'] = sorted(all_tasks, key=lambda x: x['start_time'])
            episode_info['total_tasks'] = len(self.env.combined_tasks) if hasattr(self.env, 'combined_tasks') else 0
            episode_info['completed_tasks'] = len(all_tasks)
            episode_info['total_distance'] = total_distance
            episode_info['completion_rate'] = episode_info['completed_tasks'] / max(episode_info['total_tasks'], 1)

        return episode_info

    def plot_gantt_charts(self, episodes_to_plot=None, max_episodes=10):
        """Plot Gantt charts - Show task completion status for specified episodes"""
        if not self.episode_task_data:
            print("No task data available for plotting")
            return

        # Initialize excel_data list
        excel_data = []

        # Select episodes to plot
        if episodes_to_plot is None:
            total_episodes = len(self.episode_task_data)
            if total_episodes <= max_episodes:
                episodes_to_plot = list(range(total_episodes))
            else:
                episodes_to_plot = [0, total_episodes // 4, total_episodes // 2,
                                    3 * total_episodes // 4, total_episodes - 1]
                episodes_to_plot = episodes_to_plot[:max_episodes]

        num_plots = len(episodes_to_plot)
        fig, axes = plt.subplots(num_plots, 1, figsize=(15, 4 * num_plots))
        if num_plots == 1:
            axes = [axes]

        colors = plt.cm.Set3(np.linspace(0, 1, 12))

        for idx, episode_idx in enumerate(episodes_to_plot):
            ax = axes[idx]
            episode_data = self.episode_task_data[episode_idx]

            # Assign color to each shuttle
            shuttle_colors = {}
            color_idx = 0

            # Plot each task
            y_positions = {}
            y_pos = 0

            for shuttle_data in episode_data['shuttles_data']:
                shuttle_id = shuttle_data['shuttle_id']
                if shuttle_id not in y_positions:
                    y_positions[shuttle_id] = y_pos
                    y_pos += 1

                if shuttle_id not in shuttle_colors:
                    shuttle_colors[shuttle_id] = colors[color_idx % len(colors)]
                    color_idx += 1

                # Plot all tasks for this shuttle
                for task in shuttle_data['tasks']:
                    start_time = task['start_time']
                    duration = task['duration']
                    end_time = task['end_time']

                    # Plot task bar
                    ax.barh(y_positions[shuttle_id], duration, left=start_time,
                            height=0.6, color=shuttle_colors[shuttle_id],
                            alpha=0.7, edgecolor='black', linewidth=0.5)

                    # Add task ID label
                    ax.text(start_time + duration / 2, y_positions[shuttle_id],
                            task['task_id'].split('_')[-1],
                            ha='center', va='center', fontsize=8, fontweight='bold')

                    # Collect Excel data
                    excel_row = {
                        'Episode': episode_data['episode'],
                        'Task_ID': task['task_id'],
                        'Shuttle_ID': shuttle_id,
                        'Zone': task['zone'],
                        'Start_Time': round(start_time, 2),
                        'End_Time': round(end_time, 2),
                        'Duration': round(duration, 2),
                        'Inbound_Location': str(task.get('inbound_location', '')),
                        'Outbound_Location': str(task.get('outbound_location', '')),
                        'Storage_Strategy': task.get('storage_strategy', 'unknown'),
                        'Outbound_Strategy': task.get('outbound_strategy', 'unknown'),
                        'Remaining_Time': task.get('remaining_time', 0) if task.get('remaining_time') is not None else 0
                    }
                    excel_data.append(excel_row)

            # Set chart properties
            ax.set_xlabel('Time (seconds)')
            ax.set_ylabel('Shuttle Vehicle')
            ax.set_title(f'Episode {episode_data["episode"]} Task Completion Gantt Chart\n'
                         f'Completion Rate: {episode_data["completion_rate"]:.1%}, '
                         f'Total Time: {episode_data["total_simulation_time"]:.1f}s, '
                         f'Tasks: {episode_data["completed_tasks"]}/{episode_data["total_tasks"]}')

            # Set y-axis labels
            shuttle_labels = [f'Shuttle {sid}' for sid in sorted(y_positions.keys())]
            ax.set_yticks(list(range(len(shuttle_labels))))
            ax.set_yticklabels(shuttle_labels)

            ax.grid(True, alpha=0.3)
            ax.set_xlim(0, episode_data['total_simulation_time'] * 1.05)

        plt.tight_layout()

        # Save chart
        current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(self.output_dir, f"DQN_Gantt_Chart_{current_time}.png")
        plt.savefig(filename, dpi=1200, bbox_inches='tight', format='png')
        plt.close()
        print(f"Gantt chart saved as: {filename}")

        # Save Excel data
        if excel_data:
            try:
                wb = Workbook()
                ws1 = wb.active
                ws1.title = "DQN Gantt Chart Task Detailed Data"

                headers = [
                    'Episode', 'Task_ID', 'Shuttle_ID', 'Zone', 'Start_Time',
                    'End_Time', 'Duration', 'Inbound_Location', 'Outbound_Location',
                    'Storage_Strategy', 'Outbound_Strategy', 'Remaining_Time'
                ]

                for col, header in enumerate(headers, 1):
                    ws1.cell(row=1, column=col, value=header)

                for row_idx, data_row in enumerate(excel_data, 2):
                    for col_idx, header in enumerate(headers, 1):
                        ws1.cell(row=row_idx, column=col_idx, value=data_row[header])

                excel_filename = os.path.join(self.output_dir, f"DQN_Gantt_Chart_{current_time}.xlsx")
                wb.save(excel_filename)
                print(f"Gantt chart data saved to Excel: {excel_filename}")

            except Exception as e:
                print(f"Error saving Gantt chart Excel data: {e}")

    def plot_training_results(self):
        """Plot DQN training results"""
        # Modify subplot layout from 2x2 to 2x3 to accommodate 5 subplots
        fig, ((ax1, ax2, ax3), (ax4, ax5, ax6)) = plt.subplots(2, 3, figsize=(18, 10))

        # Training reward curve (position unchanged)
        episodes = range(1, len(self.episode_rewards) + 1)
        ax1.plot(episodes, self.episode_rewards, alpha=0.6, label='Episode Reward')

        # Smoothed curve
        if len(self.episode_rewards) > 10:
            window_size = min(20, len(self.episode_rewards) // 5)
            smoothed_rewards = []
            for i in range(len(self.episode_rewards)):
                start = max(0, i - window_size + 1)
                smoothed_rewards.append(np.mean(self.episode_rewards[start:i + 1]))
            ax1.plot(episodes, smoothed_rewards, label='Smoothed Reward', linewidth=2)

        ax1.set_xlabel('Episode')
        ax1.set_ylabel('Cumulative Reward')
        ax1.set_title('DQN Training Reward Curve')
        ax1.legend()
        ax1.grid(True)

        # Completion rate curve (position unchanged)
        ax2.plot(episodes, self.episode_completion_rates, alpha=0.6, label='Episode Completion Rate')

        if len(self.episode_completion_rates) > 10:
            window_size = min(20, len(self.episode_completion_rates) // 5)
            smoothed_completion = []
            for i in range(len(self.episode_completion_rates)):
                start = max(0, i - window_size + 1)
                smoothed_completion.append(np.mean(self.episode_completion_rates[start:i + 1]))
            ax2.plot(episodes, smoothed_completion, label='Smoothed Completion Rate', linewidth=2)

        ax2.set_xlabel('Episode')
        ax2.set_ylabel('Task Completion Rate')
        ax2.set_title('Task Completion Rate Curve')
        ax2.legend()
        ax2.grid(True)

        # Strategy usage distribution - Storage strategy (position adjusted to ax3)
        storage_labels = list(self.strategy_usage['storage'].keys())
        storage_values = list(self.strategy_usage['storage'].values())
        ax3.pie(storage_values, labels=storage_labels, autopct='%1.1f%%', startangle=90)
        ax3.set_title('Storage Strategy Usage Distribution')

        # Strategy usage distribution - Outbound strategy (position adjusted to ax4)
        outbound_labels = list(self.strategy_usage['outbound'].keys())
        outbound_values = list(self.strategy_usage['outbound'].values())
        ax4.pie(outbound_values, labels=outbound_labels, autopct='%1.1f%%', startangle=90)
        ax4.set_title('Outbound Strategy Usage Distribution')

        # New: Strategy usage distribution - Task selection strategy (new position ax5)
        task_selection_labels = list(self.strategy_usage['task_selection'].keys())
        task_selection_values = list(self.strategy_usage['task_selection'].values())
        ax5.pie(task_selection_values, labels=task_selection_labels, autopct='%1.1f%%', startangle=90)
        ax5.set_title('Task Selection Strategy Usage Distribution')

        # Hide the 6th subplot (ax6) or use for other information
        ax6.axis('off')
        # Optional: Display training statistics in ax6
        ax6.text(0.1, 0.9, 'Training Statistics:', fontsize=14, fontweight='bold', transform=ax6.transAxes)
        ax6.text(0.1, 0.8, f'Total Training Episodes: {len(episodes)}', fontsize=12, transform=ax6.transAxes)
        ax6.text(0.1, 0.7, f'Final Epsilon: {self.agent.epsilon:.4f}', fontsize=12, transform=ax6.transAxes)
        ax6.text(0.1, 0.6, f'Average Reward: {np.mean(self.episode_rewards):.2f}', fontsize=12, transform=ax6.transAxes)
        ax6.text(0.1, 0.5, f'Average Completion Rate: {np.mean(self.episode_completion_rates):.2%}', fontsize=12,
                 transform=ax6.transAxes)

        plt.tight_layout()

        # Save chart
        current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(self.output_dir, f"DQN_Training_Results_{current_time}.png")
        plt.savefig(filename, dpi=1200, bbox_inches='tight', format='png')
        plt.close()
        print(f"Training results plot saved as: {filename}")

    def plot_completion_time_iteration(self):
        """Plot completion time iteration chart"""
        if not self.episode_completion_times:
            print("No completion time data available for plotting")
            return

        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))

        episodes = range(1, len(self.episode_completion_times) + 1)

        # 1. Total completion time iteration chart
        ax1.plot(episodes, self.episode_completion_times, 'b-', alpha=0.6, label='Total Completion Time')

        # Smoothed curve
        if len(self.episode_completion_times) > 10:
            window_size = min(20, len(self.episode_completion_times) // 5)
            smoothed_times = []
            for i in range(len(self.episode_completion_times)):
                start = max(0, i - window_size + 1)
                smoothed_times.append(np.mean(self.episode_completion_times[start:i + 1]))
            ax1.plot(episodes, smoothed_times, 'r-', linewidth=2, label='Smoothed Curve')

        ax1.set_xlabel('Training Episode')
        ax1.set_ylabel('Total Completion Time (seconds)')
        ax1.set_title('DQN Total Task Completion Time Iteration Chart')
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # 2. Average task time iteration chart
        avg_task_times = [metrics['avg_task_time'] for metrics in self.episode_efficiency_metrics]
        ax2.plot(episodes, avg_task_times, 'g-', alpha=0.6, label='Average Task Time')

        if len(avg_task_times) > 10:
            window_size = min(20, len(avg_task_times) // 5)
            smoothed_avg = []
            for i in range(len(avg_task_times)):
                start = max(0, i - window_size + 1)
                smoothed_avg.append(np.mean(avg_task_times[start:i + 1]))
            ax2.plot(episodes, smoothed_avg, 'orange', linewidth=2, label='Smoothed Curve')

        ax2.set_xlabel('Training Episode')
        ax2.set_ylabel('Average Task Time (seconds)')
        ax2.set_title('DQN Average Single Task Completion Time Iteration Chart')
        ax2.legend()
        ax2.grid(True, alpha=0.3)

        # 3. Combined completion rate and efficiency chart
        completion_rates = [metrics['completion_rate'] for metrics in self.episode_efficiency_metrics]
        ax3.plot(episodes, completion_rates, 'purple', alpha=0.6, label='Task Completion Rate')
        ax3.set_xlabel('Training Episode')
        ax3.set_ylabel('Task Completion Rate')
        ax3.set_title('DQN Task Completion Rate Iteration Chart')
        ax3.legend()
        ax3.grid(True, alpha=0.3)

        # 4. Movement distance efficiency chart
        avg_distances = [metrics['avg_distance_per_task'] for metrics in self.episode_efficiency_metrics]
        ax4.plot(episodes, avg_distances, 'brown', alpha=0.6, label='Average Distance per Task')

        if len(avg_distances) > 10:
            window_size = min(20, len(avg_distances) // 5)
            smoothed_dist = []
            for i in range(len(avg_distances)):
                start = max(0, i - window_size + 1)
                smoothed_dist.append(np.mean(avg_distances[start:i + 1]))
            ax4.plot(episodes, smoothed_dist, 'red', linewidth=2, label='Smoothed Curve')

        ax4.set_xlabel('Training Episode')
        ax4.set_ylabel('Average Movement Distance per Task (m)')
        ax4.set_title('DQN Movement Efficiency Iteration Chart')
        ax4.legend()
        ax4.grid(True, alpha=0.3)

        plt.tight_layout()

        # Save chart
        current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(self.output_dir, f"DQN_Completion_Time_Iteration_{current_time}.png")
        plt.savefig(filename, dpi=1200, bbox_inches='tight', format='png')
        plt.close()
        print(f"Completion time iteration chart saved as: {filename}")

    def print_training_summary(self):
        """Print DQN training summary report"""
        if not self.episode_task_data:
            print("No training data available")
            return

        print("\n" + "=" * 60)
        print("                  DQN Training Summary Report")
        print("=" * 60)

        # Basic statistics
        total_episodes = len(self.episode_task_data)
        avg_completion_time = np.mean(self.episode_completion_times)
        std_completion_time = np.std(self.episode_completion_times)
        avg_reward = np.mean(self.episode_rewards)
        std_reward = np.std(self.episode_rewards)
        avg_completion_rate = np.mean(self.episode_completion_rates)

        print(f"Number of training episodes: {total_episodes}")
        print(f"Average completion time: {avg_completion_time:.2f} ± {std_completion_time:.2f} seconds")
        print(f"Average reward: {avg_reward:.2f} ± {std_reward:.2f}")
        print(f"Average completion rate: {avg_completion_rate:.2%}")
        print(f"Final epsilon: {self.agent.epsilon:.4f}")

        # Learning effect analysis
        if total_episodes >= 20:
            early_episodes = self.episode_completion_times[:total_episodes // 4]
            late_episodes = self.episode_completion_times[-total_episodes // 4:]

            early_avg = np.mean(early_episodes)
            late_avg = np.mean(late_episodes)
            improvement = (early_avg - late_avg) / early_avg * 100

            print(f"\nDQN Learning Effect Analysis:")
            print(f"Early stage average completion time: {early_avg:.2f} seconds")
            print(f"Late stage average completion time: {late_avg:.2f} seconds")
            print(f"Completion time improvement: {improvement:.1f}%")

        # Best performance
        best_episode_idx = np.argmin(self.episode_completion_times)
        best_time = self.episode_completion_times[best_episode_idx]
        best_reward = self.episode_rewards[best_episode_idx]

        print(f"\nBest Performance:")
        print(f"Shortest completion time: {best_time:.2f} seconds (Episode {best_episode_idx + 1})")
        print(f"Corresponding reward: {best_reward:.2f}")

        # Strategy preference analysis
        print(f"\nDQN Strategy Learning Preference:")
        for strategy_type, usage in self.strategy_usage.items():
            total_usage = sum(usage.values())
            if total_usage > 0:
                print(f"  {strategy_type}:")
                for strategy, count in usage.items():
                    percentage = count / total_usage * 100
                    print(f"    {strategy}: {percentage:.1f}% ({count} times)")

        print("=" * 60)

    def evaluate(self, num_episodes=10):
        """Evaluate trained DQN agent"""
        print(f"\n=== Evaluating Trained DQN Agent ===")

        evaluation_rewards = []
        evaluation_completion_rates = []
        evaluation_completion_times = []
        strategy_performance = {}

        for episode in range(num_episodes):
            print(f"\nEvaluation Episode {episode + 1}/{num_episodes}")

            # Reset environment
            state = self.env.reset()
            total_episode_reward = 0
            step_count = 0
            done = False
            episode_strategies = []

            while not done and step_count < 200:
                # Use greedy strategy (epsilon=0)
                strategies, action = self.agent.select_strategies(state)

                # Record strategies for performance analysis
                episode_strategies.append(strategies)

                # Execute environment step
                next_state, reward, done = self.env.step(strategies)

                # Accumulate reward
                total_episode_reward += reward

                state = next_state
                step_count += 1

            evaluation_rewards.append(total_episode_reward)

            # Calculate completion rate and completion time
            if hasattr(self.env, 'scheduler'):
                progress = self.env.scheduler.get_progress_summary()
                total_completed = sum(zone_progress['completed'] for zone_progress in progress.values())
                total_tasks = sum(zone_progress['total'] for zone_progress in progress.values())
                completion_rate = total_completed / max(total_tasks, 1)
                completion_time = self.env.time_manager.get_current_time()

                evaluation_completion_rates.append(completion_rate)
                evaluation_completion_times.append(completion_time)
            else:
                completion_rate = 0.0
                completion_time = 0.0
                evaluation_completion_rates.append(completion_rate)
                evaluation_completion_times.append(completion_time)

            # Record strategy combination performance
            strategy_combo = tuple(episode_strategies[0]) if episode_strategies else ("unknown", "unknown", "unknown")
            if strategy_combo not in strategy_performance:
                strategy_performance[strategy_combo] = {'rewards': [], 'times': []}
            strategy_performance[strategy_combo]['rewards'].append(total_episode_reward)
            strategy_performance[strategy_combo]['times'].append(completion_time)

            print(f"Evaluation Result: Total Reward={total_episode_reward:.2f}")
            print(f"Completion Rate={completion_rate:.2%}, Completion Time={completion_time:.1f}s")

        print(f"\n=== DQN Evaluation Results Summary ===")
        print(f"Average Total Reward: {np.mean(evaluation_rewards):.2f} ± {np.std(evaluation_rewards):.2f}")
        print(
            f"Average Completion Rate: {np.mean(evaluation_completion_rates):.2%} ± {np.std(evaluation_completion_rates):.2%}")
        print(
            f"Average Completion Time: {np.mean(evaluation_completion_times):.1f} ± {np.std(evaluation_completion_times):.1f} seconds")

        # Display best strategy combination
        if strategy_performance:
            best_strategy = max(strategy_performance.keys(),
                                key=lambda k: np.mean(strategy_performance[k]['rewards']))
            best_performance = np.mean(strategy_performance[best_strategy]['rewards'])
            best_time = np.mean(strategy_performance[best_strategy]['times'])
            print(f"DQN Best Strategy Combination: {best_strategy}")
            print(f"Best Strategy Average Reward: {best_performance:.2f}")
            print(f"Best Strategy Average Completion Time: {best_time:.1f}s")

        return evaluation_rewards, evaluation_completion_rates, strategy_performance

    # Add new method to WarehouseDQNAgent class
    def export_training_data(self, filename="dqn_training_data.xlsx"):
        """Export DQN training data to Excel file - Enhanced version with waiting time statistics"""
        if not self.episode_completion_times:
            print("No training data available for export")
            return

        try:
            wb = Workbook()

            # Worksheet 1: Basic training data (keep original logic unchanged)
            ws1 = wb.active
            ws1.title = "DQN Training Data"

            headers = ["Training Episode", "Task Completion Time (s)", "Smoothed Time", "Episode Reward",
                       "Smoothed Reward",
                       "Completed Tasks", "Total Tasks", "Completion Rate (%)", "Average Task Time (s)",
                       "Epsilon Value"]
            for col, header in enumerate(headers, 1):
                ws1.cell(row=1, column=col, value=header)

            window_size = min(20, max(5, len(self.episode_completion_times) // 5))  # Dynamic window size

            # Calculate smoothed time values
            smoothed_times = []
            for i in range(len(self.episode_completion_times)):
                start = max(0, i - window_size + 1)
                smoothed_times.append(np.mean(self.episode_completion_times[start:i + 1]))

            # Calculate smoothed reward values
            smoothed_rewards = []
            for i in range(len(self.episode_rewards)):
                start = max(0, i - window_size + 1)
                smoothed_rewards.append(np.mean(self.episode_rewards[start:i + 1]))

            # Write data
            for i in range(len(self.episode_completion_times)):
                ws1.cell(row=i + 2, column=1, value=i + 1)  # Training episode
                ws1.cell(row=i + 2, column=2, value=round(self.episode_completion_times[i], 2))  # Task completion time
                ws1.cell(row=i + 2, column=3, value=round(smoothed_times[i], 2))  # Smoothed time

                if i < len(self.episode_rewards):
                    ws1.cell(row=i + 2, column=4, value=round(self.episode_rewards[i], 2))  # Episode reward
                    ws1.cell(row=i + 2, column=5, value=round(smoothed_rewards[i], 2))  # Smoothed reward

                if i < len(self.episode_task_data):
                    task_data = self.episode_task_data[i]
                    ws1.cell(row=i + 2, column=6, value=task_data['completed_tasks'])  # Completed tasks
                    ws1.cell(row=i + 2, column=7, value=task_data['total_tasks'])  # Total tasks
                    ws1.cell(row=i + 2, column=8, value=round(task_data['completion_rate'] * 100, 2))  # Completion rate

                if i < len(self.episode_efficiency_metrics):
                    avg_time = self.episode_efficiency_metrics[i]['avg_task_time']
                    ws1.cell(row=i + 2, column=9, value=round(avg_time, 2))  # Average task time

                # Epsilon value (simplified calculation)
                epsilon_value = max(0.01, 0.995 ** i)  # Estimated epsilon value
                ws1.cell(row=i + 2, column=10, value=round(epsilon_value, 4))  # Epsilon value

            # New Worksheet 2: Waiting time statistics
            ws2 = wb.create_sheet(title="Waiting Time Statistics")

            # Waiting time headers
            waiting_headers = ["Episode", "Equipment Type", "Equipment ID", "Current Episode Waiting Time (s)",
                               "Total Waiting Time (s)", "Transfer Waiting Time (s)", "Elevator Waiting Time (s)"]
            for col, header in enumerate(waiting_headers, 1):
                ws2.cell(row=1, column=col, value=header)

            row_idx = 2

            # Iterate through each episode's data
            for i, episode_data in enumerate(self.episode_task_data):
                if 'waiting_time_stats' in episode_data:
                    waiting_stats = episode_data['waiting_time_stats']

                    # Shuttle waiting time data
                    for shuttle_id, stats in waiting_stats['shuttles'].items():
                        ws2.cell(row=row_idx, column=1, value=i + 1)  # Episode number
                        ws2.cell(row=row_idx, column=2, value="Shuttle")
                        ws2.cell(row=row_idx, column=3, value=shuttle_id)
                        ws2.cell(row=row_idx, column=4, value=round(stats.get('current_episode_waiting', 0), 2))
                        ws2.cell(row=row_idx, column=5, value=round(stats.get('total_waiting', 0), 2))
                        ws2.cell(row=row_idx, column=6, value=round(stats.get('transfer_waiting', 0), 2))
                        ws2.cell(row=row_idx, column=7, value=round(stats.get('elevator_waiting', 0), 2))
                        row_idx += 1

                    # Transfer shuttle idle time data
                    for transfer_id, stats in waiting_stats['transfer_shuttles'].items():
                        ws2.cell(row=row_idx, column=1, value=i + 1)  # Episode number
                        ws2.cell(row=row_idx, column=2, value="Transfer Shuttle")
                        ws2.cell(row=row_idx, column=3, value=transfer_id)
                        ws2.cell(row=row_idx, column=4, value=round(stats.get('current_episode_idle', 0), 2))
                        ws2.cell(row=row_idx, column=5, value=round(stats.get('total_idle', 0), 2))
                        ws2.cell(row=row_idx, column=6, value=0)  # No transfer waiting time for transfer shuttles
                        ws2.cell(row=row_idx, column=7, value=0)  # No elevator waiting time for transfer shuttles
                        row_idx += 1

                    # Elevator idle time data
                    for elevator_id, stats in waiting_stats['elevators'].items():
                        ws2.cell(row=row_idx, column=1, value=i + 1)  # Episode number
                        ws2.cell(row=row_idx, column=2, value="Elevator")
                        ws2.cell(row=row_idx, column=3, value=elevator_id)
                        ws2.cell(row=row_idx, column=4, value=round(stats.get('current_episode_idle', 0), 2))
                        ws2.cell(row=row_idx, column=5, value=round(stats.get('total_idle', 0), 2))
                        ws2.cell(row=row_idx, column=6, value=0)  # No transfer waiting time for elevators
                        ws2.cell(row=row_idx, column=7, value=0)  # No elevator waiting time for elevators
                        row_idx += 1

            # Save file
            current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
            full_filename = os.path.join(self.output_dir,
                                         f"DQN_with_waiting_{filename.replace('.xlsx', '')}_{current_time}.xlsx")
            wb.save(full_filename)

            print(f"DQN training data with waiting time statistics exported to: {full_filename}")

        except Exception as e:
            print(f"Error exporting waiting time data: {e}")

    def save_best_episode_gantt(self):
        """Save Gantt chart for episode with shortest completion time"""
        if self.best_episode_data is None:
            print("No best episode data found")
            return

        print(f"\nSaving Gantt chart for Best Episode {self.best_episode_idx + 1}...")

        fig, ax = plt.subplots(1, 1, figsize=(15, 8))
        episode_data = self.best_episode_data

        # Assign color to each shuttle
        colors = plt.cm.Set3(np.linspace(0, 1, 12))
        shuttle_colors = {}
        color_idx = 0

        # Plot Gantt chart
        y_positions = {}
        y_pos = 0
        excel_data = []  # Collect Excel data

        for shuttle_data in episode_data['shuttles_data']:
            shuttle_id = shuttle_data['shuttle_id']
            if shuttle_id not in y_positions:
                y_positions[shuttle_id] = y_pos
                y_pos += 1

            if shuttle_id not in shuttle_colors:
                shuttle_colors[shuttle_id] = colors[color_idx % len(colors)]
                color_idx += 1

            # Plot all tasks for this shuttle
            for task in shuttle_data['tasks']:
                start_time = task['start_time']
                duration = task['duration']
                end_time = task['end_time']

                # Plot task bar
                ax.barh(y_positions[shuttle_id], duration, left=start_time,
                        height=0.6, color=shuttle_colors[shuttle_id],
                        alpha=0.7, edgecolor='black', linewidth=0.5)

                # Add task ID label
                ax.text(start_time + duration / 2, y_positions[shuttle_id],
                        task['task_id'].split('_')[-1],
                        ha='center', va='center', fontsize=8, fontweight='bold')

                # Collect Excel data
                excel_row = {
                    'Episode': episode_data['episode'],
                    'Task_ID': task['task_id'],
                    'Shuttle_ID': shuttle_id,
                    'Zone': task['zone'],
                    'Start_Time': round(start_time, 2),
                    'End_Time': round(end_time, 2),
                    'Duration': round(duration, 2),
                    'Inbound_Location': str(task.get('inbound_location', '')),
                    'Outbound_Location': str(task.get('outbound_location', '')),
                    'Storage_Strategy': task.get('storage_strategy', 'unknown'),
                    'Outbound_Strategy': task.get('outbound_strategy', 'unknown'),
                    'Remaining_Time': task.get('remaining_time', 0) if task.get('remaining_time') is not None else 0
                }
                excel_data.append(excel_row)

        # Set chart properties
        ax.set_xlabel('Time (seconds)', fontsize=12)
        ax.set_ylabel('Shuttle Vehicle', fontsize=12)
        ax.set_title(f'Best Episode {episode_data["episode"]} Task Completion Gantt Chart\n'
                     f'Completion Time: {episode_data["total_simulation_time"]:.1f}s (Shortest), '
                     f'Completion Rate: {episode_data["completion_rate"]:.1%}, '
                     f'Tasks: {episode_data["completed_tasks"]}/{episode_data["total_tasks"]}',
                     fontsize=14, fontweight='bold')

        # Set y-axis labels
        shuttle_labels = [f'Shuttle {sid}' for sid in sorted(y_positions.keys())]
        ax.set_yticks(list(range(len(shuttle_labels))))
        ax.set_yticklabels(shuttle_labels)

        ax.grid(True, alpha=0.3)
        ax.set_xlim(0, episode_data['total_simulation_time'] * 1.05)

        plt.tight_layout()

        # Save best Gantt chart
        current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        gantt_filename = os.path.join(self.output_dir, f"best_gantt_{current_time}.png")
        plt.savefig(gantt_filename, dpi=1200, bbox_inches='tight', format='png')
        plt.close()
        print(f"Best episode Gantt chart saved as: {gantt_filename}")

        # Save Excel data for best episode
        if excel_data:
            try:
                wb = Workbook()
                ws1 = wb.active
                ws1.title = f"Best Episode {episode_data['episode']} Task Data"

                headers = [
                    'Episode', 'Task_ID', 'Shuttle_ID', 'Zone', 'Start_Time',
                    'End_Time', 'Duration', 'Inbound_Location', 'Outbound_Location',
                    'Storage_Strategy', 'Outbound_Strategy', 'Remaining_Time'
                ]

                for col, header in enumerate(headers, 1):
                    ws1.cell(row=1, column=col, value=header)

                for row_idx, data_row in enumerate(excel_data, 2):
                    for col_idx, header in enumerate(headers, 1):
                        ws1.cell(row=row_idx, column=col_idx, value=data_row[header])

                excel_filename = os.path.join(self.output_dir, f"best_gantt_data_{current_time}.xlsx")
                wb.save(excel_filename)
                print(f"Best episode task data saved to Excel: {excel_filename}")

            except Exception as e:
                print(f"Error saving best episode Excel data: {e}")

def main_dqn_training():
    """Main function for DQN reinforcement learning training"""
    print("=== Starting DQN Reinforcement Learning Training for Intelligent Warehouse System ===")
    print("System Features:")
    print("- Uses Deep Q-Network (DQN) algorithm")
    print("- Unified state representation adapted for warehouse systems")
    print("- Combined action space: Storage × Outbound × Task Selection strategies")
    print("- Experience replay and target network mechanisms")
    print("- Adaptive epsilon-greedy exploration")

    # Create DQN trainer
    trainer = WarehouseDQNTrainer(
        task_data_path=r"C:\Users\hp\Desktop\DEC-MAPPO\MARL-code-pytorch-main\6.保存文件\2-python文件版本-以这份为主\storage_task_100.xlsx",
        lr=0.001,
        output_dir = r"C:\Users\hp\Desktop\DEC-MAPPO\MARL-code-pytorch-main\6.保存文件\2-python文件版本-以这份为主\1-DQN\100-10\29"  # Can be changed to any folder name you want
    )

    try:
        print("\nStarting DQN training...")
        episode_rewards, completion_rates = trainer.train(episodes=200, save_every=50)

        print("\nGenerating analysis report...")
        trainer.print_training_summary()
        trainer.plot_completion_time_iteration()
        trainer.plot_gantt_charts(episodes_to_plot=None, max_episodes=8)
        trainer.plot_training_results()

        print("\nStarting evaluation...")
        eval_rewards, eval_completion_rates, strategy_performance = trainer.evaluate(num_episodes=10)

        print("\n=== DQN Training and Evaluation Completed ===")
        print("DQN System Features:")
        print("1. End-to-end deep reinforcement learning approach")
        print("2. Automatically learns optimal strategy combinations")
        print("3. Improves sample efficiency through experience replay")
        print("4. Target network stabilizes training process")
        print("5. Adaptive exploration strategy")

        # Export training data
        print("\nExporting DQN training data...")
        trainer.export_training_data("dqn_training_data.xlsx")

        return trainer, strategy_performance

    except Exception as e:
        print(f"Error occurred during DQN training: {e}")
        import traceback
        traceback.print_exc()
        return None, None


def main_traditional_comparison():
    """Traditional method comparison test"""
    print("\n=== Traditional Fixed Strategy Comparison Test ===")

    # Test different fixed strategy combinations
    strategy_combinations = [
        ("strategy_1", "strategy_1", "strategy_1"),  # All random
        ("strategy_2", "strategy_2", "strategy_2"),  # All optimal matching
        ("strategy_3", "strategy_3", "strategy_3"),  # All hybrid strategy
        ("strategy_3", "strategy_1", "strategy_1"),  # Hybrid combination 1
        ("strategy_2", "strategy_4", "strategy_2"),  # Hybrid combination 2
    ]

    comparison_results = {}

    for storage_strategy, outbound_strategy, task_strategy in strategy_combinations:
        print(f"\nTesting strategy combination: ({storage_strategy}, {outbound_strategy}, {task_strategy})")

        # Create environment and run test
        env = WarehouseRLEnvironment()
        total_reward = 0

        for episode in range(5):  # Test each combination for 5 episodes
            state = env.reset()
            episode_reward = 0
            step_count = 0
            done = False

            while not done and step_count < 200:
                next_state, reward, done = env.step((storage_strategy, outbound_strategy, task_strategy))
                state = next_state
                episode_reward += reward
                step_count += 1

            total_reward += episode_reward

        avg_reward = total_reward / 5
        comparison_results[(storage_strategy, outbound_strategy, task_strategy)] = avg_reward
        print(f"Average reward: {avg_reward:.2f}")

    # Display comparison results
    print(f"\n=== Strategy Combination Performance Ranking ===")
    sorted_results = sorted(comparison_results.items(), key=lambda x: x[1], reverse=True)
    for i, (strategy_combo, avg_reward) in enumerate(sorted_results, 1):
        print(f"{i}. Strategy combination {strategy_combo}: {avg_reward:.2f}")

    return comparison_results


import numpy as np
import os
import datetime
import traceback
import matplotlib.pyplot as plt
from openpyxl import Workbook
import time

# 假设相关类已提前定义（WarehouseDQNTrainer/WarehouseRLEnvironment等）

def main_dqn_vs_traditional_comparison():
    """Compare DQN vs traditional methods test"""
    print("\n=== DQN vs Traditional Methods Comparison Test ===")

    print("\n1. Running traditional fixed strategies...")
    traditional_results = main_traditional_comparison()

    print("\n2. Running DQN training...")
    dqn_trainer, dqn_strategy_performance = main_dqn_training()

    if dqn_trainer and traditional_results:
        print("\n=== Performance Comparison Analysis ===")

        # Best results of traditional methods
        best_traditional = max(traditional_results.values())
        best_traditional_strategy = max(traditional_results.keys(), key=lambda k: traditional_results[k])

        # Best results of DQN
        if dqn_trainer.episode_rewards:
            best_dqn_reward = max(dqn_trainer.episode_rewards)
            avg_dqn_reward = np.mean(dqn_trainer.episode_rewards[-10:])  # Average of last 10 episodes

            print(f"Traditional Methods Best Performance:")
            print(f"  Best Strategy Combination: {best_traditional_strategy}")
            print(f"  Best Average Reward: {best_traditional:.2f}")

            print(f"\nDQN Learning Results:")
            print(f"  Best Single Episode Reward: {best_dqn_reward:.2f}")
            print(f"  Late-stage Average Reward: {avg_dqn_reward:.2f}")

            # Calculate improvement percentage
            if best_traditional > 0:
                improvement_best = (best_dqn_reward - best_traditional) / best_traditional * 100
                improvement_avg = (avg_dqn_reward - best_traditional) / best_traditional * 100

                print(f"\nDQN Improvement over Traditional Methods:")
                print(f"  Best Performance Improvement: {improvement_best:.1f}%")
                print(f"  Average Performance Improvement: {improvement_avg:.1f}%")

            # Learning curve analysis
            if len(dqn_trainer.episode_rewards) >= 20:
                early_performance = np.mean(dqn_trainer.episode_rewards[:10])
                late_performance = np.mean(dqn_trainer.episode_rewards[-10:])
                learning_improvement = (late_performance - early_performance) / abs(early_performance) * 100

                print(f"\nDQN Learning Effect:")
                print(f"  Early-stage Performance: {early_performance:.2f}")
                print(f"  Late-stage Performance: {late_performance:.2f}")
                print(f"  Learning Improvement: {learning_improvement:.1f}%")

        print(f"\n=== Method Comparison Summary ===")
        print("Advantages of Traditional Fixed Strategies:")
        print("- Deterministic and easy to interpret")
        print("- No training time required")
        print("- Good stability")

        print("\nAdvantages of DQN Reinforcement Learning:")
        print("- Adaptive learning capability")
        print("- Can discover complex strategy combinations")
        print("- Continuous performance improvement")
        print("- Adaptable to environmental changes")


def show_system_info():
    """Display system information"""
    print("=== Intelligent Warehouse System - DQN Version ===")
    print("Feature Highlights:")
    print("1. DQN Deep Reinforcement Learning Algorithm")
    print("2. Multi-strategy combination optimization")
    print("3. Experience replay and target network")
    print("4. Real-time performance monitoring")
    print("5. Comprehensive visualization analysis")
    print("6. Excel data export")
    print("\nSystem Components:")
    print("- Collaborative operation of shuttles, transfer shuttles, and elevators")
    print("- Intelligent task scheduler")
    print("- Multi-dimensional reward function")
    print("- State feature extractor")
    print("- Gantt chart and performance analysis")


def run_demo_mode():
    """Run demo mode"""
    print("\n=== DQN Warehouse System Demo Mode ===")

    # Create a small-scale training demo
    trainer = WarehouseDQNTrainer(
        task_data_path="storage_task_100.xlsx",
        lr=0.001
    )

    print("Starting small-scale demo training (10 episodes)...")
    episode_rewards, completion_rates = trainer.train(episodes=10, save_every=5)

    print("\nGenerating demo report...")
    trainer.print_training_summary()
    trainer.plot_training_results()

    print("\nDemo completed!")
    return trainer


if __name__ == "__main__":
    print("=== Intelligent Warehouse System + DQN Reinforcement Learning ===")
    print("=== Intelligent Warehouse System - DQN Version ===")
    print("Feature Highlights:")
    print("1. DQN Deep Reinforcement Learning Algorithm")
    print("2. Multi-strategy combination optimization")
    print("3. Experience replay and target network")
    print("4. Real-time performance monitoring")
    print("5. Comprehensive visualization analysis")
    print("6. Excel data export")

    print("\nSelect running mode:")
    print("1. DQN Reinforcement Learning Training Mode")
    print("2. Traditional Strategy Comparison Mode")
    print("3. DQN vs Traditional Methods Comparison Mode")
    print("4. Quick Demo Mode")

    try:
        choice = input("\nPlease enter your choice (1-4): ").strip()

        if choice == "1":
            print("\nStarting DQN training mode...")
            trainer, strategy_performance = main_dqn_training()

            if trainer:
                print(f"\n=== Training Completed! ===")
                print(f"Number of training episodes: {len(trainer.episode_rewards)}")
                print(f"Average reward: {np.mean(trainer.episode_rewards[-10:]):.2f}")
                print(f"Average completion time: {np.mean(trainer.episode_completion_times[-10:]):.1f}s")

                # Show best performance
                best_time_idx = np.argmin(trainer.episode_completion_times)
                best_time = trainer.episode_completion_times[best_time_idx]
                print(f"Best completion time: {best_time:.1f}s (Episode {best_time_idx + 1})")

                print(f"\nCharts and data files have been saved to current directory")
            else:
                print("DQN training was not completed successfully")

        elif choice == "2":
            print("\nStarting traditional strategy comparison mode...")
            comparison_results = main_traditional_comparison()

            print(f"\n=== Comparison Completed! ===")
            best_combo = max(comparison_results.keys(), key=lambda k: comparison_results[k])
            print(f"Best strategy combination: {best_combo}")
            print(f"Best performance: {comparison_results[best_combo]:.2f}")

        elif choice == "3":
            print("\nStarting comparison test mode...")
            main_dqn_vs_traditional_comparison()
            print(f"\n=== DQN vs Traditional Methods Comparison Completed! ===")

        elif choice == "4":
            print("\nStarting quick demo mode...")
            demo_trainer = run_demo_mode()

            if demo_trainer:
                print(f"\n=== Demo Completed! ===")
                print(f"Demo training episodes: {len(demo_trainer.episode_rewards)}")
                print(f"Final reward: {demo_trainer.episode_rewards[-1]:.2f}")
            else:
                print("Demo mode was not completed successfully")

        else:
            print("Invalid choice, please enter a number between 1-4")

    except KeyboardInterrupt:
        print("\n\nProgram interrupted by user")
    except Exception as e:
        print(f"\nError occurred during execution: {e}")
        traceback.print_exc()

    print("\nProgram execution completed.")
    print("Thank you for using the Intelligent Warehouse System!")