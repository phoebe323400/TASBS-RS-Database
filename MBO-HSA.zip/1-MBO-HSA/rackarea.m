function Area = rackarea(data_storage)
x = 16; y = 40; z = 14;
area_ratio1 = 0.20;
area_ratio2 = 0.30;
area_ratio3 = 0.50;
total_volume = x * y *z;
volume1 = total_volume * area_ratio1;

% The first area is a rectangular prism.
width1 = 8;     %Choose the appropriate width
length1 = 28;   %Choose the appropriate length
height1 = round(volume1 / (width1*length1));

%The second area is a three-dimensional trapezoid.
bottom_width2 = 12;
bottom_length2 = 34;
height2 = round((total_volume*0.5-volume1-(bottom_width2-width1)*length1*height1-(bottom_width2*(bottom_length2-length1)*height1))/(bottom_width2*bottom_length2));
volume2 = (bottom_width2-width1)*length1*height1 + (bottom_width2*(bottom_length2-length1)*height1) + bottom_width2*bottom_length2*height2;
height2 = height1+height2;

%The third area
bottom_width3 = 16;
bottom_length3 = 40;
height3 =  ((total_volume - volume1-volume2) - (bottom_width3-bottom_width2)*bottom_length2*height2 - bottom_width3*(bottom_length3-bottom_length2)*height2)/...
    (bottom_width3*bottom_length3);
height3 =height2+height3;
figure;
plot3(x,y,z);
hold on;
axis equal;
xlim([0 x+2]);
ylim([0 y+2]);
zlim([0 z+2]);
%Draw the first area
fill3([0 width1 width1 0], [0 0 length1 length1], [0 0 0 0], 'Yellow', 'FaceAlpha', 1); %Bottom
fill3([0 width1 width1 0], [0 0 length1 length1], [height1 height1 height1 height1], 'Yellow', 'FaceAlpha', 1);%Top
fill3([0 width1 width1 0], [0 0 0 0], [0 0 height1 height1], 'Yellow', 'FaceAlpha', 0.5); %Front part
fill3([0 width1 width1 0], [length1 length1 length1 length1], [0 0 height1 height1], 'Yellow', 'FaceAlpha', 0.5);%Back
fill3([0 0 0 0], [0 length1 length1 0], [0 0 height1 height1], 'Yellow', 'FaceAlpha', 0.5);%Left side
fill3([width1 width1 width1 width1], [0 length1 length1 0], [0 0 height1 height1], 'Yellow', 'FaceAlpha', 0.5);%Right side

%Draw the second area
fill3([width1 bottom_width2 bottom_width2 width1], [0 0 0 0], [0 0 height1 height1], 'Magenta', 'FaceAlpha', 0.5);
fill3([0 bottom_width2 bottom_width2 0], [0 0 0 0], [height1 height1 height2 height2], 'Magenta', 'FaceAlpha', 0.5);
fill3([0 width1 width1 0], [length1 length1 length1 length1], [0 0 height1 height1], 'Magenta', 'FaceAlpha', 0.5);
fill3([0 bottom_width2 bottom_width2 0], [bottom_length2 bottom_length2 bottom_length2 bottom_length2], [0 0 height2 height2], 'Magenta', 'FaceAlpha', 0.5);
fill3([0 0 0 0], [bottom_length2 length1 length1  bottom_length2], [0 0 height1 height1], 'Magenta', 'FaceAlpha', 0.5);
fill3([0 0 0 0], [bottom_length2 bottom_length2 0 0], [height1 height2 height2 height1], 'Magenta', 'FaceAlpha', 0.5);
fill3([bottom_width2 bottom_width2 bottom_width2 bottom_width2], [0 0 bottom_length2 bottom_length2], [0 height2 height2 0], 'Magenta', 'FaceAlpha', 0.5); 
fill3([0 bottom_width2 bottom_width2 0], [0 0 bottom_length2 bottom_length2], [height2 height2 height2 height2 ], 'Magenta', 'FaceAlpha', 0.5);
%Draw the third area
fill3([bottom_width2 bottom_width3 bottom_width3 bottom_width2], [0 0 0 0], [0 0 height2 height2], 'blue', 'FaceAlpha', 0.5);
fill3([0 bottom_width3 bottom_width3 0], [0 0 0 0], [height2 height2 height3 height3], 'blue', 'FaceAlpha', 0.5);
fill3([0 bottom_width2 bottom_width2 0], [bottom_length2 bottom_length2 bottom_length2 bottom_length2], [0 0 height2 height2], 'blue', 'FaceAlpha', 0.5);
fill3([0 bottom_width3 bottom_width3 0], [bottom_length3 bottom_length3 bottom_length3 bottom_length3], [0 0 height3 height3], 'blue', 'FaceAlpha', 0.5);
fill3([0 0 0 0], [bottom_length2 bottom_length3 bottom_length3 bottom_length2], [0 0 height2 height2], 'blue', 'FaceAlpha', 0.5);
fill3([0 0 0 0], [bottom_length3 bottom_length3 0 0], [height2 height3 height3 height2], 'blue', 'FaceAlpha', 0.5);
fill3([bottom_width3 bottom_width3 bottom_width3 bottom_width3], [0 0 bottom_length3 bottom_length3], [0 height3 height3 0], 'blue', 'FaceAlpha', 0.5); 
fill3([0 bottom_width3 bottom_width3 0], [0 0 bottom_length3 bottom_length3], [height3 height3 height3 height3 ], 'blue', 'FaceAlpha', 0.5);
Area(1,:) = [[1,8] [1 28] [1 8]];
Area(2,:) = [[9,12] [29 34] [9 11]];
Area(3,:)= [[13,16] [35 40] [12 14]];
hold on;
end