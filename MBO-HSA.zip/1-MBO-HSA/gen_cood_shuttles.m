function shuttle_cood_new  = gen_cood_shuttles(Area,shuttle_NumA,shuttle_NumB,shuttle_NumC,i)
rng('shuffle');
%Used to generate random coordinates for the shuttle vehicles in each area;
if i == 1
    for j = 1: shuttle_NumA
        shuttle_cood_new(j,:) = [randi([1,Area(1,2)]),randi([1,Area(1,4)]),randi([1,Area(1,6)])];
    end
elseif i==2
    for j = 1:shuttle_NumB
        region = randi(i);
        switch region
            case 1
                shuttle_cood_new(j,:) = [randi([1, 12]),randi([1, 34]),randi([9, 11])];
            case 2
                shuttle_cood_new(j,:) = [randi([9, 12]),randi([1, 34]),randi([1, 8])];
            case 3
                shuttle_cood_new(j,:) = [randi([1, 8]),randi([29, 34]),randi([1, 8])];
        end
    end
elseif i == 3
    for j = 1:shuttle_NumC
        region = randi(i);
        switch region
            case 1
                shuttle_cood_new(j,:) = [randi([1, 16]),randi([1, 40]),randi([12, 14])];
            case 2
                shuttle_cood_new(j,:) = [randi([13, 16]),randi([1, 40]),randi([1, 11])];
            case 3
                shuttle_cood_new(j,:) = [randi([1, 12]),randi([35, 40]),randi([1, 11])];
        end
    end
end
end
    
   