% Replace the flying birds
function [flock, leftSide] = replaceLeader(nob, flock, leaderImproves, leaderExchangeMode, leftSide)
    % Make a choice based on different patterns
    switch leaderExchangeMode
        case 1
            % Replace the flying bird and the subsequent birds (numbered 2 and 3) with each other. The bird that was replaced last (numbered 2) will now be replaced by the bird numbered 3, and vice versa.
            [flock, leftSide] = replaceLeaderWithSuccessor(nob, flock, leftSide);
        case 2
            % Replace with the best-performing individuals from the flock.
            flock = replaceLeaderWithBest(nob, flock);
        case 3
            % If the leader bird has not been updated, then replace it with the best-performing bird from the flock.
            if ~leaderImproves
                flock = replaceLeaderWithBest(nob, flock);
            end
        case 4
            [flock,leftSide] = newreplaceLeaderWithSuccessor(nob, flock, leftSide);  
    end
end



