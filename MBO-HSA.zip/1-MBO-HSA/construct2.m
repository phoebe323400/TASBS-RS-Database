function [shuttle_new,trans_shuttle,lift,t,T,task_sequence] = construct2(shuttle_new,task_sequence)
v_shuttle = 2;
a_shuttle = 1.5;
v_trans_shuttle = 2;
a_trans_shuttle = 1.5;
v_lift = 3;
a_lift = 2;
height = 0.8;
width = 0.5;
Length = 0.6;
z = 14;
trans_shuttle = struct();
for i = 1 : z
    trans_shuttle(i).Current_running_status=0;
    trans_shuttle(i).original_cood = 1;  
    trans_shuttle(i).fir_time = 0;
    trans_shuttle(i).fir_rel_time=0;
    trans_shuttle(i).sec_time=0;
    trans_shuttle(i).sec_rel_time = 0;  
    trans_shuttle(i).trd_time=0;
    trans_shuttle(i).trd_rel_time = 0;
    trans_shuttle(i).task_end_time = [];
end

lift = struct();
for i = 1 : 6
    lift(i).cood = [];  
    lift(i).Current_running_status=0;
    lift(i).Mission_end_position=[];    
    lift(i).shuttle= [];  
    lift(i).fir_time = 0;
    lift(i).fir_rel_time = 0;
    lift(i).sec_time = 0;
    lift(i).sec_rel_time = 0;
    lift(i).Next_task_location=[];
end


t = struct();
fields = {'x', 'z', 't','t0','t1', 't2', 't3', 't4', 't5', 't6', ...
    't7', 't8', 't9', 't10', 't11', 't12', 't13', ...
    't14', 't15', 't16', 't17', 't18', 't19', ...
    't20', 't21', 't22', 't23', 't24', 't25', ...
    't26', 't27', 't28', 't29', 't30', 't31', 't32',...
    't33', 't34', 't35', 't36', 't37', 't38', 't39', 't40',...
    't41', 't42', 't43', 't44', 't45', 't46'};

for i = 1:6
    for j = 1:length(fields)
        t(i).(fields{j}) = 0;  
    end
end



    function running_status = now_status(shuttle_new,trans_shuttle,lift)
        running_status = 0;
        for i = 1:14
            running_status = running_status + trans_shuttle(i).Current_running_status;
        end
        
        for i = 1:6
            running_status = running_status + shuttle_new(i).Current_running_status;
        end
        
        for i = 1:2
            running_status = running_status+ lift(i).Current_running_status;
        end
    end
    running_status  = now_status(shuttle_new,trans_shuttle,lift);
%%
AT = [];
unexecuted_task =[];
shuttle_num = [];

for k = 1:2:max([shuttle_new.tasknumber])
    
    for i = 1:6
        if all(isnan(shuttle_new(i).task(k,:)))
            t(i).t1 = 0.01;
        else
            origin_point = [1 1 1];
            lift1 = 1;
            lift2 = 16;
            shuttle_point = shuttle_new(i).original_cood;
            if shuttle_point(3) ==  origin_point(3)   
                if shuttle_point(1) == origin_point(1) 
                    dis = abs(shuttle_point(2)-origin_point(2));
                    shuttle_point(2) = origin_point(2);
                    t1 = caltime(dis,v_shuttle,a_shuttle,Length);
                    t(i).t1 = t1 ;
                else  
                    dis = abs(shuttle_point(2)-origin_point(2));
                    shuttle_point(2) = origin_point(2);
                    t1 = caltime(dis,v_shuttle,a_shuttle,Length);
                    t(i).t1 = t1;
                end
            else   
                dis = abs(shuttle_point(2) - origin_point(2));
                shuttle_point(2) = origin_point(2);      
                t1 = caltime(dis,v_shuttle,a_shuttle,Length);
                t(i).t1 = t1 ;
            end
            t(i).z = shuttle_point(3);    
            shuttle_new(i).current_cood = shuttle_point;
        end
    end
    %% 
    sametier = [t.z]';             
    [uniqueValues, ~, idx] = unique(sametier); 
    result = cell(length(uniqueValues), 1);
    for i = 1:length(uniqueValues)
        result{i} = find(idx == i);   
    end  
    if length(uniqueValues) < 6   
        result(length(uniqueValues)+1:6,:) = {inf};
    end
    %% 
    finish_task = [];
    for i = 1:6
        if size(result{i,1},1) > 1           
            e = min([t(result{i,1}).t1]');   
            index1 = find([t.t1]== e);             
            common_elements= intersect(result{i,1},index1);  
            shuttle_num = common_elements(1);                
            remainingInA = setdiff(result{i,1},shuttle_num);   
            shuttle_point = shuttle_new(shuttle_num).current_cood;  
            if all(isnan(shuttle_new(shuttle_num).task(k,:)))
                t(shuttle_num).t2 = 0.01;
                t(shuttle_num).t3 = 0.01;
                t(shuttle_num).t4 = 0.01;
                t(shuttle_num).t5 = 0.01;
                t(shuttle_num).t6 = 0.01;
            else
                if trans_shuttle(shuttle_point(3)).Current_running_status == 0  
                    trans_shuttle(shuttle_point(3)).Current_running_status = 1;
                    trans_shuttle(shuttle_point(3)).fir_time = 1;
                    dis = abs(shuttle_point(1) - trans_shuttle(shuttle_point(3)).original_cood);  
                    t2 = caltime(dis,v_trans_shuttle,a_trans_shuttle,width);
                    t(shuttle_num).t2 = t2 ;
                    t(shuttle_num).t3 = max(t(shuttle_num).t2 ,t(shuttle_num).t1) ;
                    if shuttle_point(1) <= 8 
                        shuttle_point(1) = lift1;
                        t(shuttle_num).t4 = t(shuttle_num).t3 + 2;  
                        t(shuttle_num).t5 = t(shuttle_num).t4 + t(shuttle_num).t2;
                        t(shuttle_num).t6 = t(shuttle_num).t5 + 2;  
                        trans_shuttle(shuttle_point(3)).original_cood = 1;
                    else
                        dis2 = (lift2 - shuttle_point(1));
                        t2 = caltime(dis2,v_trans_shuttle,a_trans_shuttle,width);
                        shuttle_point(1) = lift2;
                        t(shuttle_num).t4 = t(shuttle_num).t3 + 2;
                        t(shuttle_num).t5 = t(shuttle_num).t4 + t2;
                        t(shuttle_num).t6 = t(shuttle_num).t5 + 2;
                        trans_shuttle(shuttle_point(3)).original_cood = 16;
                    end
                    shuttle_new(shuttle_num).current_cood = shuttle_point;
                end
            end
            finish_task = [finish_task,shuttle_num];
            unexecuted_task =[unexecuted_task;remainingInA];
        elseif size(result{i,1},1) == 1 && result{i,1} ~= inf  
            shuttle_num = result{i,1};  
            shuttle_point = shuttle_new(shuttle_num).current_cood; 
            if all(isnan(shuttle_new(shuttle_num).task(k,:)))
                t(shuttle_num).t2 = 0.01;
                t(shuttle_num).t3 = 0.01;
                t(shuttle_num).t4 = 0.01;
                t(shuttle_num).t5 = 0.01;
                t(shuttle_num).t6 = 0.01;
            else
                if trans_shuttle(shuttle_point(3)).Current_running_status == 0 
                    trans_shuttle(shuttle_point(3)).Current_running_status = 1;
                    trans_shuttle(shuttle_point(3)).fir_time = 1;    
                    dis1 = abs(shuttle_point(1) - origin_point(1));   
                    t1 = caltime(dis1,v_trans_shuttle,a_trans_shuttle,width);
                    t(shuttle_num).t2 = t1 ;     
                    t(shuttle_num).t3 = max(t(shuttle_num).t2,t(shuttle_num).t1);
                    if shuttle_point(1) <= 8    
                        shuttle_point(1) = origin_point(1);
                        shuttle_new(shuttle_num).current_cood = shuttle_point;
                        t(shuttle_num).t4 = t(shuttle_num).t3 + 2;  
                        t(shuttle_num).t5 = t(shuttle_num).t4 + t(shuttle_num).t2;
                        t(shuttle_num).t6 = t(shuttle_num).t5 + 2;
                        trans_shuttle(shuttle_point(3)).original_cood = lift1;                      
                    else    
                        dis2 = (lift2 - shuttle_point(1));   
                        t2 = caltime(dis2,v_trans_shuttle,a_trans_shuttle,width);
                        shuttle_point(1) = lift2;
                        shuttle_new(shuttle_num).current_cood = shuttle_point;
                        t(shuttle_num).t4 = t(shuttle_num).t3 + 2;  
                        t(shuttle_num).t5 = t(shuttle_num).t4 + t2;
                        t(shuttle_num).t6 = t(shuttle_num).t5 + 2;  
                        trans_shuttle(shuttle_point(3)).original_cood = lift2;  
                    end
                end
            end
            shuttle_new(shuttle_num).current_cood = shuttle_point;  
        elseif result{i,1} == inf
            result{i,1} = inf;
        end
         
    end
    %% 
    if exist('unexecuted_task', 'var')  && exist('finish_task', 'var')
        for j = 1:length(unexecuted_task)
            if length(finish_task) == 1  
                
                if j ==1
                    shuttle_num = finish_task;
                    [~,indices1]=sort([t(unexecuted_task).t1]);
                    exectued_choice = unexecuted_task(indices1(j));
                else
                    shuttle_num = unexecuted_task(indices1(j-1));
                    exectued_choice = unexecuted_task(indices1(j));
                end
            else   
                shuttle_num = finish_task(j);      
                exectued_choice = unexecuted_task(j); 
            end
            if all(isnan(shuttle_new(exectued_choice).task(k,:)))
                t(exectued_choice).t2 = 0.01;
                t(exectued_choice).t3 = 0.01;
                t(exectued_choice).t4 = 0.01;
                t(exectued_choice).t5 = 0.01;
                t(exectued_choice).t6 = 0.01;
            else
                shuttle_point = shuttle_new(exectued_choice).current_cood;
                if shuttle_point(1) > 8
                    lift_choice = lift2;
                else
                    lift_choice = lift1;
                end

                dis1 = abs(trans_shuttle(t(shuttle_num).z).original_cood -shuttle_point(1));
                trans_shuttle(t(shuttle_num).z).Current_running_status = 0;
                trans_shuttle(t(exectued_choice).z).Current_running_status = 1;  
                
                t1 = caltime(dis1, v_trans_shuttle, a_trans_shuttle,width); 
                t(exectued_choice).t2 = t1;
                t(exectued_choice).t3 = max(t(exectued_choice).t2 + t(shuttle_num).t6, t(exectued_choice).t1);
                t(exectued_choice).t4 = t(exectued_choice).t3 + 2;  
                dis2 = abs(lift_choice - shuttle_new(exectued_choice).original_cood(1));
                t2 = caltime(dis2, v_trans_shuttle, a_trans_shuttle,width);  
                t(exectued_choice).t5 = t(exectued_choice).t4 + t2; 
                t(exectued_choice).t6 = t(exectued_choice).t5 + 2; 
                
                shuttle_point(1) = lift_choice;
                shuttle_new(exectued_choice).current_cood = shuttle_point;
                trans_shuttle(shuttle_point(3)).original_cood = lift_choice;
            end
        end
    end
     
    for i = 1:6
        shuttle_point = shuttle_new(i).original_cood;
        
        if shuttle_point(1) <=8     
            lift(i).cood = 1;       
            lift(i).Mission_end_position = shuttle_new(i).original_cood;  
            lift(i).fir_time = t(i).t4;    
            lift(i).shuttle = i;
        else
            lift(i).cood = 16; 
            lift(i).Mission_end_position = shuttle_new(i).original_cood;
            lift(i).fir_time = t(i).t4;  
            lift(i).shuttle = i;
        end
    end
    count_ones1 = find([lift.cood] == 1);   
    [~, indices1] = sort([t(count_ones1).t4]);
    
    
    count_ones16 = find([lift.cood] == 16);
    [~, indices16] = sort([t(count_ones16).t4]);
    
    
    
    for i = 1:length(indices1)   
        shuttle_num = count_ones1(indices1(i));
        storage_point = shuttle_new(shuttle_num).task(k,:);
        retrieval_point = shuttle_new(shuttle_num).task(k+1,:);
        shuttle_point = shuttle_new(shuttle_num).current_cood;
        if all(isnan(shuttle_new(shuttle_num).task(k,:)))
            t(shuttle_num).t7 = 0.01;
            t(shuttle_num).t8 = 0.01;
            t(shuttle_num).t9 = 0.01;
            t(shuttle_num).t10 = 0.01;
            t(shuttle_num).t11 = 0.01;
            t(shuttle_num).t12 = 0.01;
            t(shuttle_num).t13 = 0.01;
        else
            if i <= 1    
                if lift(shuttle_num).Current_running_status == 0
                    lift(shuttle_num).Current_running_status =1;
                    dis1 = abs(shuttle_point(3) - lift1);     
                    t1 = caltime(dis1,v_lift,a_lift,height);
                    t(shuttle_num).t7 = t1;
                    t(shuttle_num).t8 = t(shuttle_num).t7 + t(shuttle_num).t4;      
                    t(shuttle_num).t9 = max(t(shuttle_num).t6,t(shuttle_num).t8) + 2;
                    t(shuttle_num).t10 = t(shuttle_num).t9 + t(shuttle_num).t7;   
                    t(shuttle_num).t11 = t(shuttle_num).t10 + 2;                   
                    dis2 = abs(storage_point(3)-lift1);                            
                    t2 = caltime(dis2,v_lift,a_lift,height);                    
                    shuttle_point(3) = storage_point(3);
                    t(shuttle_num).t12 = t(shuttle_num).t11 + t2 ;                  
                    t(shuttle_num).t13 = t(shuttle_num).t12 + 2;                 
                    lift(shuttle_num).currtent_tier = storage_point(3);
                end
            else         
                shuttle_point = shuttle_new(shuttle_num).current_cood;
                if lift(shuttle_num).Current_running_status == 0
                    lift(shuttle_num).Current_running_status =1;
                    dis3 = abs(lift(count_ones1(indices1(i-1))).currtent_tier - shuttle_point(3));
                    t3 = caltime(dis3,v_lift,a_lift,height);
                    t(shuttle_num).t7 = t3;
                    t(shuttle_num).t8 = t(count_ones1(indices1(i-1))).t13 + t(shuttle_num).t7; 
                    t(shuttle_num).t9 = max(t(shuttle_num).t6,t(shuttle_num).t8) + 2;
                    dis5 = abs(shuttle_point(3) - lift1);  
                    t5 = caltime(dis5,v_lift,a_lift,height);
                    t(shuttle_num).t10 = t(shuttle_num).t9 + t5;
                    t(shuttle_num).t11 = t(shuttle_num).t10 + 2;
                    dis4 = abs(lift1 - storage_point(3));
                    t4 = caltime(dis4,v_lift,a_lift,height);
                    shuttle_point(3) = storage_point(3);
                    t(shuttle_num).t12 = t(shuttle_num).t11 + t4 ;
                    t(shuttle_num).t13 = t(shuttle_num).t12 + 2;
                    lift(shuttle_num).currtent_tier = shuttle_new(shuttle_num).task(k,3);
                end
            end
        end
        shuttle_new(shuttle_num).current_cood = shuttle_point;  
        shuttle_new(shuttle_num).storage_cood = storage_point;
        shuttle_new(shuttle_num).retrieval_cood = retrieval_point;
        end_tier1 = shuttle_new(shuttle_num).task(k,3); 
        t(shuttle_num).z = shuttle_point(3);   
    end  
    for i = 1:length(indices16)  
        shuttle_num = count_ones16(indices16(i));
        shuttle_point = shuttle_new(shuttle_num).current_cood;
        storage_point = shuttle_new(shuttle_num).task(k,:);
        retrieval_point = shuttle_new(shuttle_num).task(k+1,:);
        if all(isnan(shuttle_new(shuttle_num).task(k,:)))
            t(shuttle_num).t7 = 0.01;
            t(shuttle_num).t8 = 0.01;
            t(shuttle_num).t9 = 0.01;
            t(shuttle_num).t10 = 0.01;
            t(shuttle_num).t11 = 0.01;
            t(shuttle_num).t12 = 0.01;
            t(shuttle_num).t13 = 0.01;
        else
            if i <= 1  
                if lift(shuttle_num).Current_running_status == 0
                    lift(shuttle_num).Current_running_status =1;
                    dis3 = abs(shuttle_point(3) - lift1);
                    t3 = caltime(dis3,v_lift,a_lift,height);
                    t(shuttle_num).t7 = t3;
                    t(shuttle_num).t8 = t(shuttle_num).t7 + t(shuttle_num).t4; 
                    t(shuttle_num).t9 = max(t(shuttle_num).t6,t(shuttle_num).t8) + 2;
                    t(shuttle_num).t10 = t(shuttle_num).t9 + t(shuttle_num).t7; 
                    t(shuttle_num).t11 = t(shuttle_num).t10 + 2;
                    dis4 = abs(storage_point(3)-lift1);
                    t4 = caltime(dis4,v_lift,a_lift,height); 
                    shuttle_point(3) = storage_point(3);
                    t(shuttle_num).t12 = t(shuttle_num).t11 + t4 ;
                    t(shuttle_num).t13 = t(shuttle_num).t12 + 2;
                    lift(shuttle_num).currtent_tier = storage_point(3);
                end   
            else   
                shuttle_point = shuttle_new(shuttle_num).current_cood;
                if lift(shuttle_num).Current_running_status == 0
                    lift(shuttle_num).Current_running_status =1;
                    dis3 = abs(lift(count_ones16(indices16(i-1))).currtent_tier - shuttle_point(3));
                    t3 = caltime(dis3,v_lift,a_lift,height);
                    t(shuttle_num).t7 = t3;
                    t(shuttle_num).t8 = t(count_ones16(indices16(i-1))).t13 + t(shuttle_num).t7;
                    t(shuttle_num).t9 = max(t(shuttle_num).t6,t(shuttle_num).t8) + 2;
                    dis5 = abs(shuttle_point(3) - lift1);  
                    t5 = caltime(dis5,v_lift,a_lift,height);
                    t(shuttle_num).t10 = t(shuttle_num).t9 + t5;
                    t(shuttle_num).t11 = t(shuttle_num).t10 + 2;
                    dis4 = abs(lift1 - storage_point(3));   
                    t4 = caltime(dis4,v_lift,a_lift,height);
                    shuttle_point(3) = shuttle_new(shuttle_num).task(k,3);
                    t(shuttle_num).t12 = t(shuttle_num).t11 + t4 ;
                    t(shuttle_num).t13 = t(shuttle_num).t12 + 2;  
                    lift(shuttle_num).currtent_tier = storage_point(3);
                end
            end
        end
        shuttle_new(shuttle_num).current_cood = shuttle_point;
        end_tier16 = storage_point(3);       
        shuttle_new(shuttle_num).storage_cood = storage_point;
        shuttle_new(shuttle_num).retrieval_cood = retrieval_point;
        t(shuttle_num).z = shuttle_point(3);  
    end
    %% 
    [time_t6, indices6] = sort([t.t6]); 
    for i = 1 :length(indices6)
        shuttle_point = shuttle_new(indices6(i)).original_cood;
        trans_shuttle(shuttle_point(3)).Current_running_status = 0;
        trans_shuttle(shuttle_point(3)).fir_rel_time = time_t6(1);  
        time_t6(1) = [];
    end
    
    selected_values1 = [t(count_ones1).t13];  
    [release_1, index] = sort(selected_values1);
    for i = 1 : length(selected_values1)
        lift(count_ones1(index(i))).Current_running_status = 0;
        lift(count_ones1(index(i))).fir_rel_time = t(count_ones1(i)).t13;  
        release_1(1) =[]; 
    end
    selected_values2 = [t(count_ones16).t13];
    [release_2, index] = sort(selected_values2);
    for i = 1 :length(selected_values2)
        lift(count_ones16(index(i))).Current_running_status = 0;
        lift(count_ones16(index(i))).fir_rel_time = t(count_ones16(i)).t13;
        release_2(1) =[];
    end
    
  
   
    for i = 1:6
        t(i).z = shuttle_new(i).current_cood(3);   
    end
   
    [~, indices11] = sort(([t.t11]')); 
    for i = 1:6 
        shuttle_num = indices11(i);
        if all(isnan(shuttle_new(shuttle_num).task(k,:)))
            t(shuttle_num).t14 = 0.01;
            t(shuttle_num).t15 = 0.01;
            t(shuttle_num).t16 = 0.01;
            t(shuttle_num).t17 = 0.01;
            t(shuttle_num).t18 = 0.01;
            t(shuttle_num).t19 = 0.01;
            t(shuttle_num).t20 = 0.01;
        else
            shuttle_point = shuttle_new(shuttle_num).current_cood; 
            storage_task = shuttle_new(shuttle_num).task(k,:);     
            %shuttle_new(shuttle_num).retrieval_cood = storage_task; 
            storage_x = storage_task(1); 
            storage_y = storage_task(2);
            storage_z = storage_task(3);
            trans_shuttle(storage_z).Current_running_status = 1;
            storage_trans_cood = trans_shuttle(storage_z).original_cood;
            trans_shuttle(storage_z).sec_time = t(shuttle_num).t11;
            dis1 = abs(shuttle_point(1)-storage_trans_cood);
            t1 = caltime(dis1,v_trans_shuttle,a_trans_shuttle,width);
            t(shuttle_num).t14 = t1;
            t(shuttle_num).t15 = max(t(shuttle_num).t14+t(shuttle_num).t11,t(shuttle_num).t13);
            t(shuttle_num).t16 = t(shuttle_num).t15 + 2;
            dis2 = abs(shuttle_point(1)-storage_x);
            t2 = caltime(dis2,v_trans_shuttle,a_trans_shuttle,width);
            t(shuttle_num).t17 = t(shuttle_num).t16 + t2;
            t(shuttle_num).t18 = t(shuttle_num).t17 + 2;
            dis3 = abs(storage_y-storage_task(2));  
            t3 = caltime(dis3,v_shuttle,a_shuttle,Length);
            t(shuttle_num).t19 = t(shuttle_num).t18 + t3;
            t(shuttle_num).t20 = t(shuttle_num).t19 + 2;
            shuttle_point(1) = storage_x;
            shuttle_point(2) = storage_y;
            shuttle_new(shuttle_num).current_cood = shuttle_point;
            shuttle_new(shuttle_num).retrieval_cood = shuttle_new(shuttle_num).task(k+1,:);
        end
    end
    
    [time_t18, indices18] = sort([t.t18]);
    for i = 1 :length(indices18)
        trans_shuttle(t(indices18(i)).z).Current_running_status = 0;
        trans_shuttle(t(indices18(i)).z).sec_rel_time = time_t18(1);  
        trans_shuttle(t(indices18(i)).z).original_cood = shuttle_new(indices18(i)).current_cood(1);
        time_t18(1) = [];
    end
    %%
    [~, indices20] = sort([t.t20]);
    for i = 1:6
        if all(isnan(shuttle_new(indices20(i)).task(k,:)))
            for j = 21:38
                t(indices20(i)).(['t' num2str(j)]) = 0.01;
            end
        else
            storge_task = shuttle_new(indices20(i)).current_cood;
            retrieval_task = shuttle_new(indices20(i)).retrieval_cood;
            if  storge_task(3) == retrieval_task(3)   
                trans_shuttle_num = storge_task(3);  
                shuttle_point = storge_task;  
                if storge_task(1) == retrieval_task(1)                             
                    
                    for j = 21:31
                        t(indices20(i)).(['t', num2str(j)]) = t(indices20(i)).(['t', num2str(j-1)]);
                    end  
                    dis1 = abs(shuttle_point(2)-retrieval_task(2)); 
                    t1 = caltime(dis1,v_shuttle,a_shuttle,Length);
                    t(indices20(i)).t32 = t(indices20(i)).t31 + t1; 
                    t(indices20(i)).t33 = t(indices20(i)).t32 + 2;  
                    trans_shuttle(trans_shuttle_num).trd_time = t(indices20(i)).t33;
                    if trans_shuttle(trans_shuttle_num).Current_running_status == 0
                        trans_shuttle(trans_shuttle_num).Current_running_status = 1;
                        dis2 = abs(retrieval_task(2)-1);  
                        t2 = caltime(dis2,v_shuttle,a_shuttle,Length);  
                        shuttle_point(2) = 1;
                        t(indices20(i)).t34 = t(indices20(i)).t33 + t2;
                        dis3 = abs(retrieval_task(1)-trans_shuttle(trans_shuttle_num).original_cood); 
                        t3 = caltime(dis3,v_trans_shuttle,a_trans_shuttle,width);
                        t(indices20(i)).t35 = t(indices20(i)).t34 +t3;
                        t(indices20(i)).t36 = max(t(indices20(i)).t34,t(indices20(i)).t35) + 2; 
                        if retrieval_task(1) <= 8  
                            end_cood = 1;
                        else
                            end_cood = 16;
                        end
                        dis4 = abs(end_cood - retrieval_task(1));
                        t4 = caltime(dis4,v_trans_shuttle,a_trans_shuttle,width);
                        t(indices20(i)).t37 = t(indices20(i)).t36 + t4;
                        t(indices20(i)).t38 = t(indices20(i)).t37 + 2;
                    else  
                        indices1 = find([t.z] == trans_shuttle_num);
                        if t(indices1(1)).t34 ~= 0 
                            unexecuted_task = indices1(2);
                            finish_task = indices1(1);
                        else
                            unexecuted_task = indices1(1);
                            finish_task = indices1(2);
                        end
                        trans_shuttle(trans_shuttle_num).Current_running_status = 1;
                        dis2 = abs(retrieval_task(2)-1);   
                        t2 = caltime(dis2,v_shuttle,a_shuttle,Length);   
                        shuttle_point(2) = 1;
                        t(unexecuted_task).t34 = t(finish_task).t38 + t2;
                        dis3 = abs(retrieval_task(1)-trans_shuttle(trans_shuttle_num).original_cood); 
                        t3 = caltime(dis3,v_trans_shuttle,a_trans_shuttle,width); 
                        t(unexecuted_task).t35 = t(unexecuted_task).t34 +t3;
                        t(unexecuted_task).t36 = max(t(unexecuted_task).t34,t(unexecuted_task).t35) + 2; 
                        if retrieval_task(1) <= 8 
                            end_cood = 1;
                        else
                            end_cood = 16;
                        end
                        dis4 = abs(end_cood - retrieval_task(1));    
                        t4 = caltime(dis4,v_trans_shuttle,a_trans_shuttle,width);
                        t(unexecuted_task).t37 = t(unexecuted_task).t36 + t4;
                        t(unexecuted_task).t38 = t(unexecuted_task).t37 + 2;
                    end
                    trans_shuttle(trans_shuttle_num).original_cood = end_cood;
                    shuttle_point(1) = end_cood;
                    shuttle_new(indices20(i)).current_cood = shuttle_point;
                    t(indices20(i)).x =  shuttle_new(indices20(i)).current_cood(1);  
                else     
                    t(indices20(i)).t21 = t(indices20(i)).t20 + t3; 
                    if t(indices20(i)).t20 > trans_shuttle(trans_shuttle_num).sec_rel_time && trans_shuttle(trans_shuttle_num).Current_running_status == 0
                        trans_shuttle(trans_shuttle_num).Current_running_status = 1;
                        dis1 =  abs(trans_shuttle(trans_shuttle_num).original_cood - shuttle_new(indices20(i)).current_cood(1));
                        t1 = caltime(dis1,v_trans_shuttle,a_trans_shuttle,width);
                        t(indices20(i)).t22 = t(indices20(i)).t21 + t1;
                        t(indices20(i)).t23 = t(indices20(i)).t22 + 2; 
                        dis2 = abs(shuttle_point(1)-shuttle_new(indices20(i)).retrieval_cood(1));
                        t2 = caltime(dis2,v_trans_shuttle,a_trans_shuttle,width);
                        t(indices20(i)).t24 = t(indices20(i)).t23 + t2;
                        t(indices20(i)).t25 = t(indices20(i)).t25 + t2; 
                        for j = 26:31
                            t(indices20(i)).(['t', num2str(j)]) = t(indices20(i)).(['t', num2str(j-1)]);
                        end
                        dis3 = abs(shuttle_new(indices20(i)).current_cood(2)-shuttle_new(indices20(i)).retrieval_cood(2));
                        t3 = caltime(dis3,v_shuttle,a_shuttle,Length);
                        t(indices20(i)).t32 = t(indices20(i)).t31 + t3;  
                        t(indices20(i)).t33 = t(indices20(i)).t32 + 2;   
                        trans_shuttle(trans_shuttle_num).trd_time = t(indices20(i)).t33;
                        t(indices20(i)).t34 = t(indices20(i)).t33 + t3;  
                        shuttle_point(1) = shuttle_new(indices20(i)).retrieval_cood(1);
                        shuttle_point(2) = shuttle_new(indices20(i)).retrieval_cood(2);
                        if shuttle_point(1) <= 8
                            end_cood = 1;
                        else
                            end_cood = 16;
                        end
                        dis4 = abs(shuttle_new(indices20(i)).retrieval_cood(1)-shuttle_new(indices20(i)).retrieval_cood(1));
                        t4 = caltime(dis4,v_trans_shuttle,a_trans_shuttle,width);  
                        t(indices20(i)).t35 = t(indices20(i)).t34 + t4; 
                        t(indices20(i)).t36 = t(indices20(i)).t35 + 2;  
                        lift(indices20(i)).sec_time = t(indices20(i)).t35;
                        dis5 = abs(end_cood-shuttle_new(indices20(i)).retrieval_cood(1));
                        t5 = caltime(dis5,v_trans_shuttle,a_trans_shuttle,width);
                        t(indices20(i)).t37 = t(indices20(i)).t36 + t5;
                        t(indices20(i)).t38 = t(indices20(i)).t37 + 2; 
                        shuttle_point(1) = end_cood;
                        
                    end
                end
            else  
                
            end
            lift(indices20(i)).cood = shuttle_point(1);
        end
    end
    %% 
    [time_t38, indices38] = sort([t.t38]);
    for i = 1 :length(indices38)
        trans_shuttle(t(indices38(i)).z).Current_running_status = 0;
        trans_shuttle(t(indices38(i)).z).trd_rel_time = time_t38(1);  
        trans_shuttle(t(indices38(i)).z).original_cood = shuttle_new(indices38(i)).current_cood(1);
        time_t38(1) = [];
    end
    
    %% 
    count_ones1 = find([lift.cood] == 1);    
    selected_values1 = [t(count_ones1).t36];  
    [~, indices1] = sort(selected_values1);
    
    count_ones16 = find([lift.cood] == 16);    
    selected_values16 = [t(count_ones16).t36]; 
    [~, indices16] = sort(selected_values16);
    for i = 1:length(indices1)   
        shuttle_num = count_ones1(indices1(i));
        shuttle_point = shuttle_new(shuttle_num).current_cood;
        if all(isnan(shuttle_new(shuttle_num).task(k,:)))
            for j = 39:42
                t(shuttle_num).(['t' num2str(j)]) = 0.01;
            end
        else
            if i <= 1    
                if lift(shuttle_num).Current_running_status == 0
                    lift(shuttle_num).Current_running_status = 1;
                    lift(shuttle_num).sec_time = t(shuttle_num).t35;
                    dis1 = abs(end_tier1 - shuttle_point(3));  
                    t1 = caltime(dis1,v_lift,a_lift,height);
                    t(shuttle_num).t39 = max(t(shuttle_num).t36+t1, t(shuttle_num).t38); 
                    t(shuttle_num).t40 = t(shuttle_num).t39 + 2; 
                    dis2 = abs(1 - shuttle_point(3)); 
                    t2 = caltime(dis2,v_lift,a_lift,height);
                    t(shuttle_num).t41 = t(shuttle_num).t40 + t2; 
                    t(shuttle_num).t42 = t(shuttle_num).t41 + 2;  
                end
                shuttle_point(3) = 1;
            else  
                if lift(shuttle_num).Current_running_status == 0
                    lift(shuttle_num).Current_running_status =1;
                    lift(shuttle_num).sec_time = t(shuttle_num).t35;
                    dis1 = abs(1 - shuttle_point(3));
                    t1 = caltime(dis1,v_lift,a_lift,height);
                    t(shuttle_num).t39 = t(count_ones1(indices1(i-1))).t42 + t1; 
                    t(shuttle_num).t40 = t(shuttle_num).t39 + 2; 
                    t(shuttle_num).t41 = t(shuttle_num).t40 + t1;
                    t(shuttle_num).t42 = t(shuttle_num).t41 + 2;
                end
                shuttle_point(3) = 1;
            end
        end
        shuttle_new(shuttle_num).current_cood = shuttle_point;
        t(shuttle_num).z = 1;
        shuttle_new(shuttle_num).original_cood = shuttle_point;
        t(shuttle_num).t0 = t(shuttle_num).t + t(shuttle_num).t42;
        t(shuttle_num).t = t(shuttle_num).t0;
        lift(shuttle_num).current_tier = lift1;
        end_tier1 = 1;
    end
    for i = 1:length(indices16)    
        end_tier16 = 16;
        shuttle_num = count_ones16(indices16(i));
        shuttle_point = shuttle_new(count_ones16(indices16(i))).current_cood;
        if all(isnan(shuttle_new(shuttle_num).task(k,:)))
            for j = 39:42
                t(shuttle_num).(['t' num2str(j)]) = 0.01;
            end
        else
            if i <= 1   
                if lift(shuttle_num).Current_running_status == 0
                    lift(shuttle_num).Current_running_status =1;
                    lift(shuttle_num).sec_time = t(shuttle_num).t35;
                    dis1 = abs(end_tier16 - shuttle_point(3));
                    t1 = caltime(dis1,v_lift,a_lift,height);
                    t(shuttle_num).t39 = max(t(shuttle_num).t36+t1,t(shuttle_num).t38);
                    t(shuttle_num).t40 = t(shuttle_num).t39 + 2; 
                    dis2 = abs(1 - shuttle_point(3));
                    t2 = caltime(dis2,v_lift,a_lift,height);
                    t(shuttle_num).t41 = t(shuttle_num).t40 + t2;
                    t(shuttle_num).t42 = t(shuttle_num).t41 + 2;  
                end
                shuttle_point(3) = 1;
            else  
                if lift(shuttle_num).Current_running_status == 0
                    lift(shuttle_num).Current_running_status =1;
                    lift(shuttle_num).sec_time = t(shuttle_num).t35;
                    dis1 = abs(1 - shuttle_point(3));
                    t1 = caltime(dis1,v_lift,a_lift,height);
                    t(shuttle_num).t39 = t(count_ones16(indices16(i-1))).t42 + t1; 
                    t(shuttle_num).t40 = t(shuttle_num).t39 + 2; 
                    t(shuttle_num).t41 = t(shuttle_num).t40 + t1; 
                    t(shuttle_num).t42 = t(shuttle_num).t41 + 2;  
                end
                shuttle_point(3) = 1;
            end
        end
        shuttle_new(shuttle_num).current_cood = shuttle_point;
        t(shuttle_num).z = 1;
        shuttle_new(shuttle_num).original_cood = shuttle_point;  
        t(shuttle_num).t0 = t(shuttle_num).t + t(shuttle_num).t42;
        t(shuttle_num).t = t(shuttle_num).t0;
        lift(shuttle_num).current_tier = lift1; 
        end_tier16 = 1;
    end
    %% 
    count_ones1 = find([lift.cood] == 1);    
    selected_values1 = [t(count_ones1).t41]; 
    
    
    count_ones16 = find([lift.cood] == 16);
    selected_values16 = [t(count_ones16).t41];
    
    [release_1, indices1] = sort(selected_values1);
    for i = 1 : length(selected_values1)
        lift(count_ones1(indices1(i))).Current_running_status = 0;
        lift(count_ones1(indices1(i))).sec_rel_time = t(count_ones1(i)).t41;  
        release_1(1) =[];  
    end
    
    [release_2, indices16] = sort(selected_values16);
    for i = 1 :length(selected_values16)
        lift(count_ones16(indices16(i))).Current_running_status = 0;
        lift(count_ones16(indices16(i))).sec_rel_time = t(count_ones16(i)).t41;
        release_2(1) =[];
    end
    %% 
    T = max([t.t]);
    AT= [AT;T];
    for i = 1:42   
        for j = 1:6
            fieldName = ['t', num2str(i)];
            t(j).(fieldName) = 0;    
        end
    end
    unexecuted_task = [];
    finish_task = [];
    for i = 1:6
        lift(i).fir_time = 0;
        lift(i).fir_rel_time = 0;
        lift(i).sec_time = 0;
        lift(i).sec_rel_time = 0;
    end
    for i = 1:14
        trans_shuttle(i).fir_time = 0;
        trans_shuttle(i).fir_rel_time = 0;
        trans_shuttle(i).sec_time = 0;
        trans_shuttle(i).sec_rel_time = 0;
        trans_shuttle(i).trd_time = 0;
        trans_shuttle(i).trd_rel_time = 0;
    end
end  


end