function [ breaks ] = randbreaks( min_tour , n , num_brks, cum_prob)
        if min_tour == 1
            tmp_brks = randperm(n-1);
            breaks = sort(tmp_brks(1:num_brks));
        else
            num_adjust = find(rand < cum_prob,1)-1;
            spaces = ceil(num_brks*rand(1,num_adjust));
            adjust = zeros(1,num_brks);
            for kk = 1:num_brks
                adjust(kk) = sum(spaces == kk);
            end
            breaks = min_tour*(1:num_brks) + cumsum(adjust);
        end

        for i = 1:num_brks
            if mod(breaks(i),2) == 1
                breaks(i) = breaks(i) + 1;
            end
        end
end