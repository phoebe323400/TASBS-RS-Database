% Explore the non-neighborhood of the current solution / bird
function [neighbourSet,number] = createNeighborSet(non, NON, solution,new_shuttle_cood)
%The leader bird creates non=3 domain solutions, while the "other birds" create non=2 neighborhood solutions.
    for i = 1:non
        neighbourSet(i) = neighbour(solution,new_shuttle_cood);
        NON = NON + 1;
    end
    neighbourSet = sortNeighbours(neighbourSet);
    number  = NON;
end

