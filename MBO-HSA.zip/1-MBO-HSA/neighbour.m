% Based on the current solution (bird), explore one of its neighboring solutions
function newSolution = neighbour(solution,new_shuttle_cood)
% Used to change the tasks for each shuttle vehicle;
% For tasks involving only one shuttle vehicle, replace the task within the task;
% If there are two or more vehicles, exchange the task sequence among the vehicles
for i  = 1:size(new_shuttle_cood,1)
    shuttle_num = size(new_shuttle_cood{i,1},1);  
    if i == 1
        new_shuttle_cood{i,2} = shuttle_num;
    else
        new_shuttle_cood{i,2} = new_shuttle_cood{i-1,2}+ shuttle_num;
    end
    
    
    if shuttle_num == 1   
       task_length = size(solution.task_sequence(shuttle_num).task,1); 
       a = (task_length/2);
       Random_number = 2*randperm(a);
       sequece = solution.task_sequence(shuttle_num).task;
       for j = 1:2:task_length
           task(j,:) = sequece(Random_number((j+1)/2)-1,:);
           task(j+1,:) = sequece(Random_number((j+1)/2),:);
       end
       solution.task_sequence(shuttle_num).task = task;
       
    else       %If the quantity of shuttle_num is 3, then find one to replace it between the tasks.
        if i == 1
            last_shuttle_num = 0;
        else
            last_shuttle_num = new_shuttle_cood{i-1,2};
        end
        minvalues = Inf;
        for j = (last_shuttle_num + 1):(shuttle_num + last_shuttle_num)      
            task_length = size(solution.task_sequence(j).task,1);
            if task_length < minvalues
                minvalues = task_length;
            end
        end
        rand_number = randi(minvalues);   %Randomly select a number from the task;
        if mod(rand_number,2) == 0
            number1 = rand_number -1;  %inbound task
            number2 = rand_number;     %outbound task
        else
            number1 = rand_number;
            number2 = rand_number+1;
        end
        rand1 = solution.task_sequence(last_shuttle_num + shuttle_num).task(number1,:);
        rand2 = solution.task_sequence(last_shuttle_num + shuttle_num).task(number2,:);
        for j = (last_shuttle_num+ shuttle_num) :-1:(last_shuttle_num+1)
            if j  == (last_shuttle_num + 1)
                solution.task_sequence(j).task(number1,:) = rand1;
                solution.task_sequence(j).task(number2,:) = rand2;
            else
                solution.task_sequence(j).task(number1,:) = solution.task_sequence(j-1).task(number1,:);
                solution.task_sequence(j).task(number2,:) = solution.task_sequence(j-1).task(number2,:);
             end
        end
    end
end
result = [];
for i = 1:3
    ab(1:size(new_shuttle_cood{i, 1},1),:) = new_shuttle_cood{i, 1};
    result = [result;ab];
    ab = [];
end
%Build shuttle_new
shuttle_new1 = struct();
task_sequence = struct();
for i  = 1:6
    shuttle_new1(i).sum = (i);
    shuttle_new1(i).task = solution.task_sequence(i).task;
    shuttle_new1(i).tasknumber = size(solution.task_sequence(i).task,1);
    shuttle_new1(i).original_cood = result(i,:);
    shuttle_new1(i).current_cood = 1;
    shuttle_new1(i).storage_cood = 0;
    shuttle_new1(i).retrieval_cood = 0;
    shuttle_new1(i).Current_running_status = 1;
    shuttle_new1(i).lift_status = 0;
    task_sequence(i).task = shuttle_new1(i).task;
end
maxtask = max([shuttle_new1.tasknumber]);
for i  =  1:6
    if shuttle_new1(i).tasknumber < maxtask
        shuttle_new1(i).task((shuttle_new1(i).tasknumber + 1):maxtask,:) = NaN;
    end
end
[shuttle_new,trans_shuttle,lift,t,T,task_sequence] = construct2(shuttle_new1,task_sequence);
newSolution.task_sequence = task_sequence;
newSolution.t = t;
newSolution.T = T;
end
