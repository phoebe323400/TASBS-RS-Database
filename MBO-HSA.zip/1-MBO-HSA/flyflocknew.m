function [NON, flock, leaderImproves] = flyflocknew(nob,non,olf,NON,flock,new_shuttle_cood)
    leader = flock(1);
    % Create the territory of the leading birds;
    % In the two cases, if there is only one vehicle in a certain area, then the task sequence will be changed.
    % If there are 2 to 3 vehicles in a certain area, then the tasks should be redistributed among the vehicles.
    [leaderNeighborSet, NON] = createNeighborSet(non, NON, leader,new_shuttle_cood);
    flock(1).neighborSet = leaderNeighborSet;
    for i = 2 : nob
        [flock(i).neighborSet, NON] = createNeighborSet(non-olf, NON, flock(i),new_shuttle_cood);
    end
    [bests(1), leaderNeighborSet] = getBestNeighbour(leaderNeighborSet);
    flock(1).neighborSet = leaderNeighborSet;  %Store the optimal solution of the leading bird in "bests".
    %
    
    for i = 2 :nob
        %Each neighborhood generates one solution; two neighborhoods generate two solutions.
        %The total number of solutions is 4. Remove the worst one.
        for j = 1:size(flock(i).neighborSet,2)
            neighbourSet(j) = neighbour(flock(i).neighborSet(j),new_shuttle_cood);  
        end
        flock(i).neighborSet = addNeighbour(neighbourSet, flock(i).neighborSet);
        flock(i).neighborSet(:,3:4) = [];%Select the two worse solutions among the four neighboring solutions and remove them first.
    end
        
    %Pass the territory of the flying bird to the 2nd and 3rd birds.
    for i = 1:2 * olf
        [best, leaderNeighborSet] = getBestNeighbour(leaderNeighborSet);
        if eq(1, mod(i,2))
            flock(2).neighborSet = addNeighbour(best, flock(2).neighborSet);
        else
            % If it is an even number, the bird on the right will inherit the number 3.
            flock(3).neighborSet = addNeighbour(best, flock(3).neighborSet);
        end
    end
    flock(1).neighborSet = leaderNeighborSet;
    % Handling of other birds
    for i = 2:nob - 2
        [bests(i), flock(i).neighborSet] = getBestNeighbour(flock(i).neighborSet);%"bests" stores the optimal solution for each bird.
        for j = 1:olf
            % Take out the i-th suboptimal bird, then add the suboptimal bird to the i + 2nd bird. The i-th bird will then have only the worst solution left.
            [best, flock(i).neighborSet] = getBestNeighbour(flock(i).neighborSet);
            flock(i+2).neighborSet = addNeighbour(best, flock(i+2).neighborSet);
        end
    end
    [bests(nob - 1), flock(nob - 1).neighborSet] = getBestNeighbour(flock(nob - 1).neighborSet);
    [bests(nob), flock(nob).neighborSet] = getBestNeighbour(flock(nob).neighborSet);
    
    
    if flock(1).T <= bests(1).T
        leaderImproves = false;
    else
        leaderImproves = true;
    end
    
    % SA
    for i = 1:nob
        if flock(i).T >= bests(i).T
            bests(i).neighborSet = [];
            flock(i) = bests(i);   
        else
            a = 0.98;
            tem = 6000;
            tem = a*tem;
            p = exp((bests(i).T-flock(i).T)/tem);
            if p > rand
                bests(i).neighborSet = [];
                flock(i) = bests(i);
            end
        end
    end
end
