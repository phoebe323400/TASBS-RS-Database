function [Carea,shuttle_i_task] = get_i_area(storages,iarea,goods,iter)
%storages 16x40 indicates one floor, and there are a total of 14 floors.
%"A_area" represents the coordinate range of Area A.
%Function purpose: Returns the updated regional storage data Carea and the corresponding warehousing task shuttle_i_task.
step1 = [];
for k = 1:iarea(6)
    Carea_i = storages(16*(k-1)+1:16*(k-1)+iarea(2),1:iarea(4)); 
    step1 = [step1;Carea_i];
end
%step = storages;
if iter == 1
    Carea =step1;
    task = [];
    for i = 1:0.5*length(goods)%ȡǰ��29���������
        if goods(i).cluster == 1
            shuttle_i_task = goods(i);
            task = [task;shuttle_i_task];
        end
    end 
elseif iter == 2  %Set all elements in region 1 to NaN;
   rows = [1:8,13:20,25:32,37:44,49:56,61:68,73:80,85:92];
    cols = 1:28;  %Retrieve the number of columns in region 1
    for i = 1:length(rows)
        for j = 1:length(cols)
            step1(rows(i),j).emp = NaN;
            step1(rows(i),j).fre = NaN;
            step1(rows(i),j).vol = NaN;
            step1(rows(i),j).wei = NaN;
        end
    end
elseif iter == 3
    rows = [1:12,17:28,33:44,49:60,65:76,81:92,97:108,113:124,129:140,145:156,161:172];
    cols = 1:34;
    for i = 1:length(rows)
        for j = 1:length(cols)
            step1(rows(i),j).emp = NaN;
            step1(rows(i),j).fre = NaN;
            step1(rows(i),j).vol = NaN;
            step1(rows(i),j).wei = NaN;
        end
    end
end
Carea = step1;
task = [];
for i = 1:0.5*length(goods)
    if goods(i).cluster == iter
        shuttle_i_task = goods(i);
        task = [task;shuttle_i_task];
    end
end
shuttle_i_task = task;
end