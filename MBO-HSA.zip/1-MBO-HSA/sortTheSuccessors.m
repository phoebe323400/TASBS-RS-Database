% Sort the flock of birds
function flock = sortTheSuccessors(nob, flock, sortAccToPerf)
    % Because the bird leader has been updated before, here the bird leader remains unchanged.
    leader = flock(1);
    % If an update is required
    if eq(2, sortAccToPerf)
        % Place the birds that come after the flying birds in the new lineup.
        for i = 2:nob
            p(i - 1) = flock(i);
        end
        % Sort the items
        [~, index] = sort([p.cost]);
        p = p(index(:));
        % Combine the flocks of birds together
        flock(1) = leader;
        for i = 2:nob
            flock(i) = p(i - 1);
        end
    end
end