function [flock, leftSide] = newreplaceLeaderWithSuccessor(nob, flock, leftSide)
a1 = randi([3,14]);
a2 = randi([15,29]);
b1 = randi([30,44]);
b2 = randi([45,51]);  
    if leftSide
        nf(1) = flock(1);
        flock(a1) = flock(a2);
        flock(a2) = flock(b1);
        flock(b1) = flock(b2);
        flock(b2) = nf(1);
        nf(1) =  flock(2);
        for i = 2:nob - 2
            if eq(0, mod(i,2))
                nf(i) = flock(i + 2);
            else
                nf(i) = flock(i);
            end
        end
        nf(nob - 1) = flock(1);
        nf(nob) = flock(nob);
    else
        nf(1) = flock(1);
        flock(a1) = flock(a2);
        flock(a2) = flock(b1);
        flock(b1) = flock(b2);
        flock(b2) = nf(1);
        nf(1) = flock(3);

        for i = 2:nob - 1
            if eq(0, mod(i,2))
                nf(i) = flock(i);
            else
                nf(i) = flock(i + 2);
            end
        end

        nf(nob) = flock(1);

    flock = nf;

    leftSide = ~leftSide;
end