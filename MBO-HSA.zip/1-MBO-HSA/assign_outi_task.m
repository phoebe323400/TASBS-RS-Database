function [retrieval_task,C_area,task] = assign_outi_task(location_in,C_area,iter)
%First, determine whether there is an appropriate outbound storage location among the shelves in the same row.
%Secondly, check again to see if there are any suitable storage locations for outbound goods within the same layer.
l_width = 0.5;
location = zeros(size(location_in,1),5);
retrieval_task = zeros(size(location_in,1),5);
for i = 1:size(location_in,1)
    min_dis = inf;
    for j = 1 : size(C_area,2)  %Obtain the number of columns of the x_area
        if C_area(location_in(i,1),j).emp == 1 && j~= location_in(i,2)  %First, identify the storage locations within the same floor and the same alleyway.
            dis = abs((j-location_in(i,2)))*l_width;
            if min_dis > dis
                min_dis = dis;  %
                location = [location_in(i,1),j];
            end
        end
    end
    retrieval_task(i,1:2) = location;
    if iter == 1
        retrieval_task(i,3:5) = [mod(retrieval_task(i,1),8),retrieval_task(i,2),ceil(retrieval_task(i,1)/8)];
        if mod(retrieval_task(i,1),8) == 0
            retrieval_task(i,3) = mod((retrieval_task(i, 1)-1),8) +1;
        end
    elseif iter ==  2
        retrieval_task(i,3:5) = [mod(retrieval_task(i,1),12),retrieval_task(i,2),ceil(retrieval_task(i,1)/12)];
        if mod(retrieval_task(i,1),12) == 0
            retrieval_task(i,3) = mod((retrieval_task(i, 1)-1),12) +1;
        end
    elseif iter == 3
        retrieval_task(i,3:5) = [mod(retrieval_task(i,1),16),retrieval_task(i,2),ceil(retrieval_task(i,1)/16)];
        if mod(retrieval_task(i,1),16) == 0
            retrieval_task(i,3) = mod((retrieval_task(i, 1)-1),16) +1;
        end
    else
    end
    C_area(location(1),location(2)).emp = 0;  %This storage location is marked as an empty storage area.
end

%
for i = 1:size(location_in,1)-1
    if retrieval_task(i,1) == retrieval_task(i+1,1)         
        for j = 1 : size(C_area,2)
            min_dis = inf;
            if mod(mod(location_in(i+1,1),16),2)==1        %If the roadway is an odd-numbered roadway
                if C_area(location_in(i+1,1)+1,j).emp == 1 %If the lane is odd, then we need to look for an even-numbered lane.
                    dis = abs(j-location_in(i+1,2))*l_width;
                    if min_dis > dis
                        min_dis = dis;  %
                        location = [location_in(i+1,1)+1,j];
                    else
                    end
                else
                end
            else
                if C_area(location_in(i,1)-1,j).emp == 1
                    dis = abs(j-location_in(i,2))*l_width;
                    if min_dis > dis
                        min_dis = dis;  %
                        location = [location_in(i,1),j];
                    else
                    end
                else
                end
            end
            retrieval_task(i+1,1:2) = location;
            retrieval_task(i+1,3:5) = [mod(retrieval_task(i+1,1),16),retrieval_task(i+1,2),ceil(retrieval_task(i+1,1)/14)];
            C_area(location(1),location(2)).emp = 0;
        end
    else
    end
end
task = [];
for i = 1:2:2*size(location_in,1)
    task(i:i+1,:)= [location_in((i+1)/2,3:5);retrieval_task((i+1)/2,3:5)];
end
end