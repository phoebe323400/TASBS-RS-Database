clc;
clear all
rng(0);
nob = 51;     %  n Population size (can be changed)
non = 3;      %  k Neighborhood number k>=2x+1
olf = 1;      %  x Share the number of domain solutions with the solutions of the next domain area
nof = 20;     %  m Number of tours
noi = nob.^3; %  K Number of iterations
initialFlockSortedAccToPerf=1; 
NON = 0;      %  
leaderExchangeMode = 4;   %The method of exchanging with flying birds
 % 1 means exchange the leader with the successor��
 % 2 means exchanging the leader with the best   
 % 3 means exchanging if its performance is gets worse  
 % 4 To improve the method of leading bird exchange;
leftSide = true;  
sortAccToPerf = 1; 
% 1 means the flock permutation stays the same 
% 2 means sorting them according performance
tic;
num_items = 40;  %Number of tasks,40/60/80/100/120
v_shuttle = 2;
a_shuttle = 1.5;
v_lift = 3;
a_lift =  1.5;
v_tras_shuttle = 2;
a_tras_shuttle = 1.5;
shuttles = [v_shuttle a_shuttle;v_shuttle a_shuttle;v_shuttle a_shuttle;v_shuttle a_shuttle;v_shuttle a_shuttle;v_shuttle a_shuttle;];
data_storage.emp = xlsread('storage location information_1.xlsx',1,'A4:AN227');%Storage location status
data_storage.fre = xlsread('storage location information_2.xlsx',1,'A4:AN227');%Storage location frequency information,0~30
data_storage.vol = xlsread('storage location information_3.xlsx',1,'A4:AN227');%Storage location volume information ,0~10
data_storage.wei = xlsread('storage location information_4.xlsx',1,'A4:AN227');%Storage location weight information,0~25
data_goods = [xlsread('storage task information1.xlsx',1,'A1:D20');xlsread('storage location information1.xlsx',1,'F1:I20')];  
[data_goods] = goodscluster(data_goods);   %Task clustering
storages = struct();
for i =  1:224
    for j = 1:40
        storages(i,j).ID  = [i,j];
        storages(i,j).emp = data_storage.emp(i,j);
        storages(i,j).fre = data_storage.fre(i,j);
        storages(i,j).vol = data_storage.vol(i,j);
        storages(i,j).wei = data_storage.wei(i,j);
    end
end 
goods = struct();
for i = 1:num_items
    goods(i).ID = i;                      
    goods(i).Frequency = data_goods(i,2); 
    goods(i).Volume = data_goods(i,3);    
    goods(i).weight = data_goods(i,4);    
    goods(i).cluster = data_goods(i,5);
    goods(i).x = 0;
    goods(i).y = 0;
    goods(i).z = 0; 
end
storage_and_retrieval = [goods.cluster];
count_1 = sum(storage_and_retrieval(1:(num_items/2)) == 1);  %The number of tasks in Area A
count_2 = sum(storage_and_retrieval(1:(num_items/2)) == 2);  %The number of tasks in Area B
count_3 = sum(storage_and_retrieval(1:(num_items/2)) == 3);  %The number of tasks in Area C


shuttle_NumA = round(count_1/(num_items/2)*length(shuttles));% The number of shuttle vehicles corresponding to the demand in Area A
shuttle_NumB = round(count_2/(num_items/2)*length(shuttles));% The number of shuttle vehicles corresponding to the demand in Area B
shuttle_NumC = round(count_3/(num_items/2)*length(shuttles));% The number of shuttle vehicles corresponding to the demand in Area C
[Area] = rackarea(data_storage);

% Assign the initial coordinates for the shuttle vehicle
for i = 1 : size((Area),1)  
  shuttle_cood  = gen_cood_shuttles(Area(i,:),shuttle_NumA,shuttle_NumB,shuttle_NumC,i);
  new_shuttle_cood{i,:} = shuttle_cood;  
end
 
data = struct();
%Carea:Partitioned area
%shuttle_c_task��
for i = 1: size(Area,1)
    [Carea,shuttle_x_task] = get_i_area(storages,Area(i,:),goods,i);
    [storage_task,Carea,goods] = calculate_vol_i(Carea,shuttle_x_task,i,data,goods);   %Match the most suitable three-dimensional coordinates for the inbound task
    [retrieval_task,Carea,task] = assign_outi_task(storage_task,Carea,i);              %Match the outbound tasks with the inbound tasks
    data(i).shuttle_x_task = shuttle_x_task;
    data(i).Carea = Carea;
    data(i).storage_task = storage_task;      %Inbound task coordinates;
    data(i).retrieval_task = retrieval_task;  %Outbound task coordinates;
    data(i).task = task;
end

tic;
flock = struct();
[shuttle_new,trans_shuttle,lift,t,T,task_sequence] = construct(data,new_shuttle_cood); %The main function for calculating travel time
flock.task_sequence = task_sequence;
flock.t = t;
flock.T = T;
for i = 1:nob-1
    data = newdata(data);
    [shuttle_new,trans_shuttle,lift,t,T,task_sequence] = construct(data,new_shuttle_cood);  
    flock(i+1).task_sequence = task_sequence;  %"Flock" represents the specific content of a population.
    flock(i+1).t = t;
    flock(i+1).T = T;
end

count = 0;
result_for = [];
result = [];
while NON < 102001
    for i = 1:nof
         [NON, flock, leaderImproves] = flyflocknew(nob,non,olf,NON,flock,new_shuttle_cood);  % Improvement 1 and 2
         result_for = [result_for,flock(1).T];
    end
    min_value = min(result_for);
    result = [result;min_value];
    [flock, leftSide] = replaceLeader(nob, flock, leaderImproves, leaderExchangeMode, leftSide);  %Improvement 3
    flock = sortTheSuccessors(nob, flock, sortAccToPerf);  
    leaderImproves = true;
    count=count+1;
end
[solution] = writeResults(flock,goods,count,result);