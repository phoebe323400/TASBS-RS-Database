function [data]= newdata(data)
for i = 1:length(data)
    a = size(data(i).storage_task,1);  
    Random_number = randperm(a); 
    data(i).storage_task = data(i).storage_task(Random_number,:);
    data(i).retrieval_task = data(i).retrieval_task(Random_number,:);
    for j = 1:2:2*size(data(i).storage_task,1)
        task(j:j+1,:)= [data(i).storage_task(((j+1)/2),3:5);data(i).retrieval_task(((j+1)/2),3:5)];
    end
    data(i).task =task;
    task = [];
end
end