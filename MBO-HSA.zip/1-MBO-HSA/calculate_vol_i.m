function [location_C,Carea,goods] = calculate_vol_i(Carea,shuttle_x_task,iter,data,goods)
% Each incoming task is screened to determine if it is ranked in the first position.
length_task = length(shuttle_x_task);
%Subfunction: Match the most suitable three-dimensional coordinates for the incoming task
set = struct();
for j = 1:size(Carea,1)  %132
    for k = 1:size(Carea,2)  %34
        if ~(isnan(Carea(j,k).emp) ||Carea(j,k).emp == 1) %When the value of Barea(j,k).emp is neither NaN nor 1, execute the corresponding code.
            for l = 1:length_task
                if shuttle_x_task(l).Volume > Carea(j,k).vol
                    set(j,k).vol(:,l) = 0;
                    if shuttle_x_task(l).weight > Carea(j,k).wei
                        set(j,k).wei(:,l) = 0;
                    elseif shuttle_x_task(l).weight == Carea(j,k).wei
                        set(j,k).wei(:,l) = 1;
                    elseif shuttle_x_task(l).weight < Carea(j,k).wei
                        set(j,k).wei(:,l) = Carea(j,k).wei/shuttle_x_task(l).weight;
                    end
                elseif shuttle_x_task(l).Volume == Carea(j,k).vol
                    set(j,k).vol(:,l) = 1;
                    if shuttle_x_task(l).weight > Carea(j,k).wei
                        set(j,k).wei(:,l) = 0;
                    elseif shuttle_x_task(l).weight == Carea(j,k).wei
                        set(j,k).wei(:,l) = 1;
                    elseif shuttle_x_task(l).weight < Carea(j,k).wei
                        set(j,k).wei(:,l) = Carea(j,k).wei/shuttle_x_task(l).weight;
                    end
                elseif shuttle_x_task(l).Volume < Carea(j,k).vol
                    set(j,k).vol(:,l) = Carea(j,k).vol/shuttle_x_task(l).Volume;
                    if shuttle_x_task(l).weight > Carea(j,k).wei
                        set(j,k).wei(:,l) = 0;
                    elseif shuttle_x_task(l).weight == Carea(j,k).wei
                        set(j,k).wei(:,l) = 1;
                    elseif shuttle_x_task(l).weight < Carea(j,k).wei
                        set(j,k).wei(:,l) = Carea(j,k).wei/shuttle_x_task(l).weight;
                    end
                end
            end
        else
            for l = 1:length(shuttle_x_task)
                set(j,k).vol(:,l) = NaN;
                set(j,k).wei(:,l) = NaN;
            end
        end
    end
end
% Make judgments for all positions and determine which position is the best.
% Obtain the value of vol*wei and sort it in descending order;
for i = 1: size(set,1)
    for j = 1: size(set,2)
        if all(isnan(set(i,j).vol))
            set(i,j).all = NaN;
            set(i,j).a = NaN;
            set(i,j).b = NaN;
        else  %The "set(i,j).all" contains the corresponding quantity of storage tasks.
            set(i,j).all = set(i,j).vol.* set(i,j).wei;
            step = set(i,j).all;
            [a,b] = sort(step,'descend');
            set(i,j).a  = a;
            set(i,j).b = b;   %b
        end
    end
end
%"Set" is a structure that calculates "vol", "wei", "vol * wei", as well as the ranking value and index value.

location_C = zeros(length_task,6);
for i = 1:length_task
    maxvalue = 0;
    maxvalue_j = 0;
    maxvalue_k = 0;
    for j = 1:size(set,1)
        for k = 1:size(set,2)
            value = set(j,k).all;  %all = vol * wei
            if any(isnan(value)) || all(value == 0)
            else
                for m = 1:length_task
                    index = find(set(j,k).b == i);
                    value1 = set(j,k).a(index);
                    if set(j,k).b(m) == i %If the first choice at position (j, k) can be assigned to task i in the library
                        if maxvalue < value1
                            maxvalue = value1;
                            maxvalue_j = j;  %Find the corresponding index of the vertical coordinate
                            maxvalue_k = k;
                        end
                    end
                end
            end
        end
    end
    Carea(maxvalue_j, maxvalue_k).emp = 1;
    set(maxvalue_j, maxvalue_k).vol = NaN;
    set(maxvalue_j, maxvalue_k).wei = NaN;
    set(maxvalue_j, maxvalue_k).all = NaN;
    set(maxvalue_j, maxvalue_k).a = NaN;
    set(maxvalue_j, maxvalue_k).b = NaN;
    location_C(i, 1:2) = [maxvalue_j, maxvalue_k]; 
    if iter == 1
        location_C(i, 3:5) = [mod(location_C(i, 1), 8), location_C(i, 2), ceil(location_C(i, 1)/8)];
        location_C(i, 6) = shuttle_x_task(i).ID;
        if mod(location_C(i, 1), 8) == 0
            location_C(i,3) = mod((location_C(i, 1)-1), 8) +1;
        end
        fprintf('The %dth run, the maximum value in the array is: %f, the stored inbound task is the %dth one, and the coordinates of the shelf are����%d��%d��%d��\n', ...
            i, maxvalue, shuttle_x_task(i).ID, location_C(i, 3), location_C(i, 4), location_C(i, 5));
    elseif iter == 2
        location_C(i, 3:5) = [mod(location_C(i, 1),12), location_C(i, 2), ceil(location_C(i, 1)/12)];
        location_C(i, 6) = shuttle_x_task(i).ID;
        if mod(location_C(i, 1), 12) == 0
            location_C(i,3) = mod((location_C(i, 1)-1),12) +1;
        end
        fprintf('The %dth run, the maximum value in the array is: %f, the stored inbound task is the %dth one, and the coordinates of the shelf are����%d��%d��%d��\n', ...
            i + size(data(1).storage_task, 1), maxvalue, shuttle_x_task(i).ID, location_C(i, 3), location_C(i, 4), location_C(i, 5));
    elseif iter == 3
        location_C(i, 3:5) = [mod(location_C(i, 1), 16), location_C(i, 2), ceil(location_C(i, 1)/16)];
        location_C(i, 6) = shuttle_x_task(i).ID;
        if mod(location_C(i, 1), 16) == 0
            location_C(i,3) = mod((location_C(i, 1)-1), 16) +1;
        end
        fprintf('The %dth run, the maximum value in the array is: %f, the stored inbound task is the %dth one, and the coordinates of the shelf are����%d��%d��%d��\n', ...
            i + (size(data(1).storage_task, 1) + size(data(2).storage_task, 1)), maxvalue, shuttle_x_task(i).ID, location_C(i, 3), ...
            location_C(i, 4), location_C(i, 5));
    end
end
for i = 1:size(location_C,1)
    index = location_C(i,6);
    goods(index).x = location_C(i,3);
    goods(index).y = location_C(i,4);
    goods(index).z = location_C(i,5);
end
end