
function neighbourSet = sortNeighbours(neighbourSet)

    [~, index] = sort([neighbourSet.T]);

    neighbourSet = neighbourSet(index(:));
end

