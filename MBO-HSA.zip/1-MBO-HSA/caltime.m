function t = caltime(distance,v,a,l_length)
if distance*l_length  < (v.^2)/a
    t = 2*sqrt(distance*l_length/a);
else
    t = distance*l_length/v + v/a;
end
t = round(t,2);
end