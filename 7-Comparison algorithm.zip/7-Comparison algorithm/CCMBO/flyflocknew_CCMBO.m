function [NON, flock, leaderImproves] = flyflocknew_CCMBO(nob, non, olf, NON, flock, new_shuttle_cood)
% =========================================================================
% Improved core flight iteration function of MBO
% Improvement 1: V-formation flight phase ���� Encoded segment crossover sharing 
%                (Solves the problem of complete discard of follower information)
% Improvement 2: Adjustment phase ���� Dispersed formation dynamic collaboration 
%                (Solves the problems of fixed population formation and single collaboration topology)
% Improvement 3: Competition phase ���� Competition mechanism for leader bird selection 
%                (Solves the problem of inefficient rotation of leader birds)
% =========================================================================

leader = flock(1);

%% ================= Improvement 1: V-formation Flight Phase (Encoded Segment Crossover Sharing) =================
% Generate neighborhood solutions for the leader bird
[leaderNeighborSet, NON] = createNeighborSet(non, NON, leader, new_shuttle_cood);
flock(1).neighborSet = leaderNeighborSet;

% Generate neighborhood solutions for follower birds
for i = 2 : nob
    [flock(i).neighborSet, NON] = createNeighborSet(non - olf, NON, flock(i), new_shuttle_cood);
end

% Get the optimal neighborhood solution of the leader bird
[bests(1), leaderNeighborSet] = getBestNeighbour(leaderNeighborSet);
flock(1).neighborSet = leaderNeighborSet;

% ---- Core of Improvement 1: Followers share encoded segments with front birds through crossover operation ----
% Instead of directly replacing followers' neighborhood solutions, generate candidate solutions via crossover function
for i = 2 : nob
    % Determine the front bird (leader bird or preceding follower)
    if i == 2 || i == 3
        front_bird = flock(1);  % Front birds of the first left/right followers are the leader bird
    else
        if mod(i, 2) == 0
            front_bird = flock(i - 2);  % Left bird chain
        else
            front_bird = flock(i - 2);  % Right bird chain
        end
    end

    % For each neighborhood solution of the current bird, perform crossover with the front bird to generate candidate solutions
    crossover_candidates = [];
    for j = 1 : size(flock(i).neighborSet, 2)
        % Crossover operation: F_cross(k, x_i, x_{i+1})
        cross_solution = crossoverSolution(flock(i).neighborSet(j), front_bird, new_shuttle_cood);
        crossover_candidates = [crossover_candidates, cross_solution];
    end

    % Merge crossover candidates with original neighborhood solutions, select the optimal non-olf ones to retain
    all_candidates = [flock(i).neighborSet, crossover_candidates];
    % Sort by fitness and retain the optimal ones
    T_values = [all_candidates.T];
    [~, sort_idx] = sort(T_values, 'ascend');
    keep_num = min(non - olf, length(sort_idx));
    flock(i).neighborSet = all_candidates(sort_idx(1:keep_num));
end

% Pass leader bird's neighborhood to the first left/right followers (via crossover instead of direct replacement)
for i = 1 : 2 * olf
    [best, leaderNeighborSet] = getBestNeighbour(leaderNeighborSet);
    if mod(i, 2) == 1
        % Left follower (No. 2): crossover sharing
        cross_sol = crossoverSolution(best, flock(2), new_shuttle_cood);
        flock(2).neighborSet = addNeighbour(cross_sol, flock(2).neighborSet);
    else
        % Right follower (No. 3): crossover sharing
        cross_sol = crossoverSolution(best, flock(3), new_shuttle_cood);
        flock(3).neighborSet = addNeighbour(cross_sol, flock(3).neighborSet);
    end
end
flock(1).neighborSet = leaderNeighborSet;

% Neighborhood passing for other birds (also using crossover sharing)
for i = 2 : nob - 2
    [bests(i), flock(i).neighborSet] = getBestNeighbour(flock(i).neighborSet);
    for j = 1 : olf
        [best, flock(i).neighborSet] = getBestNeighbour(flock(i).neighborSet);
        % Pass to the (i+2)-th bird after crossover
        cross_sol = crossoverSolution(best, flock(i + 2), new_shuttle_cood);
        flock(i + 2).neighborSet = addNeighbour(cross_sol, flock(i + 2).neighborSet);
    end
end
[bests(nob - 1), flock(nob - 1).neighborSet] = getBestNeighbour(flock(nob - 1).neighborSet);
[bests(nob), flock(nob).neighborSet] = getBestNeighbour(flock(nob).neighborSet);

% Determine if the leader bird is improved
if flock(1).T <= bests(1).T
    leaderImproves = false;
else
    leaderImproves = true;
end

% Update flock using simulated annealing probabilistic acceptance mechanism
for i = 1 : nob
    if flock(i).T >= bests(i).T
        bests(i).neighborSet = [];
        flock(i) = bests(i);
    else
        a = 0.98;
        tem = 6000;
        tem = a * tem;
        p = exp((bests(i).T - flock(i).T) / tem);
        if p > rand
            bests(i).neighborSet = [];
            flock(i) = bests(i);
        end
    end
end

%% ================= Improvement 2: Adjustment Phase (Dispersed Formation Dynamic Collaboration) =================
% Simulate "dispersed formation" when birds adjust speed, introduce dynamic collaboration relationships
% Each bird randomly selects another bird in the population as a "temporary following target" 
% and generates new solutions through encoded segment sharing
K_a = 3;  % Number of rounds in adjustment phase (adjustable as needed)
for ka = 1 : K_a
    for i = 1 : nob
        % Randomly select another bird as temporary following target: j = randint(1, n)
        j = randi(nob);
        while j == i
            j = randi(nob);  % Ensure not selecting itself
        end
        % Generate new solution through encoded segment sharing: x_i = F_CS(x_j, x_i)
        new_solution = codingSegmentShare(flock(j), flock(i), new_shuttle_cood);
        % Replace current bird if new solution is better
        if new_solution.T < flock(i).T
            new_solution.neighborSet = [];
            flock(i) = new_solution;
        else
            % Also use simulated annealing probabilistic acceptance
            a = 0.98;
            tem = 6000 * (0.98 ^ ka);  % Temperature decreases with rounds
            p = exp((new_solution.T - flock(i).T) / tem);
            if p > rand
                new_solution.neighborSet = [];
                flock(i) = new_solution;
            end
        end
    end
end
end

%% ===================== Auxiliary Functions =====================

function cross_solution = crossoverSolution(solution_a, solution_b, new_shuttle_cood)
% Crossover operation function F_cross(k, x_i, x_{i+1})
% Perform crossover on encoded segments of solution_a and solution_b to generate candidate solution
% solution_a: Neighborhood solution or high-quality solution of front bird
% solution_b: Current bird (follower)
% Return crossovered candidate solution

cross_solution = solution_a;  % Based on solution_a

task_seq_a = solution_a.task_sequence;
task_seq_b = solution_b.task_sequence;

num_shuttles = size(task_seq_a, 2);

% Randomly select crossover points: exchange task sequences of partial shuttles
num_cross = max(1, randi(ceil(num_shuttles / 2)));  % Number of shuttles for crossover
cross_indices = randperm(num_shuttles, num_cross);   % Randomly select which shuttles participate in crossover

new_task_seq = task_seq_a;
for idx = 1 : length(cross_indices)
    shuttle_idx = cross_indices(idx);
    task_a = task_seq_a(shuttle_idx).task;
    task_b = task_seq_b(shuttle_idx).task;

    % Get valid task rows (exclude NaN rows)
    valid_a = sum(~any(isnan(task_a), 2));
    valid_b = sum(~any(isnan(task_b), 2));
    min_valid = min(valid_a, valid_b);

    if min_valid >= 4  % At least 2 pairs of inbound/outbound tasks for crossover
        % Select crossover interval (must be even, as inbound/outbound are paired)
        cross_start = 2 * randi(floor(min_valid / 2) - 1) - 1;  % Odd start point
        cross_end = min(cross_start + 2 * randi(max(1, floor((min_valid - cross_start) / 2))), min_valid);
        if mod(cross_end - cross_start + 1, 2) ~= 0
            cross_end = cross_end - 1;
        end
        if cross_end > cross_start
            % Insert segment from B into corresponding position in A
            new_task_seq(shuttle_idx).task(cross_start:cross_end, :) = ...
                task_b(cross_start:cross_end, :);
        end
    end
end

cross_solution.task_sequence = new_task_seq;
% Recalculate fitness (Makespan)
[~, ~, ~, t_new, T_new, ~] = construct_from_sequence(cross_solution, new_shuttle_cood);
cross_solution.t = t_new;
cross_solution.T = T_new;
end


function new_solution = codingSegmentShare(bird_j, bird_i, new_shuttle_cood)
% Encoded segment sharing function F_CS(x_j, x_i)
% Randomly select encoded segments from bird_j and integrate into bird_i to generate new solution
% Used for dynamic collaboration in adjustment phase

new_solution = bird_i;  % Based on current bird

task_seq_i = bird_i.task_sequence;
task_seq_j = bird_j.task_sequence;

num_shuttles = size(task_seq_i, 2);

% Randomly select 1-2 shuttles for encoded segment sharing
num_share = randi(min(2, num_shuttles));
share_indices = randperm(num_shuttles, num_share);

new_task_seq = task_seq_i;
for idx = 1 : length(share_indices)
    shuttle_idx = share_indices(idx);
    task_i = task_seq_i(shuttle_idx).task;
    task_j = task_seq_j(shuttle_idx).task;

    valid_i = sum(~any(isnan(task_i), 2));
    valid_j = sum(~any(isnan(task_j), 2));
    min_valid = min(valid_i, valid_j);

    if min_valid >= 4
        % Randomly select a segment (paired)
        pair_count = floor(min_valid / 2);
        share_pair = randi(pair_count);
        start_row = 2 * share_pair - 1;
        end_row = 2 * share_pair;

        % Copy segment from bird_j to bird_i
        new_task_seq(shuttle_idx).task(start_row:end_row, :) = ...
            task_j(start_row:end_row, :);
    end
end

new_solution.task_sequence = new_task_seq;
% Recalculate fitness
[~, ~, ~, t_new, T_new, ~] = construct_from_sequence(new_solution, new_shuttle_cood);
new_solution.t = t_new;
new_solution.T = T_new;
end