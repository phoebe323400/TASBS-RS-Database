% Replace leader bird
function [flock, leftSide] = replaceLeader_CCMBO(nob, flock, leaderImproves, leaderExchangeMode, leftSide)
% =========================================================================
% Improvement 3: Competition Phase ���� Competition mechanism for leader bird selection
% Solves the problem of "inefficient rotation of leader birds and difficulty for elite individuals to take the lead"
%
% Defect of basic MBO: Leader birds rotate in a fixed order (front followers take turns to be promoted), 
%   elite individuals in the middle of the queue have to wait multiple rounds to become leader birds, 
%   resulting in low optimization efficiency.
%
% Improvement content:
%   (1) At the start of each iteration, sort all birds by objective function value (Makespan) to form a "quality gradient"
%   (2) Randomly exchange positions of some birds (avoid fixed formation after sorting) to construct a new V-formation
%   (3) High-quality individuals after sorting prioritize to become leader birds or front-row followers, 
%       shortening the waiting time for elite individuals to take the lead
%
% Mathematical description: �� = F_dis(F_sort(X), {rand_int,int(0.3n)(n)})
% =========================================================================

%% Step 1: F_sort(X) ���� Sort all birds by Makespan to form a quality gradient
T_values = zeros(1, nob);
for i = 1 : nob
    T_values(i) = flock(i).T;
end
[~, sort_indices] = sort(T_values, 'ascend');  % Sort by Makespan in ascending order (smaller is better)

sorted_flock = flock(sort_indices);  % Sorted flock of birds

%% Step 2: F_dis() ���� Random perturbation to avoid completely fixed formation after sorting
% Perturbation range: Random position exchange among the top 30% of birds
% {rand_int,int(0.3n)(n)} indicates random exchange within the first 0.3n positions

perturb_range = max(2, round(0.3 * nob));  % Perturbation range: top 30% of birds
num_swaps = max(1, round(perturb_range / 3));  % Number of swaps

for s = 1 : num_swaps
    % Randomly select two positions within the first perturb_range for exchange 
    % (but with high probability of keeping the 1st place unchanged)
    idx1 = randi(perturb_range);
    idx2 = randi(perturb_range);
    while idx2 == idx1
        idx2 = randi(perturb_range);
    end

    % If involving the 1st place (optimal solution), keep it unchanged with 50% probability
    if (idx1 == 1 || idx2 == 1)
        if rand > 0.5
            continue;  % Skip with 50% probability to protect the leader position of the optimal solution
        end
    end

    % Exchange positions
    temp = sorted_flock(idx1);
    sorted_flock(idx1) = sorted_flock(idx2);
    sorted_flock(idx2) = temp;
end

%% Step 3: Construct new V-formation
% The sorted + perturbed flock is directly used as the new V-formation
% The 1st position is the leader bird, and the rest are followers in order

flock = sorted_flock;

% Clear the neighborhood set of all birds (prepare for the next iteration)
for i = 1 : nob
    if isfield(flock(i), 'neighborSet')
        flock(i).neighborSet = [];
    end
end

% Alternate left/right sides (maintain interface compatibility)
leftSide = ~leftSide;
end