function [NON, flock, leaderImproves, tabu_list] = flyflocknew_EMBO(nob, non, olf, NON, flock, new_shuttle_cood, tabu_list)
% =========================================================================
% Improved core flight iteration function of EMBO (5 improvements)
% Improvement 1: Hybrid Neighborhood Search (Swap + Forward Insertion)
% Improvement 2: Tabu List to avoid repeated searches
% Improvement 3: Restart Mechanism to solve population aging
% Improvement 4: STH Intensification Mechanism to enhance local search precision
% Improvement 5: Age-based pseudo-random leader bird selection (implemented in replaceLeader_v2)
% =========================================================================

leader = flock(1);

%% ====== Improvement 3: Restart Mechanism ���� Check and replace aged individuals ======
% Replace solutions with age exceeding threshold (age_threshold=100) with random new solutions
age_threshold = 100;
for i = 1 : nob
    if ~isfield(flock(i), 'age') || isempty(flock(i).age)
        flock(i).age = 0;
    end
    if flock(i).age > age_threshold
        % Replace aged individual with random new solution
        flock(i) = generateRandomSolution(flock(i), new_shuttle_cood);
        flock(i).age = 0;  % Reset age
    end
end

%% ====== Improvement 4: STH Intensification Mechanism ���� Perform STH intensification on each solution before generating neighborhoods ======
for i = 1 : nob
    flock(i) = STH_intensification(flock(i), new_shuttle_cood);
end

%% ====== Generate neighborhood solutions for leader bird (Improvement 1 + Improvement 2: Hybrid Neighborhood + Tabu List check) ======
[leaderNeighborSet, NON, tabu_list] = createMixedNeighborSet(non, NON, leader, new_shuttle_cood, tabu_list);
flock(1).neighborSet = leaderNeighborSet;

% Generate neighborhood solutions for follower birds
for i = 2 : nob
    [flock(i).neighborSet, NON, tabu_list] = createMixedNeighborSet(non - olf, NON, flock(i), new_shuttle_cood, tabu_list);
end

% Get the optimal neighborhood solution of the leader bird
[bests(1), leaderNeighborSet] = getBestNeighbour(leaderNeighborSet);
flock(1).neighborSet = leaderNeighborSet;

%% ====== Pass leader bird's neighborhood to the first left/right followers ======
for i = 1 : 2 * olf
    [best, leaderNeighborSet] = getBestNeighbour(leaderNeighborSet);
    if eq(1, mod(i, 2))
        flock(2).neighborSet = addNeighbour(best, flock(2).neighborSet);
    else
        flock(3).neighborSet = addNeighbour(best, flock(3).neighborSet);
    end
end
flock(1).neighborSet = leaderNeighborSet;

%% ====== Neighborhood passing for other birds ======
for i = 2 : nob - 2
    [bests(i), flock(i).neighborSet] = getBestNeighbour(flock(i).neighborSet);
    for j = 1 : olf
        [best, flock(i).neighborSet] = getBestNeighbour(flock(i).neighborSet);
        flock(i + 2).neighborSet = addNeighbour(best, flock(i + 2).neighborSet);
    end
end
[bests(nob - 1), flock(nob - 1).neighborSet] = getBestNeighbour(flock(nob - 1).neighborSet);
[bests(nob), flock(nob).neighborSet] = getBestNeighbour(flock(nob).neighborSet);

% Determine if the leader bird is improved
if flock(1).T <= bests(1).T
    leaderImproves = false;
else
    leaderImproves = true;
end

%% ====== Update flock (with simulated annealing probabilistic acceptance) + Improvement 3: Age update ======
for i = 1 : nob
    if flock(i).T >= bests(i).T
        % Replaced by better solution, reset age to 0
        bests(i).neighborSet = [];
        bests(i).age = 0;  % Newly generated solution has age 0
        flock(i) = bests(i);
    else
        a = 0.98;
        tem = 6000;
        tem = a * tem;
        p = exp((bests(i).T - flock(i).T) / tem);
        if p > rand
            bests(i).neighborSet = [];
            bests(i).age = 0;
            flock(i) = bests(i);
        else
            % Not replaced, age increases by 1
            flock(i).age = flock(i).age + 1;
        end
    end
end
end

%% =====================================================================
%                        Improvement 1: Hybrid Neighborhood Search
%  Design hybrid neighborhood of "Swap + Forward Insertion"
% =====================================================================
function [neighborSet, NON, tabu_list] = createMixedNeighborSet(k, NON, bird, new_shuttle_cood, tabu_list)
% Generate k hybrid neighborhood solutions, randomly select Swap or Forward Insertion for each neighborhood
% Combined with Improvement 2 (Tabu List) check to avoid repeated searches
neighborSet = [];
attempts = 0;
max_attempts = k * 5;  % Prevent infinite loop

while size(neighborSet, 2) < k && attempts < max_attempts
    attempts = attempts + 1;

    % Randomly select neighborhood type: 0.5 probability for Swap, 0.5 for Forward Insertion
    if rand < 0.5
        [new_sol, op_pair] = swapNeighbor(bird, new_shuttle_cood);
    else
        [new_sol, op_pair] = forwardInsertionNeighbor(bird, new_shuttle_cood);
    end

    % ====== Improvement 2: Tabu List check ======
    if ~isTabu(op_pair, tabu_list)
        neighborSet = [neighborSet, new_sol];
        NON = NON + 1;
        % Add operation pair to tabu list
        tabu_list = addToTabuList(op_pair, tabu_list);
    end
end

% If insufficient neighborhoods generated due to tabu restrictions, relax tabu constraints to make up
while size(neighborSet, 2) < k
    if rand < 0.5
        [new_sol, ~] = swapNeighbor(bird, new_shuttle_cood);
    else
        [new_sol, ~] = forwardInsertionNeighbor(bird, new_shuttle_cood);
    end
    neighborSet = [neighborSet, new_sol];
    NON = NON + 1;
end
end

%% ----- Swap Neighborhood: Randomly swap positions of two jobs -----
function [new_sol, op_pair] = swapNeighbor(bird, new_shuttle_cood)
    new_sol = bird;  % This copies all fields
    task_seq = bird.task_sequence;
    num_shuttles = size(task_seq, 2);

    % Randomly select a shuttle
    shuttle_idx = randi(num_shuttles);
    task_mat = task_seq(shuttle_idx).task;
    valid_rows = find(~any(isnan(task_mat), 2));

    if length(valid_rows) >= 4
        % Randomly select two different task pair indices (inbound/outbound paired, step=2)
        num_pairs = floor(length(valid_rows) / 2);
        pair_indices = randperm(num_pairs, min(2, num_pairs));
        if length(pair_indices) == 2
            idx1_start = valid_rows(2 * pair_indices(1) - 1);
            idx1_end = valid_rows(2 * pair_indices(1));
            idx2_start = valid_rows(2 * pair_indices(2) - 1);
            idx2_end = valid_rows(2 * pair_indices(2));

            % Swap the two task pairs
            temp = task_mat(idx1_start:idx1_end, :);
            task_mat(idx1_start:idx1_end, :) = task_mat(idx2_start:idx2_end, :);
            task_mat(idx2_start:idx2_end, :) = temp;

            task_seq(shuttle_idx).task = task_mat;
            new_sol.task_sequence = task_seq;

            % Record operation pair (unordered, use sorted pair)
            op_pair = sort([pair_indices(1), pair_indices(2)]);
            op_pair = [shuttle_idx, op_pair];  % [shuttle ID, smaller index, larger index]
        else
            op_pair = [0, 0, 0];
        end
    else
        op_pair = [0, 0, 0];
    end

    % Recalculate Makespan
    [~, ~, ~, t_new, T_new, ~] = construct_from_task_sequence(new_sol.task_sequence, new_shuttle_cood);
    new_sol.t = t_new;
    new_sol.T = T_new;
    
    % Ensure required fields are included
    if ~isfield(new_sol, 'age')
        new_sol.age = 0;
    end
    if ~isfield(new_sol, 'neighborSet')
        new_sol.neighborSet = [];
    end
end

%% ----- Forward Insertion Neighborhood: Insert a job forward to other positions -----
function [new_sol, op_pair] = forwardInsertionNeighbor(bird, new_shuttle_cood)
    new_sol = bird;  % This copies all fields
    task_seq = bird.task_sequence;
    num_shuttles = size(task_seq, 2);

    % Randomly select a shuttle
    shuttle_idx = randi(num_shuttles);
    task_mat = task_seq(shuttle_idx).task;
    valid_rows = find(~any(isnan(task_mat), 2));
    num_pairs = floor(length(valid_rows) / 2);

    if num_pairs >= 2
        % Randomly select a task pair
        source_pair = randi([2, num_pairs]);  % Select non-first task pair
        % Randomly select a forward insertion position
        target_pair = randi([1, source_pair - 1]);

        source_start = 2 * source_pair - 1;
        source_end = 2 * source_pair;
        target_start = 2 * target_pair - 1;

        % Extract the task pair to be moved
        moved_rows = task_mat(valid_rows(source_start):valid_rows(source_end), :);

        % Delete from original position
        remaining = task_mat;
        remaining(valid_rows(source_start):valid_rows(source_end), :) = [];

        % Insert before target position
        insert_pos = valid_rows(target_start);
        if insert_pos > size(remaining, 1)
            insert_pos = size(remaining, 1) + 1;
        end
        new_task_mat = [remaining(1:insert_pos-1, :); moved_rows; remaining(insert_pos:end, :)];

        % Fill with NaN rows
        orig_rows = size(task_mat, 1);
        if size(new_task_mat, 1) < orig_rows
            new_task_mat(end+1:orig_rows, :) = NaN;
        end

        task_seq(shuttle_idx).task = new_task_mat;
        new_sol.task_sequence = task_seq;
        op_pair = [shuttle_idx, sort([source_pair, target_pair])];
    else
        op_pair = [0, 0, 0];
    end

    % Recalculate Makespan
    [~, ~, ~, t_new, T_new, ~] = construct_from_task_sequence(new_sol.task_sequence, new_shuttle_cood);
    new_sol.t = t_new;
    new_sol.T = T_new;
    
    % Ensure required fields are included
    if ~isfield(new_sol, 'age')
        new_sol.age = 0;
    end
    if ~isfield(new_sol, 'neighborSet')
        new_sol.neighborSet = [];
    end
end

%% =====================================================================
%                        Improvement 2: Tabu List Mechanism
% =====================================================================
function flag = isTabu(op_pair, tabu_list)
% Check if operation pair is in tabu list (stored unordered, (7,2) and (2,7) are considered the same tabu item)
flag = false;
if all(op_pair == 0)
    return;
end
for i = 1 : size(tabu_list, 1)
    if isequal(op_pair, tabu_list(i, :))
        flag = true;
        return;
    end
end
end

function tabu_list = addToTabuList(op_pair, tabu_list)
% Add operation pair to tabu list, tabu list size l=10, remove earliest item by "First-In-First-Out" when full
tabu_size = 10;  % Tabu list size
if all(op_pair == 0)
    return;
end
if size(tabu_list, 1) >= tabu_size
    tabu_list(1, :) = [];  % Remove earliest tabu item (FIFO)
end
tabu_list = [tabu_list; op_pair];
end

%% =====================================================================
%                  Improvement 3: Restart Mechanism ���� Generate random new solutions
% =====================================================================
function new_bird = generateRandomSolution(old_bird, new_shuttle_cood)
% Randomly generate a new solution to replace aged individual
new_bird = old_bird;
task_seq = old_bird.task_sequence;
num_shuttles = size(task_seq, 2);

for s = 1 : num_shuttles
    task_mat = task_seq(s).task;
    valid_rows = find(~any(isnan(task_mat), 2));
    num_pairs = floor(length(valid_rows) / 2);

    if num_pairs >= 2
        % Randomly shuffle the order of task pairs
        new_order = randperm(num_pairs);
        new_task_mat = task_mat;
        for p = 1 : num_pairs
            src_start = valid_rows(2 * new_order(p) - 1);
            src_end = valid_rows(2 * new_order(p));
            dst_start = valid_rows(2 * p - 1);
            dst_end = valid_rows(2 * p);
            new_task_mat(dst_start:dst_end, :) = task_mat(src_start:src_end, :);
        end
        task_seq(s).task = new_task_mat;
    end
end

new_bird.task_sequence = task_seq;
% Recalculate Makespan
[~, ~, ~, t_new, T_new, ~] = construct_from_task_sequence(new_bird.task_sequence, new_shuttle_cood);
new_bird.t = t_new;
new_bird.T = T_new;
new_bird.age = 0;
end

%% =====================================================================
%           Improvement 4: STH Intensification Mechanism (Shifting Bottleneck Heuristic)
%  Randomly select 1-3 jobs from current solution to form a "block", based on setup time minimization principle
%  Select b optimal insertion positions, return optimal solution after b iterations
% =====================================================================
function bird = STH_intensification(bird, new_shuttle_cood)
task_seq = bird.task_sequence;
num_shuttles = size(task_seq, 2);
best_T = bird.T;
best_bird = bird;
b = 3;  % Number of iterations

for iter = 1 : b
    % Randomly select a shuttle
    shuttle_idx = randi(num_shuttles);
    task_mat = task_seq(shuttle_idx).task;
    valid_rows = find(~any(isnan(task_mat), 2));
    num_pairs = floor(length(valid_rows) / 2);

    if num_pairs < 2
        continue;
    end

    % Randomly select 1-3 task pairs as "block"
    num_block = min(randi(3), num_pairs);
    block_indices = randperm(num_pairs, num_block);
    block_indices = sort(block_indices);  % Sort for extraction

    % Extract tasks in the block
    block_tasks = [];
    for bi = 1 : num_block
        row_s = valid_rows(2 * block_indices(bi) - 1);
        row_e = valid_rows(2 * block_indices(bi));
        block_tasks = [block_tasks; task_mat(row_s:row_e, :)];
    end

    % Remove block from task matrix
    remove_rows = [];
    for bi = 1 : num_block
        row_s = valid_rows(2 * block_indices(bi) - 1);
        row_e = valid_rows(2 * block_indices(bi));
        remove_rows = [remove_rows, row_s:row_e];
    end
    remaining_mat = task_mat;
    remaining_mat(remove_rows, :) = [];

    % Calculate remaining valid rows
    remaining_valid = find(~any(isnan(remaining_mat), 2));
    remaining_pairs = floor(length(remaining_valid) / 2);

    % Try inserting block into each possible position and select the optimal one
    best_insert_T = inf;
    best_insert_mat = task_mat;

    for pos = 0 : remaining_pairs
        % Insert block after the pos-th task pair
        if pos == 0
            insert_idx = 1;
        else
            insert_idx = remaining_valid(2 * pos) + 1;
            if insert_idx > size(remaining_mat, 1)
                insert_idx = size(remaining_mat, 1) + 1;
            end
        end

        candidate_mat = [remaining_mat(1:insert_idx-1, :); block_tasks; remaining_mat(insert_idx:end, :)];
        % Fill with NaN rows
        orig_rows = size(task_mat, 1);
        if size(candidate_mat, 1) < orig_rows
            candidate_mat(end+1:orig_rows, :) = NaN;
        elseif size(candidate_mat, 1) > orig_rows
            candidate_mat = candidate_mat(1:orig_rows, :);
        end

        % Evaluate Makespan of this insertion position
        test_seq = task_seq;
        test_seq(shuttle_idx).task = candidate_mat;
        test_bird = bird;
        test_bird.task_sequence = test_seq;
        [~, ~, ~, ~, T_test, ~] = construct_from_task_sequence(test_seq, new_shuttle_cood);

        if T_test < best_insert_T
            best_insert_T = T_test;
            best_insert_mat = candidate_mat;
        end
    end

    % Update if better insertion position is found
    if best_insert_T < best_T
        task_seq(shuttle_idx).task = best_insert_mat;
        best_T = best_insert_T;
    end
end

% Update bird's solution
if best_T < bird.T
    bird.task_sequence = task_seq;
    [~, ~, ~, t_new, T_new, ~] = construct_from_task_sequence(bird.task_sequence, new_shuttle_cood);
    bird.t = t_new;
    bird.T = T_new;
    if isfield(bird, 'age')
        bird.age = 0;  % Reset age if improved
    end
end
end