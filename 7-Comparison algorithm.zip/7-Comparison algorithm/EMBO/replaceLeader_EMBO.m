function [flock, leftSide] = replaceLeader_EMBO(nob, flock, leaderImproves, leaderExchangeMode, leftSide)
% =========================================================================
% Improvement 5: Age-based pseudo-random leader selection
% Solves the "inefficient leader rotation" problem
% Basic MBO defect: The leader rotates in a fixed order (left/right wing
% followers take turns), so high-quality "young" solutions in the middle of
% the queue must wait many rounds to become the leader, wasting the guidance
% of elite solutions.
%
% Improvement: Design an age-based pseudo-random selection rule that
% prioritizes "young" solutions as the new leader
% Advantage: Shortens the waiting time for elite solutions to take the lead,
% allowing high-quality solutions to guide population evolution faster
% =========================================================================
    q0 = 0.7;  % Pseudo-random threshold parameter
    q = rand;  % Generate random number
% Ensure all birds have the age field
for i = 1 : nob
if ~isfield(flock(i), 'age') || isempty(flock(i).age)
            flock(i).age = 0;
end
end
if q <= q0
        %% Mode 1: Randomly select the first follower from left/right wing as new leader
if leftSide
% The first left-wing follower (index 2) becomes the new leader
            new_leader_idx = 2;
else
% The first right-wing follower (index 3) becomes the new leader
            new_leader_idx = 3;
end
% Move the new leader to position 1, original leader moves to the vacated position
if new_leader_idx ~= 1
            temp = flock(1);
            flock(1) = flock(new_leader_idx);
            flock(new_leader_idx) = temp;
end
else
        %% Mode 2: Age-based probability selection
% Calculate the promotion probability for each solution: p_SOL_i(t) = (1/age_i) / ��(1/age_j)
% Solutions with age=0 are treated as age=0.5 (avoid division by zero, while granting highest probability)
        ages = zeros(1, nob);
for i = 1 : nob
            ages(i) = max(flock(i).age, 0.5);  % Minimum age set to 0.5 to avoid division by zero
end
% Calculate probabilities: smaller age �� larger 1/age �� higher probability
        inv_ages = 1.0 ./ ages;
        probabilities = inv_ages / sum(inv_ages);
% Select new leader by probability (roulette wheel selection)
        cum_prob = cumsum(probabilities);
        r = rand;
        new_leader_idx = 1;
for i = 1 : nob
if r <= cum_prob(i)
                new_leader_idx = i;
break;
end
end
% Move the selected bird to position 1
if new_leader_idx ~= 1
            temp = flock(1);
            flock(1) = flock(new_leader_idx);
            flock(new_leader_idx) = temp;
end
end
    %% Reconstruct V-formation: leader is confirmed (flock(1)), others remain in current order
% Clear all birds' neighbor sets (prepare for the next iteration)
for i = 1 : nob
if isfield(flock(i), 'neighborSet')
            flock(i).neighborSet = [];
end
end
% Alternate left and right sides
    leftSide = ~leftSide;
end