clc;
clear all
num_items = 40;
v_shuttle = 2;
a_shuttle = 1.5;
v_lift = 3;
a_lift =  1.5;
v_tras_shuttle = 2;
a_tras_shuttle = 1.5;
shuttles = 6;
rng(0);
data_storage.emp = xlsread('StorageLocationInfo.xlsx',1,'A4:AN227');% Read storage location information: 1 means occupied, 0 means empty;
data_storage.fre = xlsread('StorageLocationInfo.xlsx',2,'A4:AN227');% Maximum frequency is 30
data_storage.vol = xlsread('StorageLocationInfo.xlsx',3,'A4:AN227');% Maximum volume is 10
data_storage.wei = xlsread('StorageLocationInfo.xlsx',4,'A4:AN227');% Maximum weight is 25
data_goods = [xlsread('GoodsInfo.xlsx',1,'A1:D21');xlsread('GoodsInfo.xlsx',1,'F1:I21')];
[data_goods]=goodscluster(data_goods);

storages = struct();
for i =  1:224
    for j = 1:40
        storages(i,j).ID  = [i,j];
        storages(i,j).emp = data_storage.emp(i,j);
        storages(i,j).fre = data_storage.fre(i,j);
        storages(i,j).vol = data_storage.vol(i,j);
        storages(i,j).wei = data_storage.wei(i,j);
    end
end

goods = struct();
for i = 1:num_items
    goods(i).ID = i; % Goods ID
    goods(i).Frequency = data_goods(i,2); % Randomly generate weight (positive integer)
    goods(i).Volume = data_goods(i,3); % Randomly generate volume (positive integer)
    goods(i).weight = data_goods(i,4); % Randomly generate inbound/outbound frequency (positive integer)
    goods(i).cluster = data_goods(i,5); % Determine the category of each task;
    goods(i).x = 0;
    goods(i).y = 0;
    goods(i).z = 0;
end

% Determine the number of tasks in each area
storage_and_retrieval = [goods.cluster];
count_1 = sum(storage_and_retrieval(1:(num_items/2)) == 1);
count_2 = sum(storage_and_retrieval(1:(num_items/2)) == 2);
count_3 = sum(storage_and_retrieval(1:(num_items/2)) == 3);
% Determine the number of shuttles in each area;
shuttle_NumA = round(count_1/(num_items/2)*shuttles);
shuttle_NumB = round(count_2/(num_items/2)*shuttles);
shuttle_NumC = round(count_3/(num_items/2)*shuttles);

[Area] = rackarea(data_storage);
new_shuttle_cood = cell(3,1);
for i = 1:size(Area,1)
    shuttle_cood  = gen_cood_shuttles(Area(i,:),shuttle_NumA,shuttle_NumB,shuttle_NumC,i);
    new_shuttle_cood{i,:} = shuttle_cood;
end  

data = struct();
for i = 1:size(Area,1)
    [Carea,shuttle_x_task] = get_i_area(storages,Area(i,:),goods,i);
    [storage_task,Carea,goods] = calculate_vol_i(Carea,shuttle_x_task,i,data,goods);
    [retrieval_task,Carea,task] = assign_outi_task(storage_task,Carea,i);
    data(i).shuttle_x_task = shuttle_x_task;
    data(i).Carea = Carea;
    data(i).storage_task = storage_task;  
    data(i).retrieval_task = retrieval_task;
    data(i).task = task;
end

flock = struct();
[shuttle_new,trans_shuttle,lift,t,T,task_sequence] = construct(data,new_shuttle_cood);
flock.task_sequence = task_sequence;
flock.t = t;
flock.T = T;
besttime = T;
bestdist = flock.task_sequence;

t0= 2000;   % Initial temperature
Tem = t0;
B=[];    % B represents the optimal total time at each temperature iteration
temp=[];
count=0;
tend=0.1;  % Termination temperature
L=200;  % Number of iterations at each temperature
a = 0.91;% Temperature decay coefficient
tic
pflock = struct();
while Tem > tend
    for i = 1:L
        % Perform crossover and mutation on flock
        newsolution = neighbour(flock,new_shuttle_cood);
        newtime = newsolution.T;  % Time of new individual
        newdist = newsolution.task_sequence;  % Sequence of new individual
        if newtime <= besttime
            besttime = newtime;
            bestdist = newdist;
        else
            p = exp(abs((besttime-newtime))/Tem);
            if p > rand
                besttime = newtime;
                bestdist = newdist;
            end
        end
        pflock(i).task_sequence = bestdist;
        pflock(i).t = newsolution.t;
        pflock(i).T = besttime;
    end
    sumt = [pflock.T]'; % Sort the values of pflock
    [pflock,best] = pai(sumt,L,pflock);  % Sort pflock by T value
    Tem = a*Tem;
    temp =[temp;Tem];   % Record temperature
    if count == 0
        B=[B;best(1)];
    else
        if best(1) <= B(count)
            B=[B;best(1)];     % Record time
        else
            B=[B;B(count)];
        end
    end
    count=count+1;
    flock = pflock(:,1);
end
disp('Number of temperature decay iterations:')
disp(count)
figure;
x1=1:count;
y1=B;
plot(x1,y1)
xlabel('Number of temperature decay iterations')
legend('Total time')
disp('Minimum working time')
disp(B(count))
elapsedTime = toc;
fprintf('Program running time: %.2f seconds\n', elapsedTime);


function [pflock,best] = pai(sumt,L,flock)
pflock(size(flock)) = struct;
[best,index]=sort(sumt);
for i = 1:L
    pflock(i).task_sequence = flock(index(i,1)).task_sequence;
    pflock(i).t = flock(index(i,1)).t;
    pflock(i).T = flock(index(i,1)).T;
end
end