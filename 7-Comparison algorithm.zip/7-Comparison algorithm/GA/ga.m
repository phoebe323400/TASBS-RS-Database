%����������

clc
clear all
num_items = 40;
shuttles = 6;
rng(0);
magnit=30;
ps=0.8;  %Selection rate 
pc=0.6;  %Crossover rate
pm=0.01;  %Mutation rate
maxgen = 100;
data_storage.emp = xlsread('Storage location information.xlsx',1,'A4:AN227');
data_storage.fre = xlsread('Storage location information.xlsx',2,'A4:AN227');
data_storage.vol = xlsread('Storage location information.xlsx',3,'A4:AN227');
data_storage.wei = xlsread('Storage location information.xlsx',4,'A4:AN227');
data_goods = [xlsread('Task Information.xlsx',1,'A1:D21');xlsread('Task Information.xlsx',1,'F1:I21')];
[data_goods]=goodscluster(data_goods);
storages = struct();
for i =  1:224
    for j = 1:40
        storages(i,j).ID  = [i,j];
        storages(i,j).emp = data_storage.emp(i,j);
        storages(i,j).fre = data_storage.fre(i,j);
        storages(i,j).vol = data_storage.vol(i,j);
        storages(i,j).wei = data_storage.wei(i,j);
    end
end

goods = struct();
for i = 1:num_items
    goods(i).ID = i; 
    goods(i).Frequency = data_goods(i,2);
    goods(i).Volume = data_goods(i,3); 
    goods(i).weight = data_goods(i,4); 
    goods(i).cluster = data_goods(i,5); 
    goods(i).x = 0;
    goods(i).y = 0;
    goods(i).z = 0; 
end


storage_and_retrieval = [goods.cluster];
count_1 = sum(storage_and_retrieval(1:(num_items/2)) == 1);
count_2 = sum(storage_and_retrieval(1:(num_items/2)) == 2);
count_3 = sum(storage_and_retrieval(1:(num_items/2)) == 3);

shuttle_NumA = round(count_1/(num_items/2)*shuttles);
shuttle_NumB = round(count_2/(num_items/2)*shuttles);
shuttle_NumC = round(count_3/(num_items/2)*shuttles);

[Area] = rackarea(data_storage);
new_shuttle_cood = cell(3,1);
for i = 1:size(Area,1)
    shuttle_cood  = gen_cood_shuttles(Area(i,:),shuttle_NumA,shuttle_NumB,shuttle_NumC,i);
    new_shuttle_cood{i,:} = shuttle_cood;
end 

data = struct();
for i = 1:size(Area,1)
    [Carea,shuttle_x_task] = get_i_area(storages,Area(i,:),goods,i);
    [storage_task,Carea,goods] = calculate_vol_i(Carea,shuttle_x_task,i,data,goods);
    [retrieval_task,Carea,task] = assign_outi_task(storage_task,Carea,i);
    data(i).shuttle_x_task = shuttle_x_task;
    data(i).Carea = Carea;
    data(i).storage_task = storage_task;  
    data(i).retrieval_task = retrieval_task;
    data(i).task = task;
end
flock = struct();
[shuttle_new,trans_shuttle,lift,t,T,task_sequence] = construct(data,new_shuttle_cood);
flock.task_sequence = task_sequence;
flock.t = t;
flock.T = T;
for i = 1:magnit - 1
    data = newdata(data);
    [shuttle_new,trans_shuttle,lift,t,T,task_sequence] = construct(data,new_shuttle_cood);  
    flock(i+1).task_sequence = task_sequence;
    flock(i+1).t = t;
    flock(i+1).T = T;
end
tic
sumt = [flock.T]';
[pflock,best] = pai(sumt,magnit,flock);
pop = size(flock,2);
 B = [];
 for i = 1:maxgen
     fitlevelplus=fitv(best,magnit);
     [newselect,chosebest,s]=sel(magnit,fitlevelplus,pflock,best,ps);  
     crozi=cross(s,newselect,pc,new_shuttle_cood);   
     muzi=var(newselect,pm,new_shuttle_cood);
     flock1 = renew(crozi,muzi,magnit,pflock);
     sumt = [flock1.T]';
     [pflock,best] = pai(sumt,magnit,flock1);
     B=[B;best(1,1)];
 end
disp('The shortest time for task completion��')
disp(best(1,1))
figure;
x1=1:maxgen;
y1=B;
plot(x1,y1)
xlabel('Number of iterations');
ylabel('Time');
title('GAalgorithm iteration diagram');
legend('GA');
disp(pflock(1,:))
elapsedTime = toc;
fprintf('The running time of the program is: %.4f seconds\n', elapsedTime);
 
 
 function fitlevelplus = fitv(best,magnit)
     fit = 1000.-best;
     tolfit=0;   
     for s = 1: magnit
         tolfit=tolfit+fit(s,:);
     end
     fitlevel=fit./tolfit;      %fitness
     fitlevelplus=cumsum(fitlevel); %
 end
 
 
 %selection
 function [newselect,chosebest,s]=sel(magnit,fitlevelplus,pflock,best,ps)
 newselect = struct();
 chosebest =[];
 for i = 1:magnit
     if ps > rand
         lunpan=rand;
         for t = 1:(magnit-1)
             if lunpan>=fitlevelplus(t,1)&&lunpan<fitlevelplus(t+1,1)
                 newselect(t).task_sequence = pflock(t).task_sequence;
                 newselect(t).t = pflock(t).t;
                 newselect(t).T = pflock(t).T;
                 chosebest=[chosebest;best(t,:)];
             end
         end
     end
 end
 newselect = newselect(~cellfun('isempty', {newselect.t}));
 [~,s]=size(newselect);  
 end
 
 %crossover
 function crozi=cross(s,newselect,pc,new_shuttle_cood)
 crozi=struct(); 
 for i = 1:s
     solution = newselect(i);
     if pc >=rand
         crozi1 = neighbour(solution,new_shuttle_cood);
     else
         crozi1.task_sequence = [];
         crozi1.t = [];
         crozi1.T = [];
     end
     crozi(i).task_sequence = crozi1.task_sequence;
     crozi(i).t = crozi1.t;
     crozi(i).T = crozi1.T;
 end
 crozi = crozi(~cellfun('isempty', {crozi.t}));
 end
 
 %matation
 function muzi = var(newselect,pm,new_shuttle_cood)
 [~,m]=size(newselect);
 muzi = struct();
 for i = 1:m
     solution = newselect(i);
     if pm > rand
         muzi1 = neighbour(solution,new_shuttle_cood);
     else
         muzi1.task_sequence = [];
         muzi1.t = [];
         muzi1.T = [];
     end
     muzi(i).task_sequence = muzi1.task_sequence;
     muzi(i).t = muzi1.t;
     muzi(i).T = muzi1.T;
 end
 muzi = muzi(~cellfun('isempty', {muzi.t}));
 end
 
  
function [pflock,best] = pai(sumt,magnit,flock)
    pflock(size(flock)) = struct;
    [best,index]=sort(sumt);
    for i = 1:magnit
        pflock(i).task_sequence = flock(index(i,1)).task_sequence;
        pflock(i).t = flock(index(i,1)).t;
        pflock(i).T = flock(index(i,1)).T;
    end
end


function rang=renew(crozi,muzi,magnit,prang)
%Update the population
zi=[crozi,muzi];
[~,x]=size(zi);
rang=[prang(:,(1:magnit-x)),zi];
end