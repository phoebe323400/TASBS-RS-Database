#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TASBS/RS Storage Location Assignment and Task Scheduling Optimization based on Cplex
=====================================================================

Constraint formulas: (8)-(12) Inventory allocation constraints, (16)-(27) Task scheduling constraints
Objective function: (36) Minimize the maximum completion time (Makespan)
Speed model: (28)-(32)
Job mode: (33)-(35)

Dependence: pip install docplex
"""

import math
import random
import numpy as np
from itertools import product as iter_product

try:
    from docplex.mp.model import Model
    from docplex.mp.linear import Var
except ImportError:
    raise ImportError(
        "Please install docplex first: pip install docplex"
        "If you want to use the local CPLEX solver, you also need to install IBM ILOG CPLEX Optimization Studio."
    )


# ============================================================================
# Part One: Constants and Data Initialization
# ============================================================================

class TABSRSConfig:
    """TASBS/RS System Configuration Parameters"""

    # --- Shelf structure parameters ---
    NUM_TIERS = 14       # Number of Tier L (z方向)
    NUM_COLUMNS = 40     # Number of Column C (y方向)
    NUM_AISLES = 16      # Number of aisles A (x方向)

    # --- Shelf dimensions ---
    RACK_LENGTH = 0.6    # Storage location length l (m)
    RACK_WIDTH = 0.5     # Storage location width w (m)
    RACK_HEIGHT = 0.8    # Storage location height h (m)

    # --- Shuttle parameters ---
    V_SHUTTLE = 2.0          # v_s (m/s)
    A_SHUTTLE = 1.5          # a_s (m/s^2)

    # --- transfer shuttle  parameters  ---
    V_TRANSFER = 1.5         # v_ts (m/s)
    A_TRANSFER = 1.0         #  a_ts (m/s^2)

    # --- lift parameters  ---
    V_LIFT = 2.5             # v_l (m/s)
    A_LIFT = 1.5             # a_l (m/s^2)

    # --- Loading and unloading time parameters ---
    T_SHUTTLE_LOAD = 2.0     # Time for shuttle vehicle to load/unload containers t_s_load (s)
    T_TRANSFER_LOAD = 2.0    # Time for loading and unloading containers by the transfer vehicle t_ts_load (s)
    T_LIFT_LOAD = 2.0        # Time for loading and unloading the material box by the lift t_l_load (s)
    T_LIFT_SHUTTLE = 2.0     # Lift truck loading and unloading time t_l_shuttle (s)
    T_TRANSFER_SHUTTLE = 2.0 # Transfer shuttle loading and unloading shuttle time t_ts_shuttle (s)

    # --- I/O point location ---
    IO_TIER = 1
    IO_COLUMN = 1
    IO_AISLE = 1

    # --- Storage area division (three zones: A/B/C) ---
    AREA_A_TIERS = list(range(1, 8))

    AREA_B_TIERS = list(range(9, 12))

    AREA_C_TIERS = list(range(13, 14))

    # --- Storage capacity ---
    MAX_VOLUME = 10
    MAX_WEIGHT = 25

    # --- Solver parameters ---
    TIME_LIMIT = 3600        # Solution time limit (seconds)
    MIP_GAP = 0.01           # MIP Gap


class InboundTask:
    """inbound task"""
    def __init__(self, task_id, volume, weight, frequency):
        self.id = task_id
        self.volume = volume
        self.weight = weight
        self.frequency = frequency

    def __repr__(self):
        return f"InTask({self.id}, vol={self.volume}, wei={self.weight}, fre={self.frequency})"


class OutboundTask:
    """outbound task"""
    def __init__(self, task_id, location_x, location_y, location_z):
        self.id = task_id
        self.loc_x = location_x
        self.loc_y = location_y
        self.loc_z = location_z

    def __repr__(self):
        return f"OutTask({self.id}, loc=({self.loc_x},{self.loc_y},{self.loc_z}))"


class StorageLocation:
    """storage location"""
    def __init__(self, loc_id, x, y, z, max_volume, max_weight, is_empty=True):
        self.id = loc_id
        self.x = x      # 巷道
        self.y = y       # 列
        self.z = z       # 层
        self.max_volume = max_volume
        self.max_weight = max_weight
        self.is_empty = is_empty

    def __repr__(self):
        return f"Loc({self.id}, ({self.x},{self.y},{self.z}), empty={self.is_empty})"


# ============================================================================
# Part Two: Data Reading and Generation
# ============================================================================

def load_inbound_tasks():
    """
    Read the information of the incoming task (corresponding to Table 4 in the paper)
    Return the inventory task list
    """
    # Table 4 数据: (NO., Vol, Wei, Fre)
    task_data = [
        (1,  7,  23, 6),   (2,  2,  1,  3),   (3,  5,  25, 27),  (4,  5,  6,  3),
        (5,  1,  5,  12),  (6,  8,  4,  28),   (7,  3,  23, 22),  (8,  3,  16, 14),
        (9,  7,  19, 2),   (10, 5,  5,  2),    (11, 10, 15, 26),  (12, 10, 3,  1),
        (13, 5,  21, 2),   (14, 3,  19, 16),   (15, 1,  22, 6),   (16, 9,  22, 26),
        (17, 5,  4,  18),  (18, 6,  11, 3),    (19, 10, 3,  1),   (20, 5,  21, 2),
        (21, 9,  4,  11),  (22, 3,  10, 29),   (23, 7,  17, 5),   (24, 5,  13, 2),
        (25, 9,  15, 10),  (26, 4,  24, 8),    (27, 8,  20, 8),   (28, 4,  22, 19),
        (29, 4,  21, 11),  (30, 3,  20, 25),   (31, 6,  15, 9),   (32, 10, 24, 30),
        (33, 8,  3,  22),  (34, 1,  2,  29),   (35, 9,  13, 28),  (36, 2,  13, 6),
        (37, 5,  17, 10),  (38, 1,  3,  21),   (39, 10, 16, 2),   (40, 6,  23, 29),
    ]
    tasks = []
    for tid, vol, wei, fre in task_data:
        tasks.append(InboundTask(tid, vol, wei, fre))
    return tasks


def generate_storage_locations(config: TABSRSConfig, n_empty=60, n_occupied=40):
    """
    Generate storage location information
    - n_empty: Number of empty storage locations (for inventory entry)
    - n_occupied: Number of non-empty storage locations (for inventory withdrawal)
    Return: (List of empty storage locations, List of non-empty storage locations)
    """
    random.seed(42)
    all_positions = []
    for x in range(1, config.NUM_AISLES + 1):
        for y in range(1, config.NUM_COLUMNS + 1):
            for z in range(1, config.NUM_TIERS + 1):
                all_positions.append((x, y, z))

    random.shuffle(all_positions)

    empty_locs = []
    for i in range(n_empty):
        x, y, z = all_positions[i]
        loc = StorageLocation(
            loc_id=i + 1, x=x, y=y, z=z,
            max_volume=config.MAX_VOLUME,
            max_weight=config.MAX_WEIGHT,
            is_empty=True
        )
        empty_locs.append(loc)

    occupied_locs = []
    for i in range(n_empty, n_empty + n_occupied):
        x, y, z = all_positions[i]
        loc = StorageLocation(
            loc_id=i + 1, x=x, y=y, z=z,
            max_volume=config.MAX_VOLUME,
            max_weight=config.MAX_WEIGHT,
            is_empty=False
        )
        occupied_locs.append(loc)

    return empty_locs, occupied_locs


def generate_outbound_tasks(occupied_locs):
    """
    Generate out-of-stock tasks from non-empty storage locations
    """
    tasks = []
    for idx, loc in enumerate(occupied_locs):
        tasks.append(OutboundTask(
            task_id=idx + 1,
            location_x=loc.x,
            location_y=loc.y,
            location_z=loc.z
        ))
    return tasks


def generate_shuttle_info(config, num_shuttles=6):
    """
    Generate initial information for the shuttle vehicle
    Return: Dictionary of initial positions of shuttles {shuttle_id: (x, y, z)}
    """
    random.seed(123)
    shuttles = {}
    for s in range(1, num_shuttles + 1):
        shuttles[s] = (
            random.randint(1, config.NUM_AISLES),
            random.randint(1, config.NUM_COLUMNS),
            random.randint(1, config.NUM_TIERS)
        )
    return shuttles


# ============================================================================
# Part Three: Speed Model - Equations (28) - (32)
# ============================================================================

def calc_travel_time(distance, v_max, accel):
    """
    Calculate the running time of the transportation equipment from one point to another
    Formula (28): Not reaching maximum speed - only acceleration-deceleration phase
        t = 2 * sqrt(D / a)
    Formula (29): Reaching maximum speed - Acceleration - Constant speed - Deceleration stage
        t = D / v_max + v_max / a

    Parameters:
        distance: Driving distance (m)
        v_max: Maximum speed (m/s)
        accel: Acceleration (m/s^2)
    Return:
        travel_time: Running time (s)
    """
    if distance <= 0:
        return 0.0

    # The distance required to accelerate to the maximum speed
    d_accel = v_max ** 2 / accel

    if distance < d_accel:
        # Formula (28): Not reaching the maximum speed
        travel_time = 2.0 * math.sqrt(distance / accel)
    else:
        # Formula (29): Achieving maximum speed
        travel_time = distance / v_max + v_max / accel

    return travel_time


def calc_shuttle_time(y1, y2, config: TABSRSConfig):
    distance = abs(y2 - y1) * config.RACK_LENGTH
    return calc_travel_time(distance, config.V_SHUTTLE, config.A_SHUTTLE)


def calc_transfer_time(x1, x2, config: TABSRSConfig):
    distance = abs(x2 - x1) * config.RACK_WIDTH
    return calc_travel_time(distance, config.V_TRANSFER, config.A_TRANSFER)


def calc_lift_time(z1, z2, config: TABSRSConfig):
    distance = abs(z2 - z1) * config.RACK_HEIGHT
    return calc_travel_time(distance, config.V_LIFT, config.A_LIFT)


# ============================================================================
# # Part Four: Calculation of Homework Mode Time
# ============================================================================

def calc_compound_task_time_mode_a(
    shuttle_pos, io_pos, inbound_loc, outbound_loc, config: TABSRSConfig
):
    """
    Formula (33):Mode A
    """
    s_x, s_y, s_z = shuttle_pos
    io_x, io_y, io_z = io_pos
    in_x, in_y, in_z = inbound_loc
    out_x, out_y, out_z = outbound_loc


    t1 = calc_lift_time(io_z, s_z, config)

    t2 = config.T_LIFT_SHUTTLE

    t3 = calc_lift_time(s_z, io_z, config)

    t4 = calc_shuttle_time(s_y, io_y, config)

    t5 = config.T_SHUTTLE_LOAD

    t6 = calc_transfer_time(s_x, in_x, config)

    t7 = config.T_TRANSFER_SHUTTLE

    t8 = calc_lift_time(io_z, in_z, config)

    t9 = config.T_LIFT_SHUTTLE

    t10 = calc_shuttle_time(io_y, in_y, config)

    t11 = config.T_SHUTTLE_LOAD

    t12 = calc_shuttle_time(in_y, out_y, config)

    t13 = calc_lift_time(in_z, out_z, config)

    t14 = calc_transfer_time(in_x, out_x, config)

    t15 = config.T_SHUTTLE_LOAD

    t16 = config.T_LIFT_SHUTTLE

    t17 = calc_lift_time(out_z, io_z, config)

    t18 = config.T_SHUTTLE_LOAD

    total = (t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9
             + t10 + t11 + t12 + t13 + t14 + t15 + t16 + t17 + t18)
    return total


def calc_compound_task_time_mode_b(
    shuttle_pos, io_pos, inbound_loc, outbound_loc, config: TABSRSConfig
):
    """
    Formula (34):Mode B
    """
    s_x, s_y, s_z = shuttle_pos
    io_x, io_y, io_z = io_pos
    in_x, in_y, in_z = inbound_loc
    out_x, out_y, out_z = outbound_loc


    t1 = calc_lift_time(io_z, s_z, config)
    t2 = config.T_LIFT_SHUTTLE
    t3 = calc_lift_time(s_z, io_z, config)
    t4 = calc_shuttle_time(s_y, io_y, config)
    t5 = config.T_SHUTTLE_LOAD
    t6 = calc_lift_time(io_z, in_z, config)
    t7 = config.T_LIFT_SHUTTLE
    t8 = calc_shuttle_time(io_y, in_y, config)
    t9 = config.T_SHUTTLE_LOAD
    t10 = calc_transfer_time(in_x, out_x, config)
    t11 = config.T_TRANSFER_SHUTTLE
    t12 = calc_shuttle_time(in_y, out_y, config)
    t13 = config.T_SHUTTLE_LOAD
    # 回I/O
    t14 = calc_lift_time(out_z, io_z, config)
    t15 = config.T_SHUTTLE_LOAD

    total = t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11 + t12 + t13 + t14 + t15
    return total


def calc_compound_task_time_mode_c(
    shuttle_pos, io_pos, inbound_loc, outbound_loc, config: TABSRSConfig
):
    """
    Formula (35): Mode (c)
    """
    s_x, s_y, s_z = shuttle_pos
    io_x, io_y, io_z = io_pos
    in_x, in_y, in_z = inbound_loc
    out_x, out_y, out_z = outbound_loc

    # 到I/O取货
    t1 = calc_lift_time(io_z, s_z, config)
    t2 = config.T_LIFT_SHUTTLE
    t3 = calc_lift_time(s_z, io_z, config)
    t4 = calc_shuttle_time(s_y, io_y, config)
    t5 = config.T_SHUTTLE_LOAD
    t6 = calc_lift_time(io_z, in_z, config)
    t7 = config.T_LIFT_SHUTTLE
    t8 = calc_shuttle_time(io_y, in_y, config)
    t9 = config.T_SHUTTLE_LOAD
    t10 = calc_shuttle_time(in_y, out_y, config)
    t11 = config.T_SHUTTLE_LOAD
    t12 = calc_lift_time(out_z, io_z, config)
    t13 = config.T_SHUTTLE_LOAD

    total = t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11 + t12 + t13
    return total


def determine_mode_and_time(shuttle_pos, io_pos, inbound_loc, outbound_loc, config):
    """
    Based on the location of inventory entry and exit, determine the operation mode and calculate the time.
    """
    in_x, in_y, in_z = inbound_loc
    out_x, out_y, out_z = outbound_loc

    cross_tier = (in_z != out_z)
    cross_aisle = (in_x != out_x)

    if cross_tier and cross_aisle:

        mode = 'a'
        t = calc_compound_task_time_mode_a(shuttle_pos, io_pos, inbound_loc, outbound_loc, config)
    elif not cross_tier and cross_aisle:

        mode = 'b'
        t = calc_compound_task_time_mode_b(shuttle_pos, io_pos, inbound_loc, outbound_loc, config)
    else:

        mode = 'c'
        t = calc_compound_task_time_mode_c(shuttle_pos, io_pos, inbound_loc, outbound_loc, config)

    return mode, t


# ============================================================================
# Part Five: LMD Calculation
# ============================================================================

def calc_lmd(task: InboundTask, loc: StorageLocation):
    """
    Formula (5)-(7): Calculate the matching degree LMD between the inbound task and the storage location
    LMD = V* + M*
    V* = |V_m - V_i| / V_m
    M* = |M_m - W_i| / M_m
    The smaller the LMD is, the higher the degree of matching will be.
    """
    if task.volume > loc.max_volume or task.weight > loc.max_weight:
        return float('inf')  # 不满足容量约束

    v_star = abs(loc.max_volume - task.volume) / loc.max_volume if loc.max_volume > 0 else float('inf')
    m_star = abs(loc.max_weight - task.weight) / loc.max_weight if loc.max_weight > 0 else float('inf')
    lmd = v_star + m_star
    return lmd


# ============================================================================
# Part VI: Pre-calculated Task Time Matrix
# ============================================================================

def precompute_task_times(inbound_tasks, outbound_tasks, empty_locs, config):
    """
    Return: task_time_dict[(in_task_id, loc_id, out_task_id)] = time
    """
    io_pos = (config.IO_AISLE, config.IO_COLUMN, config.IO_TIER)
    # 简化: 使用一个统一的穿梭车初始位置 (后续在CPLEX中通过决策变量动态确定)
    default_shuttle_pos = (1, 1, 1)

    task_times = {}
    for in_task in inbound_tasks:
        for loc in empty_locs:
            if in_task.volume <= loc.max_volume and in_task.weight <= loc.max_weight:
                inbound_loc = (loc.x, loc.y, loc.z)
                for out_task in outbound_tasks:
                    outbound_loc = (out_task.loc_x, out_task.loc_y, out_task.loc_z)
                    _, t = determine_mode_and_time(
                        default_shuttle_pos, io_pos, inbound_loc, outbound_loc, config
                    )
                    task_times[(in_task.id, loc.id, out_task.id)] = t

    return task_times


# ============================================================================
# Part Seven: CPLEX Model Construction
# ============================================================================

def build_cplex_model(
    inbound_tasks, outbound_tasks, empty_locs, occupied_locs,
    shuttles, config: TABSRSConfig, task_times
):
    """
    Construct a CPLEX mixed integer programming model

    Constraint:
        Formula (8)-(12): Inventory allocation constraints
        公Formula (16)-(27): Task scheduling constraints
    Objective:
        Formula (36): min T_max
    """

    mdl = Model(name="TASBS_RS_Optimization")

    # --- 集合定义 ---
    I_in = [t.id for t in inbound_tasks]          # Inbound task collection
    I_out = [t.id for t in outbound_tasks]         # Outbound task collection
    M_empty = [loc.id for loc in empty_locs]       # Empty storage location set
    M_full = [loc.id for loc in occupied_locs]     # Non-empty set of storage locations
    S = list(shuttles.keys())                      # Shuttle collection
    N_total = len(I_in)                            # Number of Composite Tasks

    # Establish index mapping
    in_task_dict = {t.id: t for t in inbound_tasks}
    out_task_dict = {t.id: t for t in outbound_tasks}
    empty_loc_dict = {loc.id: loc for loc in empty_locs}
    occ_loc_dict = {loc.id: loc for loc in occupied_locs}

    # --- Definition of Decision Variables ---


    x = mdl.binary_var_matrix(I_in, M_empty, name="x")


    y = mdl.binary_var_matrix(I_in, I_out, name="y")


    z_assign = mdl.binary_var_matrix(I_in, S, name="z_assign")

    # seq[i,j,s]: On the shuttle vehicle S, task i is executed before task j.
    seq = {}
    for i in I_in:
        for j in I_in:
            if i != j:
                for s in S:
                    seq[i, j, s] = mdl.binary_var(name=f"seq_{i}_{j}_{s}")

    # st[i]: The start time of composite task i (continuous)
    st = mdl.continuous_var_dict(I_in, lb=0, name="st")

    # ct[i]: Completion time of composite task i (continuous)
    ct = mdl.continuous_var_dict(I_in, lb=0, name="ct")

    # proc_time[i]: Processing time of composite task i (continuous auxiliary variable)
    proc_time = mdl.continuous_var_dict(I_in, lb=0, name="proc_time")

    # T_max: Maximum completion time (Makespan)
    T_max = mdl.continuous_var(lb=0, name="T_max")

    # ===================================================================
    # Establishment of constraints
    # ===================================================================

    G = 1e6  # The Big M Constant

    # ------ Storage location allocation constraint ------

    # Formula (8): Each inbound task can only be assigned to one storage location.
    for i in I_in:
        mdl.add_constraint(
            mdl.sum(x[i, m] for m in M_empty) == 1,
            ctname=f"eq8_single_loc_{i}"
        )

    # Formula (9): The number of inbound tasks shall not exceed the number of empty storage positions, and the number of outbound tasks shall not exceed the number of non-empty storage positions.
    mdl.add_constraint(
        mdl.sum(x[i, m] for i in I_in for m in M_empty) <= len(M_empty),
        ctname="eq9_inbound_capacity"
    )

    # Formula (10): All composite tasks must be completed - each inbound task must be precisely matched with an outbound task.
    for i in I_in:
        mdl.add_constraint(
            mdl.sum(y[i, j] for j in I_out) == 1,
            ctname=f"eq10_compound_in_{i}"
        )

    # Each outbound task can be paired with at most one inbound task.
    for j in I_out:
        mdl.add_constraint(
            mdl.sum(y[i, j] for i in I_in) <= 1,
            ctname=f"eq10_compound_out_{j}"
        )

    # Formula (12): Constraint for non-empty or empty inventory status
    for i in I_in:
        task = in_task_dict[i]
        for m in M_empty:
            loc = empty_loc_dict[m]
            if task.volume > loc.max_volume or task.weight > loc.max_weight:
                mdl.add_constraint(x[i, m] == 0, ctname=f"eq12_cap_{i}_{m}")

    # Each empty storage location can be assigned at most one inbound task.
    for m in M_empty:
        mdl.add_constraint(
            mdl.sum(x[i, m] for i in I_in) <= 1,
            ctname=f"eq12_loc_unique_{m}"
        )

    # ------ Task scheduling constraints ------

    # Formula (16): Each composite task has a corresponding operation mode
    w = {}
    for i in I_in:
        for m in M_empty:
            for j in I_out:
                key = (i, m, j)
                if (i, m, j) in task_times:
                    w[key] = mdl.binary_var(name=f"w_{i}_{m}_{j}")

    # Linearization constraint: w[i,m,j] = x[i,m] * y[i,j]
    for (i, m, j), wvar in w.items():
        mdl.add_constraint(wvar <= x[i, m], ctname=f"lin_w1_{i}_{m}_{j}")
        mdl.add_constraint(wvar <= y[i, j], ctname=f"lin_w2_{i}_{m}_{j}")
        mdl.add_constraint(wvar >= x[i, m] + y[i, j] - 1, ctname=f"lin_w3_{i}_{m}_{j}")

    # proc_time[i] = sum_{m,j} task_times[i,m,j] * w[i,m,j]
    for i in I_in:
        mdl.add_constraint(
            proc_time[i] == mdl.sum(
                task_times.get((i, m, j), 0) * w.get((i, m, j), 0)
                for m in M_empty for j in I_out
                if (i, m, j) in task_times
            ),
            ctname=f"eq16_proc_time_{i}"
        )


    # Formula (24): Each task can only be assigned to the same shuttle vehicle from the beginning to the end.
    for i in I_in:
        mdl.add_constraint(
            mdl.sum(z_assign[i, s] for s in S) == 1,
            ctname=f"eq19_24_assign_{i}"
        )


    # Formula (21): The number of tasks assigned to each shuttle vehicle shall not exceed the total number of tasks.
    for s in S:
        mdl.add_constraint(
            mdl.sum(z_assign[i, s] for i in I_in) <= N_total,
            ctname=f"eq21_shuttle_cap_{s}"
        )


    for i in I_in:
        for j in I_in:
            if i != j:
                for s in S:
                    #If the shuttle vehicle S executes action i first and then action j, then ct[i] <= st[j]
                    mdl.add_constraint(
                        ct[i] - st[j] <= G * (1 - seq[i, j, s]),
                        ctname=f"eq22_23_prec_{i}_{j}_{s}"
                    )

    # Consistency between seq and z_assign: If both i and j are assigned to s, the sequence must be determined.
    for i in I_in:
        for j in I_in:
            if i < j:
                for s in S:
                    # seq[i,j,s] + seq[j,i,s] >= z_assign[i,s] + z_assign[j,s] - 1
                    mdl.add_constraint(
                        seq[i, j, s] + seq[j, i, s] >= z_assign[i, s] + z_assign[j, s] - 1,
                        ctname=f"eq_seq_cons_{i}_{j}_{s}"
                    )
                    # seq[i,j,s] + seq[j,i,s] <= 1
                    mdl.add_constraint(
                        seq[i, j, s] + seq[j, i, s] <= 1,
                        ctname=f"eq_seq_excl_{i}_{j}_{s}"
                    )

    # The "seq" function is only effective when assigned to the same shuttle vehicle.
    for i in I_in:
        for j in I_in:
            if i != j:
                for s in S:
                    mdl.add_constraint(
                        seq[i, j, s] <= z_assign[i, s],
                        ctname=f"eq_seq_z1_{i}_{j}_{s}"
                    )
                    mdl.add_constraint(
                        seq[i, j, s] <= z_assign[j, s],
                        ctname=f"eq_seq_z2_{i}_{j}_{s}"
                    )


    # Completion time = Start time + Processing time
    for i in I_in:
        mdl.add_constraint(
            ct[i] == st[i] + proc_time[i],
            ctname=f"ct_def_{i}"
        )


    # x[i,m] ∈ {0,1}, y[i,j] ∈ {0,1}, z_assign[i,s] ∈ {0,1}
    # st[i] >= 0, ct[i] >= 0

    # ===================================================================
    #Objective function — 公式(36): min T_max
    # ===================================================================

    # T_max >= ct[i] for all i
    for i in I_in:
        mdl.add_constraint(
            T_max >= ct[i],
            ctname=f"eq36_makespan_{i}"
        )

    mdl.minimize(T_max)

    # --- Solver parameters ---
    mdl.parameters.timelimit = config.TIME_LIMIT
    mdl.parameters.mip.tolerances.mipgap = config.MIP_GAP

    return mdl, {
        'x': x, 'y': y, 'z_assign': z_assign, 'seq': seq,
        'st': st, 'ct': ct, 'proc_time': proc_time, 'T_max': T_max, 'w': w
    }


# ============================================================================
# Part Eight: Solution and Result Output
# ============================================================================

def solve_and_report(mdl, variables, inbound_tasks, outbound_tasks,
                     empty_locs, shuttles, config):
    """
    Solve the model and output the results
    """
    print("=" * 70)
    print("Joint Optimization of Warehouse Location Allocation and Task Scheduling in TASBS/RS - Solution by CPLEX")
    print("=" * 70)
    print(f"Time limit for solving: {config.TIME_LIMIT}s")
    print(f"MIP Gap:    {config.MIP_GAP}")
    print("-" * 70)

    # Printing model statistics
    mdl.print_information()
    print("-" * 70)

    # 求解
    print("\nLet's start solving...")
    solution = mdl.solve(log_output=True)

    if solution is None:
        print("\n" + "!" * 70)
        print("No feasible solution was found!")
        print("Possible reasons:")
        print("  1. The model is not feasible")
        print("  2. Insufficient time for solution (increase TIME_LIMIT)")
        print("  3. The problem is too large in scale.")

        try:
            conflicts = mdl.refine_conflict()
            if conflicts:
                print("\nConflict Constraint:")
                for ct in conflicts.iter_constraints():
                    print(f"  {ct}")
        except Exception:
            pass
        print("!" * 70)
        return None

    # --- Output result ---
    x = variables['x']
    y = variables['y']
    z_assign = variables['z_assign']
    st = variables['st']
    ct = variables['ct']
    proc_time = variables['proc_time']
    T_max = variables['T_max']

    I_in = [t.id for t in inbound_tasks]
    I_out = [t.id for t in outbound_tasks]
    M_empty = [loc.id for loc in empty_locs]
    S = list(shuttles.keys())

    in_task_dict = {t.id: t for t in inbound_tasks}
    out_task_dict = {t.id: t for t in outbound_tasks}
    empty_loc_dict = {loc.id: loc for loc in empty_locs}

    print("\n" + "=" * 70)
    print(f"Optimal completion time (Makespan): {solution.get_value(T_max):.2f} s")
    print(f"Solve the state: {mdl.solve_details.status}")
    print(f"Solution time: {mdl.solve_details.time:.2f} s")
    print(f"MIP Gap:  {mdl.solve_details.mip_relative_gap:.4%}")
    print("=" * 70)


    assignments = {}
    for i in I_in:
        for m in M_empty:
            if solution.get_value(x[i, m]) > 0.5:
                loc = empty_loc_dict[m]
                task = in_task_dict[i]
                lmd = calc_lmd(task, loc)
                assignments[i] = m
                print(f"{i:>8} | {m:>6} | ({loc.x:>2},{loc.y:>2},{loc.z:>2}) | "
                      f"{task.volume:>4} | {task.weight:>4} | {task.frequency:>4} | "
                      f"{lmd:>6.2f}")


    pairings = {}
    for i in I_in:
        for j in I_out:
            if solution.get_value(y[i, j]) > 0.5:
                out = out_task_dict[j]
                pairings[i] = j
                print(f"{i:>8} | {j:>8} | ({out.loc_x:>2},{out.loc_y:>2},{out.loc_z:>2})")

    # --- Shuttle mission allocation ---
    print("\n--- Shuttle task allocation and scheduling ---")
    for s in S:
        tasks_on_s = []
        for i in I_in:
            if solution.get_value(z_assign[i, s]) > 0.5:
                tasks_on_s.append((i, solution.get_value(st[i]),
                                   solution.get_value(ct[i]),
                                   solution.get_value(proc_time[i])))
        # Sort by start time
        tasks_on_s.sort(key=lambda t: t[1])

        print(f"\nshuttle {s} (Initial position: {shuttles[s]}): Allocation {len(tasks_on_s)} tasks")
        if tasks_on_s:
            print(f"  {'tasks':>4} | {'start time':>10} | {'finish time':>10} | {'process time':>10}")
            print(f"  " + "-" * 45)
            for tid, start, comp, proc in tasks_on_s:
                print(f"  {tid:>4} | {start:>10.2f} | {comp:>10.2f} | {proc:>10.2f}")

    # --- Summary statistics ---
    print("\n" + "=" * 70)
    print("Summary statistics")
    print("=" * 70)

    shuttle_loads = {}
    for s in S:
        load = sum(1 for i in I_in if solution.get_value(z_assign[i, s]) > 0.5)
        shuttle_loads[s] = load

    print(f"Load capacity of each shuttle: {shuttle_loads}")
    max_load = max(shuttle_loads.values()) if shuttle_loads else 0
    min_load = min(shuttle_loads.values()) if shuttle_loads else 0
    print(f"Load difference: max={max_load}, min={min_load}, diff={max_load - min_load}")

    # Task balance degree TB
    avg_load = sum(shuttle_loads.values()) / len(shuttle_loads) if shuttle_loads else 0
    tb = math.sqrt(sum((v - avg_load) ** 2 for v in shuttle_loads.values()))
    print(f"Task balance degree TB: {tb:.2f}")
    print(f"Makespan: {solution.get_value(T_max):.2f} s")
    print("=" * 70)

    return solution


# ============================================================================
# Main program
# ============================================================================

def main():
    """
    Main function: Complete TASBS/RS joint optimization process
    """
    # --- 1. Initial configuration ---
    config = TABSRSConfig()

    # --- 2. Data reading---
    print("Load data...")
    inbound_tasks = load_inbound_tasks()

    # Control the problem size (adjustable)
    N_TASKS = 20
    inbound_tasks = inbound_tasks[:N_TASKS]

    n_inbound = len(inbound_tasks)
    n_outbound = n_inbound
    n_empty = max(n_inbound + 10, 30)

    empty_locs, occupied_locs = generate_storage_locations(
        config, n_empty=n_empty, n_occupied=n_outbound
    )
    outbound_tasks = generate_outbound_tasks(occupied_locs)

    # The number of shuttle vehicles
    num_shuttles = 3 if N_TASKS <= 20 else 6
    shuttles = generate_shuttle_info(config, num_shuttles=num_shuttles)

    print(f"Inbound task: {n_inbound}, outbound task: {n_outbound}")
    print(f"Empty storage space: {n_empty}, shuttle: {num_shuttles}")

    # --- 3. Pre-computed task time ---
    print("\nPre-computed composite task time matrix...")
    task_times = precompute_task_times(inbound_tasks, outbound_tasks, empty_locs, config)
    print(f"Number of effective time combinations: {len(task_times)}")

    # --- 4. Build a CPLEX model ---
    print("\nConstruct a CPLEX mixed integer programming model...")
    mdl, variables = build_cplex_model(
        inbound_tasks, outbound_tasks, empty_locs, occupied_locs,
        shuttles, config, task_times
    )

    # --- 5. Solving and result output ---
    solution = solve_and_report(
        mdl, variables, inbound_tasks, outbound_tasks,
        empty_locs, shuttles, config
    )

    if solution:
        print("\nSolution found successfully! The result can be used for the comparison experiment with the MBO-HSA algorithm.")
    else:
        print("\nThe solution failed. Please check the model parameters or increase the solution time.")

    return mdl, solution


if __name__ == "__main__":
    main()